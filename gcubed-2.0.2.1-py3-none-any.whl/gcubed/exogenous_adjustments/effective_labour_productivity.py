"""
This module contains the `EffectiveLabourProductivity` class,
used to set up and provided access to baseline productivity shocks.

Productivity shocks in simulations should be set up in a 
`SimulationLayer`.
"""

import os
import logging
from gcubed.sym_data import SymData
from gcubed.model_configuration import ModelConfiguration
import pandas as pd
import numpy as np
from gcubed.base import Base
from gcubed.model_parameters.parameters import Parameters
from gcubed.exogenous_adjustments.productivity import Productivity
from gcubed.exogenous_adjustments.population import Population
import decimal


class EffectiveLabourProductivity(Base):
    """
    Sets up effective labour productivity projections as well as potential
    output growth projections.

    Effective labor is A times L where A is productivity and L is labor.
    """

    def __init__(self, parameters: Parameters) -> None:
        """
        ### Constructor

        Constructor that sets up the effective labour productivity projections and
        potential output growth projections.

        The projections are based upon the input CSV files containing data
        on productivity and population growth.

        ### Arguments

        `parameters`: The calibrated model parameters.

        The parameters input gives access to the model configuration so that
        the locations of the relevant CSV files can be determined.

        """
        assert parameters is not None
        self._parameters = parameters

        self._productivity = Productivity(sym_data=self.sym_data)

        self._population = Population(sym_data=self.sym_data)

        self.__configure_effective_labour_productivity_deviations()

        self.__configure_potential_output_growth_projections()

        self.__validate()

    def __validate(self):
        """
        TODO: Check that productivity shocks etc. meet expectations
        """
        pass

    @property
    def parameters(self):
        """
        The calibrated model parameters.
        """
        return self._parameters

    @property
    def calibration_database(self):
        """
        The database used to calibrate the model parameters.
        """
        return self.parameters.calibration_database

    @property
    def sym_data(self) -> SymData:
        """
        The information about the model structure available from the
        SYM model definition.
        """
        return self.parameters.sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        """
        The model configuration.
        """
        return self.parameters.sym_data.configuration

    @property
    def productivity(self) -> Productivity:
        """
        The productivity projections for each region and each projection year.
        """
        return self._productivity

    @property
    def population(self) -> Population:
        """
        The population projections for each region and each projection year.
        """
        return self._population

    @property
    def potential_output_growth_rates(self) -> pd.DataFrame:
        """
        A dataframe containing the real growth in potential output (ROGY)
        for each region (rows) and each projection year (columns).
        """
        if not hasattr(self, "_potential_output_growth_rates"):
            self._potential_output_growth_rates: pd.DataFrame = pd.DataFrame(
                0.0,
                index=self.sym_data.regions_members,
                columns=self.configuration.projection_years_column_labels,
            )
        return self._potential_output_growth_rates

    @property
    def us_longrun_effective_labour_index(self) -> pd.DataFrame:
        """

        ### Overview

        Set up the US long run effective labour growth rate from the model parameters
        and project that rate forward to the end of the projection years to
        create an index that has a simple growth rate that is equal to the value
        of the `labgrow` parameter for the US
        (defined in the user-set parameters).

        ### Returns

        A dataframe containing the log of the US longrun effective labour (AL) index for
        each sector (rows) and each projection year (columns).

        The index has the base year equal to the first projection year.

        """

        # Just return the index if it has already been set up.
        if hasattr(self, "_us_longrun_effective_labour_log_index"):
            return self._us_longrun_effective_labour_log_index

        # We need to set up the index using the `labgrow` parameter.
        us_long_run_growth_rate: float = float(
            self.parameters.parameter(parameter_name="labgrow")
            .loc[:, self.sym_data.us_region]
            .values[0]
        )
        us_long_run_effective_labour_log_index: pd.DataFrame = (
            pd.DataFrame(
                0.0,
                index=["US_LONGRUN_EFFECTIVE_LABOUR_INDEX"],
                columns=self.configuration.projection_years_column_labels,
            )
            + us_long_run_growth_rate
        ).cumsum(axis="columns") - us_long_run_growth_rate

        self._us_longrun_effective_labour_log_index = np.exp(
            us_long_run_effective_labour_log_index
        )

        return self._us_longrun_effective_labour_log_index

    @property
    def region_effective_labour_productivity_deviations(
        self,
    ) -> dict[str, pd.DataFrame]:
        """
        The dictionary of dataframes used to store effective labour productivity deviations
        from the US longrun. It is indexed by region code.
        The dataframes are indexed by sector code.
        The columns of the dataframes are the projection years.
        """
        if not hasattr(self, "_region_effective_labour_productivity_deviations"):
            self._region_effective_labour_productivity_deviations: dict[
                str, pd.DataFrame
            ] = dict()
        return self._region_effective_labour_productivity_deviations

    def effective_labour_productivity_deviations(self, region: str) -> pd.DataFrame:
        """

        ### Overview

        This provides access to effective productivity growth adjustments through the
        projection years for each sector (in the set of model-specific sectors)
        in each region of the model.

        These adjustments are made to effectively productivity growth rates when setting
        up the baseline exogenous variable projections.

        ### Arguments

        region: The region for which the effective productivity deviations are required.

        ### Returns

        A dataframe indexed by sector for SHL adjustments each year through the
        projection years, e.g. `SHL(PP,a02)` where `PP` is the region code
        and `a02` is the sector code. The column labels are the projection years.

        The data is sourced from a dictionary of dataframes, with each dataframe indexed by sector.
        The dictionary is keyed by region.

        The data is multiplied by 100 to be comparable to the database, so a value of 1 is a
        1 percent deviation.

        """
        assert (
            region in self.region_effective_labour_productivity_deviations
        ), f"Region {region} does not have effective labour productivity deviation data."

        return self.region_effective_labour_productivity_deviations[region]

    def __configure_effective_labour_productivity_deviations(self):
        """

        ### Overview

        Populate a dictionary of regional dataframes of
        effective labour productivity deviations
        from the US long run.

        """

        projection_years: list[str] = self.configuration.projection_years_column_labels
        later_years: list[str] = projection_years[1:]
        earlier_years: list[str] = projection_years[:-1]

        for region in self.sym_data.regions_members:
            assert (
                not self.productivity.productivity_growth_rates(region)
                .isna()
                .any()
                .any()
            ), f"Region {region} productivity growth rates includes NaN values."
            assert (
                not self.population.population_growth_rates.loc[region, :]
                .isna()
                .any()
                .any()
            ), f"Region {region} population growth rates includes NaN values."

            # Add productivity growth and population growth
            growth_rates: pd.DataFrame = (
                self.productivity.productivity_growth_rates(region=region)
                + self.population.population_growth_rates.loc[[region], :].to_numpy()
            )

            # Convert the growth rates to log indices
            log_indices: pd.DataFrame = growth_rates.cumsum(axis="columns")
            log_indices.loc[:, later_years] = log_indices.loc[
                :, earlier_years
            ].to_numpy()
            log_indices.iloc[:, 0] = 0.0

            # Get US long run log index
            us_longrun_log_indices: pd.DataFrame = np.log(
                self.us_longrun_effective_labour_index
            )

            # Convert the aggregate growth rates to indices.
            effective_productivity_deviations: pd.DataFrame = (
                log_indices - us_longrun_log_indices.to_numpy()
            )

            # Scale up by 100 to be comparable to the database.
            effective_productivity_deviations *= 100.0

            # effective_productivity_deviations_in_first_projection_year: np.ndarray = (
            #     effective_productivity_deviations.loc[
            #         :, [str(self.configuration.first_projection_year)]
            #     ]
            #     .copy()
            #     .to_numpy()
            # )
            # effective_productivity_deviations.iloc[:, :] = (
            #     effective_productivity_deviations.to_numpy()
            #     - effective_productivity_deviations_in_first_projection_year
            # )
            self.region_effective_labour_productivity_deviations[region] = (
                effective_productivity_deviations
            )

    def __configure_potential_output_growth_projections(self):
        """

        ### Overview

        Produces a dataframe of projections for
        potential output growth rates (ROGY)
        for each region.

        The rows are indexed by region code.

        The columns correspond to projection years.

        ### Algorithm summary

        Get region values by using OUP-based weights
        across sectors (rows) for each region (columns).

        Get OUP by region/sector for the first projection year.
        Get total OUP for each sector (row) and region (column).
        Convert to national weights by dividing each OUP value by the total of OUP for the corresponding region.

        The model variable SHL(:,region) = effective_productivity_deviations(region)

        get SHL(:,region) from the first projection year to last projection year data.

        Then calculate t minus t-1 deviations in SHL(:,region), using zeros for the year before the start year.

        Then weight the change in SHL(:,region) for each year, using weights computed from OUP for the region we are calculating data for.

        """

        projection_years: list[str] = self.configuration.projection_years_column_labels
        later_years: list[str] = projection_years[1:]
        earlier_years: list[str] = projection_years[:-1]

        # Set up the dataframe to hold the OUP-based weights across sectors for each region
        weights_dataframe: pd.DataFrame = pd.DataFrame(
            0.0,
            index=self.sym_data.sectors_members,
            columns=self.sym_data.regions_members,
        )

        # Get the first-projection year OUP data for all sectors in the region
        decimal.getcontext().prec = 10
        for region in self.sym_data.regions_members:
            # Create the OUP based weights for the region
            oup: pd.DataFrame = self.calibration_database.get_data(
                name_regular_expression=rf"^OUP\(.*{region}.*$",
                years=self.configuration.first_projection_year,
            )
            region_weights: pd.DataFrame = oup / oup.sum(axis=0)
            weights: np.ndarray = region_weights.to_numpy().reshape(
                1, self.sym_data.sectors_count
            )
            weights_dataframe.loc[:, [region]] = np.transpose(weights)

            # Compute sectoral potential growth rates
            # from the effective labour productivity deviations.
            sectoral_potential_growth_rates: pd.DataFrame = (
                self.effective_labour_productivity_deviations(region=region).copy()
            )
            sectoral_potential_growth_rates.loc[:, later_years] = (
                sectoral_potential_growth_rates.loc[:, later_years].to_numpy()
                - sectoral_potential_growth_rates.loc[:, earlier_years].to_numpy()
            )

            # Compute potential output growth rates
            # for the region by taking the weighted average
            # of the sectoral potential growth rates.
            self.potential_output_growth_rates.loc[[region], :] = (
                weights @ sectoral_potential_growth_rates.to_numpy()
            )

        # Save the weights to a CSV file for diagnostic purposes.
        # weights_dataframe.to_csv(
        #     os.path.join(
        #         self.sym_data.configuration.diagnostics_directory,
        #         "ROGY sector weights based on OUP for each region.csv",
        #     )
        # )
