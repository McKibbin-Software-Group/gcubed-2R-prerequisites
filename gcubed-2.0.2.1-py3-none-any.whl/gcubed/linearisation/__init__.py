"""
Model linearisation module.
"""
