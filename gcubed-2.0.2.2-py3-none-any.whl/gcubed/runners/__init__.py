"""
This module contains the Runner classes for G-Cubed.

Various `Runner` classes are used for different types of model experiments.

The `SimpleRunner` should be used by most users. The `AdvancedRunner` has 
a number of experimental features that are still be refined.

"""
