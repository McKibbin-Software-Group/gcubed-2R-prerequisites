"""
Model version 20R parameter subclasses.
"""
