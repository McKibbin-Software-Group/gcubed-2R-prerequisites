"""
This module contains the Model class, used to load:

- the model configuration
- the details of the model equations expressed in the
SYM files
- the model database
- the IO tables
- the model parameters
- the exogenous variable baseline effective labor productivity details
- the exogenous variable energy efficiency adjustments

"""

import sys
import importlib
import importlib.util
import logging
import os
import pandas as pd
import gcubed
from gcubed.base import Base
from gcubed.exogenous_adjustments.productivity import Productivity
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData
from gcubed.validator import *
from gcubed.model_parameters.parameters import Parameters
from gcubed.data.database import Database
from gcubed.exogenous_adjustments.energy_usage_efficiency import EnergyUsageEfficiency
from gcubed.exogenous_adjustments.effective_labour_productivity import (
    EffectiveLabourProductivity,
)


class Model(Base):
    """
    Encapsulates all of the information about a Model,
    sufficient to generate baseline projections.
    """

    def __init__(self, configuration: ModelConfiguration) -> None:
        """

        ### Constructor

        Cause the model to load based on the information in its configuration.

        ### Arguments

        configuration (ModelConfiguration): the configuration details
        for the model being created.

        """
        self._configuration: ModelConfiguration = configuration

        logging.info(
            f"Setting up model version {self.configuration.version} build {self.configuration.build}."
        )

        self._sym_data: SymData = SymData(configuration=self.configuration)

        # Make sure the model is allowed to run.
        validator: Validator = AllModelsValidator(sym_data=self.sym_data)
        validator.validate()

        self._database: Database = Database(sym_data=self.sym_data)

        # ---------------------------------------------------------------------
        # Calibrate the model parameters.
        # Dynamically loads the parameters class specified
        # from the Python file in the model's Python directory.
        # The file is called "parameters_{version}_{build}.py" where
        # {version} is the model version and {build} is the build number.
        # ---------------------------------------------------------------------
        if self.configuration.python_directory not in sys.path:
            sys.path.insert(0, self.configuration.python_directory)
        module = importlib.import_module(f"{self.configuration.parameters_module_name}")
        parameters_class = getattr(module, self.configuration.parameters_class_name)
        parameters: Parameters = parameters_class(
            database=self.database,
            base_year=self.configuration.calibration_year,
        )
        parameters.validate()

        # Check that parameters is an instance of the Parameters class.
        assert isinstance(
            parameters, Parameters
        ), f"The parameter calibration class is not a subclass of gcubed.model_parameters.parameters.Parameters."

        # Save the parameters as a property of the model
        self._parameters = parameters

        # Do the initial projections of exogenous variables.
        self._effective_productivity = EffectiveLabourProductivity(
            parameters=self.parameters
        )

        self._energy_usage_efficiency = EnergyUsageEfficiency(sym_data=self.sym_data)

        # If necessary, create the modprod file by instantiating the productivity class
        if not os.path.exists(self.configuration.modprod_file):
            Productivity(self.sym_data)

        # If necessary, recreate the exogenous growth and efficiency adjustments file
        if not os.path.exists(
            self.configuration.exogenous_growth_and_efficiency_adjustments_file
        ):
            self.create_exogenous_growth_and_efficiency_adjustments()

        self.__validate()

    def __validate(self):
        """
        Raise an exception if the model is invalid.
        Confirm a successful instantiation otherwise.
        """
        logging.info(
            f"Model {self.configuration.version} {self.configuration._build} has successfully loaded."
        )

    @property
    def configuration(self) -> ModelConfiguration:
        """
        The model configuration.
        """
        return self._configuration

    @property
    def sym_data(self) -> SymData:
        """
        The data provided by SYM about variables and parameters.
        """
        return self._sym_data

    @property
    def database(self) -> Database:
        """
        The model database.
        """
        return self._database

    @property
    def parameters(self) -> Parameters:
        """
        The model parameter values, set by the user and calibrated
        from the model database and IO tables.
        """
        return self._parameters

    @property
    def effective_labour_productivity(self) -> EffectiveLabourProductivity:
        """
        The effective labour productivity growth projections underpinning
        levels projections that reflect long-run growth prospects.
        """
        return self._effective_productivity

    @property
    def energy_usage_efficiency(self) -> EnergyUsageEfficiency:
        """
        The energy usage efficiency improvement rate projections for each sector in each
        region. These impact projections for energy requirements by region and sector.
        """
        return self._energy_usage_efficiency

    def create_exogenous_growth_and_efficiency_adjustments(self):
        """
        ### Overview

        Create a CSV file containing the exogenous variable projections and save
        them into a CSV file in the data directory. The name of the CSV file
        is specified in the model configuration.

        The projections capture:

        * effective labour productivity projections (based on population and productivity
        growth rates in each region)
        * energy efficiency improvement projections (based on projections of
        autonomous energy efficiency improvements)

        # Exceptions

        Raises an exception if the first-projection-year exogenous variable values include NaNs.

        """

        projections: pd.DataFrame = pd.DataFrame(
            columns=self.configuration.projection_years_column_labels,
        )

        # Get the real region GDP to real USA GDP ratios
        # in the database in the base year of the database
        # for all regions - they are needed for projection scaling.
        yratr_data: pd.DataFrame = self.database.data.loc[
            self.database.variables.name.str.startswith(
                f"{gcubed.CONSTANTS.US_REAL_GDP_RATIO_PREFIX}("
            ),
            str(self.database.base_year),
        ].copy()
        yratr_data.index = self.sym_data.regions_members

        # Do the energy usage efficiency improvements projections.
        if self.configuration.use_energy_usage_efficiency_projections:
            # Get the data on energy usage efficiency improvements.
            energy_usage_efficiency: EnergyUsageEfficiency = (
                self.energy_usage_efficiency
            )

            # Set up the energy usage efficiency improvements projections for each sector in each region
            for region in self.sym_data.regions_members:
                scale_ratio: float = float(yratr_data.loc[region])

                # First do projections for consumers in each region.
                if (
                    energy_usage_efficiency.model_includes_consumption_energy_usage_efficiency
                ):
                    consumption_energy_usage_efficiency: pd.DataFrame = (
                        energy_usage_efficiency.consumption_cumulative_energy_usage_efficiency_gains
                    )
                    assert (
                        not consumption_energy_usage_efficiency.isna().any().any()
                    ), f"The consumption energy usage efficiency data includes NaN values."
                    shefc_name_prefix: str = f"SHEFC"
                    shefc_name: str = f"{shefc_name_prefix}({region})"
                    if self.sym_data.has_variables(
                        variable_name_prefix=shefc_name_prefix
                    ):
                        shefc_data: pd.DataFrame = (
                            consumption_energy_usage_efficiency.loc[
                                [region],
                                self.configuration.projection_years_column_labels,
                            ]
                        )
                        shefc_data.index = [shefc_name]
                        shefc_units: str = (
                            self.sym_data.units_for_variables_with_given_name_prefix(
                                vector_name="exo",
                                variable_name_prefix=shefc_name_prefix,
                            )
                        )
                        if "gdp" in shefc_units:
                            shefc_data /= scale_ratio
                        projections = pd.concat([projections, shefc_data], axis=0)

                # Now do projections for each sector in the region.
                regional_energy_usage_efficiency: pd.DataFrame = (
                    energy_usage_efficiency.sector_cumulative_energy_usage_efficiency_gains(
                        region=region
                    )
                )
                assert (
                    not regional_energy_usage_efficiency.isna().any().any()
                ), f"The regional energy usage efficiency data includes NaN values."
                variable_prefix_SHEF: str = "SHEF"
                for sector in self.sym_data.sectors_members:
                    shef_name: str = f"{variable_prefix_SHEF}({sector},{region})"
                    if self.sym_data.has_variables(variable_name_prefix=shef_name):
                        shef_data: pd.DataFrame = regional_energy_usage_efficiency.loc[
                            [sector], self.configuration.projection_years_column_labels
                        ]
                        shef_data.index = [shef_name]
                        shef_units: str = (
                            self.sym_data.units_for_variables_with_given_name_prefix(
                                vector_name="exo",
                                variable_name_prefix=variable_prefix_SHEF,
                            )
                        )
                        if "gdp" in shef_units:
                            shef_data /= scale_ratio
                        projections = pd.concat([projections, shef_data], axis=0)

        # Do the effective labour productivity projections.
        if self.configuration.use_effective_labour_productivity_growth_projections:
            effective_labour_productivity: EffectiveLabourProductivity = (
                self.effective_labour_productivity
            )

            # Do the potential output projections for each region.
            if self.configuration.use_potential_output_growth_projections:
                rogy: pd.DataFrame = (
                    effective_labour_productivity.potential_output_growth_rates
                )
                for region in self.sym_data.regions_members:
                    scale_ratio: float = float(yratr_data.loc[region])
                    rogy_name: str = f"{gcubed.CONSTANTS.ROGY_PREFIX}({region})"
                    if self.sym_data.has_variables(variable_name_prefix=rogy_name):
                        rogy_data: pd.DataFrame = rogy.loc[
                            [region], self.configuration.projection_years_column_labels
                        ]
                        rogy_data.index = [rogy_name]
                        rogy_units: str = (
                            self.sym_data.units_for_variables_with_given_name_prefix(
                                vector_name="exo",
                                variable_name_prefix=gcubed.CONSTANTS.ROGY_PREFIX,
                            )
                        )
                        if "gdp" in rogy_units:
                            rogy_data /= scale_ratio
                        projections = pd.concat([projections, rogy_data], axis=0)

            for region in self.sym_data.regions_members:
                scale_ratio: float = float(yratr_data.loc[region])
                regional_effective_labour_productivity: pd.DataFrame = (
                    effective_labour_productivity.effective_labour_productivity_deviations(
                        region=region
                    )
                )
                assert (
                    not regional_effective_labour_productivity.isna().any().any()
                ), f"Region {region} effective labour productivity data includes NaN values."
                variable_prefix_SHL: str = "SHL"
                for sector in self.sym_data.sectors_members:
                    shl_name: str = f"{variable_prefix_SHL}({region},{sector})"
                    if self.sym_data.has_variables(variable_name_prefix=shl_name):
                        shl_data: pd.DataFrame = (
                            regional_effective_labour_productivity.loc[
                                [sector],
                                self.configuration.projection_years_column_labels,
                            ]
                        )
                        shl_data.index = [shl_name]
                        shl_units: str = (
                            self.sym_data.units_for_variables_with_given_name_prefix(
                                vector_name="exo",
                                variable_name_prefix=variable_prefix_SHL,
                            )
                        )
                        if "gdp" in shl_units:
                            shl_data /= scale_ratio
                        projections = pd.concat([projections, shl_data], axis=0)

        projections.to_csv(
            self.configuration.exogenous_growth_and_efficiency_adjustments_file,
            index=True,
            header=True,
            float_format="%.7f",
        )
        logging.warning(
            f"Created a new baseline exogenous adjustments CSV file, {gcubed.file_summary(file_path=self.configuration.exogenous_growth_and_efficiency_adjustments_file)}."
        )
