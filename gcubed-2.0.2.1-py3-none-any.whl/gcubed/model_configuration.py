"""
This module contains the `ModelConfiguration` class.
"""

import logging
import importlib
import pandas as pd
import numpy as np
import regex as re
import os
import os.path
import sys
from gcubed.base import Base


class ModelConfiguration(Base):
    """
    ### Overview

    Provides access to model configuration details that have been
    read in from the model configuration CSV file.

    #### The configuration CSV file format

    The configuration CSV file must have at least 2 columns.
    Only the first 2 columns are processed when loading model
    configuration details.

    The fields in each row must be comma separated. No commas are
    allowed as part of the CSV file content in the first two columns.

    The following configuration settings must be included the model configuration
    file, noting that their names are case sensitive:

    - `Version`: the model version - `ModelConfiguration.version`.
    - `Build`: the model build - `ModelConfiguration.build`.
    - `SymInputFile`: the root file for the SYM model definition - `ModelConfiguration.sym_input_file`
    - `Database`: The name of the file that contains the model database - `ModelConfiguration.database_file`
    - `BaseYear`: The base year for indices in the model database - `ModelConfiguration.base_year`
    - `UserParameters`: The name of the file that contains the values for parameters that are set directly by the user - `ModelConfiguration.parameters_file`
    - `IOTables`: The name of the file that contains the Input/Output tables for each region - `ModelConfiguration.io_table_file`
    - `Productivity`: - The name of the file that contains the data about productivity growth in each sector of each region, over the projection years `ModelConfiguration.productivity_file`
    - `Population`: The name of the file that contains the data about population growth in each region, over the projection years - `ModelConfiguration.population_file`
    - `AutonomousEnergyEfficiencyImprovement`: The name of the file that contains the data about autonomous energy efficiency improvments over the projection years - `ModelConfiguration.aeei_file`
    - `CalibrationYear`: The year used to calibrate the model parameters except for the carbon coefficients - `ModelConfiguration.calibration_year`
    - `CalibrationOfCarbonCoefficientsYear`: The year used to calibrate the carbon coefficients - `ModelConfiguration.calibration_of_carbon_coefficients_year`
    - `LinearisationYear`: The year used to linearise the model for baseline projections - `ModelConfiguration.linearisation_year`
    - `FirstProjectionYear`: The first projection year for the baseline projections - `ModelConfiguration.first_projection_year`
    - `LastProjectionYear`: The last projection year - `ModelConfiguration.last_projection_year`
    - `StableManifoldTolerance`: The tolerance for small changes in the stable manifold that defines convergence to the stable manifold - `ModelConfiguration.stable_manifold_tolerance`
    - `StableManifoldMaximumIterations`: The maximum number of iterations to perform before failing to find the stable manifold - `ModelConfiguration.stable_manifold_maximum_iterations`
    - `UnitRootTolerance`: The tolerance for the unit root test (maximum value that is still treated as not greater than 1, defaults to 1.001) - `ModelConfiguration.unit_root_tolerance`
    - `ScaleTransitionMatrixToEliminateExplosiveRoots`: A switch to scale the transition matrix to eliminate explosive roots (If 1, then the state transition matrix is divided by the maximum
    modulus of its roots to ensure all roots are less than or exactly equal to 1 rather than possibly being greater than 1 by the amount allowed by the `UnitRootTolerance` setting)- `ModelConfiguration.scale_transition_matrix_to_eliminate_explosive_roots`
    - `NeutralRealInterestRate`: The global neutral real interest rate, as a decimal rather than a percentage - `ModelConfiguration.neutral_real_interest_rate`
    - `CarbonCoefficientsFile`: The name of the file that contains the carbon coefficients - `ModelConfiguration.carbon_coefficients_file`. if not specified, the coefficients are not loaded.
    - `EmissionIntensityParameterFileSuffix`: The suffix of the names of the files that contain the emission intensity coefficients - `ModelConfiguration.emissions_coefficient_file_suffix`. if not specified then the coefficients are not loaded. The usual value is `_emission_intensity_parameters.csv`
    These parameters will eventually replace the carbon coefficients.
    If provided, then the suffix is appended to a set of standard prefixes to form the full file names of the various
    emission intensity parameter files. The standard prefixes are `household`, `government`, `sector_input`, `sector_capital`, `sector_labor`, and `sector_output`.
    - `BaselineDesignFile`: The name of the file that contains the design of the baseline exogenous adjustments - `ModelConfiguration.baseline_design_file`
    - `ExogenousGrowthAndEfficiencyAdjustmentsFile`: The name of the file that contains the exogenous growth and energy efficiency adjustments - `ModelConfiguration.exogenous_growth_and_efficiency_adjustments_file`. This defaults to product.csv.
    - `EnforceAggregateConsistency`: A switch to enforce aggregate consistency in the model with a value of 1 for enforcement and 0 for non-enforcement - `ModelConfiguration.enforce_aggregate_consistency`

    The following configuration settings are optional inclusions in the model configuration
    file:

    - `LineariseAroundStrictModelSolution`: governing how model linearisation is done. See
    `ModelConfiguration.linearise_around_strict_model_solution` for details and its
    default value.

    #### Configuring a model to use a custom parameter calibration class

    To provide full control over parameter calibration, it is possible to configure the model
    to use a custom parameter calibration class.

    The custom parameters class name must be a subclass of the `Parameters` class.

    If a parameters class name is not specified in the configuration file then the model's default parameters class is used.

    If you want to use a custom parameter calibration class, then you must also include
    all three of the following additional settings in the configuration CSV file:

    - `ParametersClassFile`: A configuration setting that specifies the full absolute path to the python file
    that contains the custom parameters class definition - `ModelConfiguration.parameters_class_file`.
    - `ParametersModuleName`: A configuration setting that specifies the name of a Python module
    that contains the custom parameters class definition - `ModelConfiguration.parameters_module_name`.
    - `ParametersClassName`: A configuration setting that specifies the name of a parameters class
    to use instead of the model's default subclass of the `Parameters` class  - `ModelConfiguration.parameters_class_name`.

    """

    def __init__(self, configuration_file: str) -> None:
        """

        ### Constructor

        Initialises the model details from a modified version of the CSV files
        used by G-cubed. The information in the file is a subset of the information
        in the modeldetails.csv file and a subset of the information that is stored
        in the baseinfo.csv file.

        ### Arguments

        `configuration_file`: the relative path, from Python's
        current working directory, to the model configuration file.

        """

        if not configuration_file:
            raise Exception("A configuration file is required to create a model.")

        if not os.path.isfile(configuration_file):
            raise Exception(
                f"Configuration file {
                            configuration_file} does not exist."
            )

        # Get the directory that contains the model configuration and other related files.
        self._model_directory = os.path.abspath(
            os.path.dirname(os.path.realpath(configuration_file))
        )

        data: pd.DataFrame = pd.read_csv(configuration_file, header=None)
        self.__load_configuration_details(configuration_details=data)
        self.__validate()

        logging.info(
            f"Loaded the configuration details for model {
                self.version} {self.build}."
        )

        np.set_printoptions(
            suppress=False, formatter={"float": lambda x: "{0:0.12f}".format(x)}
        )
        pd.set_option("display.max_rows", None)
        pd.set_option("display.max_columns", None)
        pd.set_option("display.width", 2000)

    @property
    def model_directory(self) -> str:
        """
        The root directory of the model, where the configuration CSV file is located.
        """
        return self._model_directory

    @property
    def data_directory(self) -> str:
        """
        The data directory of the model, where the model's data files are stored.
        """
        return os.path.join(self.model_directory, "data")

    @property
    def sym_directory(self) -> str:
        """
        The sym directory of the model, where the model's sym files are stored
        and where the Python script and other SYM processor outputs are stored
        after the SYM processor has been run.
        """
        return os.path.join(self.model_directory, "sym")

    @property
    def simulations_directory(self) -> str:
        """
        This directory is where all simulation experiment definitions
        are stored. Each experiment has its own root directory that
        is a subdirectory of the simulations directory.
        """
        return os.path.join(self.model_directory, "simulations")

    @property
    def diagnostics_directory(self) -> str:
        """
        The diagnostics directory is where all model execution diagnostics are saved.
        """
        return os.path.join(self.model_directory, "diagnostics")

    @property
    def chartpacks_directory(self) -> str:
        """
        This directory is where all chartpacks are saved.
        """
        return os.path.join(self.model_directory, "chartpacks")

    @property
    def python_directory(self) -> str:
        """
        This directory is where all python scripts to run model experiments are saved.
        """
        return os.path.join(self.model_directory, "python")

    @property
    def version(self) -> str:
        """
        The unique string identifying the version of the model.
        This influences the way that the model parameters are calibrated.

        This configuration property must be specified.

        Conventionally the model version is a number plus single letter string,
        where number represents the number of sectors, and the letter relates to
        specific regions in the model. For example:

        2R is the 2 region/2 sector model

        20R is the 2 region/20 sector model

        20C is the 10 region/20 sector model used for carbon emissions modelling.

        The name for this property in the configuration file is `Version`.
        """
        if not hasattr(self, "_version"):
            raise Exception(
                "You must specify the model version in the model configuration."
            )
        return self._version

    @property
    def build(self) -> str:
        """
        The string identifying the build of the model.
        This influences the way that the model parameters are calibrated.

        This configuration property must be specified.

        The model build must start with an integer number but it can also
        include a suffix that consists of digits and letters (e.g. 123logv13).

        The name for this property in the configuration file is `Build`.
        """
        if not hasattr(self, "_build"):
            raise Exception(
                "You must specify the model build in the model configuration."
            )
        return self._build

    @property
    def build_number(self) -> int:
        """
        The integer indicating which build of the model is being used.
        A given model version can have many different builds.

        This configuration property is inferred from the `Build` value in
        the model configuration file. See `ModelConfiguration.build` for details
        of the `Build` configuration setting.
        """
        if not hasattr(self, "_build_number"):
            raise Exception(
                "The model build in the model specification must start with a positive integer."
            )
        return self._build_number

    @property
    def sym_input_file(self):
        """
        The absolute path and name of the root
        SYM file to process with the sym processor
        to produce the sym details (lists of variables and
        Python implementation of the model equations etc.)
        for the model and the Python implementation of the
        model equations.

        Note that the SYM definition of a model can be split among several files with the
        root file including the others to form the complete model definition. Only the
        name of the root SYM file is returned.

        This configuration property must be specified.

        The name for this property in the configuration file is "SymInputFile".
        """
        return os.path.abspath(os.path.join(self.sym_directory, self._sym_input_file))

    @property
    def sym_output_filename_prefix(self):
        """
        The equations Python module that is imported by the Lineariser.
        """
        return f"model_{self.version}_{self.build}"

    @property
    def fully_qualified_equations_module_name(self):
        """
        The fully qualified module name required to import the
        SYM generated Python equations module.
        """
        return f"model.{self.version}.{self.build}.sym.{
                self.sym_output_filename_prefix}"

    @property
    def equations_python_module_file(self):
        """
        The name of the file that is the Python equations module for
        this model.
        """
        return os.path.abspath(
            os.path.join(
                self.sym_directory,
                f"{
                         self.sym_output_filename_prefix}.py",
            )
        )

    @property
    def sym_output_file_path_and_prefix(self):
        """
        The prefix used for all files output by the SYM processor.
        """
        return os.path.abspath(
            os.path.join(self.sym_directory, self.sym_output_filename_prefix)
        )

    @property
    def varmap_file(self) -> str:
        """
        The absolute path to the SYM processor generated varmap file.
        """
        return f"{self.sym_output_file_path_and_prefix}_varmap.csv"

    @property
    def eqnmap_file(self) -> str:
        """
        The absolute path to the SYM processor generated eqnmap file.

        The file containing a listing of left and right hand side variables
        in the model equations. the LHS variable comes first, as a name of
        the vector (column 1), and the index in that vector (column 2). Then each
        RHS variable appears, again as the vector name in column 2 and the index
        in that vector in column 2.

        This information is used to populate a dictionary with keys being the vector
        and index tuple for each RHS variable and the value being a list of of
        vector name, vector index tuples, one for each equation that the RHS variable
        occurs in. That dictionary then drives the equation evaluations used in model
        linearisation.
        """
        return f"{self.sym_output_file_path_and_prefix}_eqnmap.csv"

    @property
    def variables_info_file(self) -> str:
        """
        The absolute path to the SYM processor generated varinfo file.
        """
        return f"{self.sym_output_file_path_and_prefix}_varinfo.csv"

    @property
    def variables_file(self) -> str:
        """
        The absolute path to the SYM processor generated vars file.
        """
        return f"{self.sym_output_file_path_and_prefix}_vars.csv"

    @property
    def model_summary_file(self) -> str:
        """
        The absolute path to the SYM processor generated lis file.

        This is not used by the Python implementation.
        """
        return f"{self.sym_output_file_path_and_prefix}.lis"

    @property
    def database_file(self) -> str:
        """
        The absolute path to the model's database CSV file.

        The database file contains the historical data for
        all of the variables in the model.
        """
        if not hasattr(self, "_database_file"):
            return None
        return os.path.abspath(os.path.join(self.data_directory, self._database_file))

    @property
    def io_table_file(self) -> str:
        """
        The absolute path to the model's input-output tables CSV file.

        This file contains the tables for all regions in the model.

        An example value is `IOTABLESvR2011.csv`.

        The name for this property in the configuration file
        is `IOTables`.
        """
        if not hasattr(self, "_io_table_file"):
            return None
        return os.path.abspath(os.path.join(self.data_directory, self._io_table_file))

    @property
    def parameters_file(self) -> str:
        """
        The absolute path to the CSV file containing the values
        of the parameters that are set by the user rather than
        by calibration using database and IO table information.

        The name for this property in the configuration file
        is `UsersParameters`.
        """
        if not hasattr(self, "_parameters_file"):
            return None
        return os.path.abspath(os.path.join(self.data_directory, self._parameters_file))

    @property
    def productivity_file(self) -> str:
        """
        The absolute path to the CSV file containing the information
        needed to do region/sector productivity growth projections.

        The name for this property in the configuration file
        is `Productivity`.
        """
        if not hasattr(self, "_productivity_file"):
            return None
        return os.path.abspath(
            os.path.join(self.data_directory, self._productivity_file)
        )

    @property
    def population_file(self) -> str:
        """
        The absolute path to the CSV file containing the information
        needed to do region population growth projections.

        The name for this property in the configuration file
        is `Population`.
        """
        if not hasattr(self, "_population_file"):
            return None
        return os.path.abspath(os.path.join(self.data_directory, self._population_file))

    @property
    def aeei_file(self) -> str:
        """
        The absolute path to the CSV file containing the information
        needed to do projections of region/sector energy efficiency improvements.

        The name for this property in the configuration file
        is `AutonomousEnergyEfficiencyImprovement`.
        """
        if not hasattr(self, "_aeei_file"):
            return None
        return os.path.abspath(os.path.join(self.data_directory, self._aeei_file))

    @property
    def carbon_coefficients_file(self) -> str:
        """
        The name of the CSV file containing the information
        about carbon coefficients. This file is expected to be
        in the `data` directory of the model.

        This value is optional. If it not specified, then the standard
        emissions coefficients are expected to feature in the model.
        """
        if not hasattr(self, "_carbon_coefficients_file"):
            return None
        return os.path.abspath(
            os.path.join(self.data_directory, self._carbon_coefficients_file)
        )

    @property
    def has_emission_intensity_parameters(self) -> bool:
        """
        `True` if the model has emission intensity parameters and `False` if the model does not have emission intensity parameters.
        """
        return hasattr(self, "_emission__intensity_file_suffix")

    @property
    def household_emission_intensity_file(self) -> str:
        """
        The name of the CSV file containing the information
        about household emission intensity parameters.
        This file is expected to be
        in the `data` directory of the model.

        This value is optional. If it not specified, then the model
        does not use the coefficients.
        """
        if not self.has_emission_intensity_parameters:
            return None
        return os.path.abspath(
            os.path.join(
                self.data_directory,
                f"household{self._emission__intensity_file_suffix}",
            )
        )

    @property
    def government_emission_intensity_file(self) -> str:
        """
        The name of the CSV file containing the information
        about government emission intensity parameters.
        This file is expected to be
        in the `data` directory of the model.

        This value is optional. If it not specified, then the model
        does not use the coefficients.
        """
        if not self.has_emission_intensity_parameters:
            return None
        return os.path.abspath(
            os.path.join(
                self.data_directory,
                f"government{self._emission__intensity_file_suffix}",
            )
        )

    @property
    def sector_input_emission_intensity_file(self) -> str:
        """
        The name of the CSV file containing the information
        about sector input emission intensity parameters.
        This file is expected to be
        in the `data` directory of the model.

        This value is optional. If it not specified, then the model
        does not use the coefficients.
        """
        if not self.has_emission_intensity_parameters:
            return None
        return os.path.abspath(
            os.path.join(
                self.data_directory,
                f"sector_input{self._emission__intensity_file_suffix}",
            )
        )

    @property
    def sector_capital_emission_intensity_file(self) -> str:
        """
        The name of the CSV file containing the information
        about sector capital emission intensity parameters.
        This file is expected to be
        in the `data` directory of the model.

        This value is optional. If it not specified, then the model
        does not use the coefficients.
        """
        if not self.has_emission_intensity_parameters:
            return None
        return os.path.abspath(
            os.path.join(
                self.data_directory,
                f"sector_capital{self._emission__intensity_file_suffix}",
            )
        )

    @property
    def sector_labor_emission_intensity_file(self) -> str:
        """
        The name of the CSV file containing the information
        about sector labor emission intensity parameters.
        This file is expected to be
        in the `data` directory of the model.

        This value is optional. If it not specified, then the model
        does not use the coefficients.
        """
        if not self.has_emission_intensity_parameters:
            return None
        return os.path.abspath(
            os.path.join(
                self.data_directory,
                f"sector_labor{self._emission__intensity_file_suffix}",
            )
        )

    @property
    def sector_output_emission_intensity_file(self) -> str:
        """
        The name of the CSV file containing the information
        about sector output emission intensity parameters.
        This file is expected to be
        in the `data` directory of the model.

        This value is optional. If it not specified, then the model
        does not use the coefficients.
        """
        if not self.has_emission_intensity_parameters:
            return None
        return os.path.abspath(
            os.path.join(
                self.data_directory,
                f"sector_output{self._emission__intensity_file_suffix}",
            )
        )

    @property
    def modprod_file(self) -> str:
        """
        The file containing the growth rate projections by sector and region
        (equivalent to the modprod.csv file in the Ox implementation).

        This value defaults to modprod.csv
        """
        if not hasattr(self, "_modprod_file"):
            return os.path.abspath(
                os.path.join(
                    self.data_directory,
                    "modprod.csv",
                )
            )
        return os.path.abspath(
            os.path.join(
                self.data_directory,
                self._modprod_file,
            )
        )

    @property
    def exogenous_growth_and_efficiency_adjustments_file(self) -> str:
        """
        The file containing the exogenous growth and energy efficiency adjustments.

        This value defaults to product.csv
        """
        if not hasattr(self, "_exogenous_growth_and_efficiency_adjustments_file"):
            return os.path.abspath(
                os.path.join(
                    self.data_directory,
                    "product.csv",
                )
            )
        return os.path.abspath(
            os.path.join(
                self.data_directory,
                self._exogenous_growth_and_efficiency_adjustments_file,
            )
        )

    @property
    def baseline_design_file(self) -> str:
        """
        The name of the CSV file containing the design of the baseline exogenous adjustments.
        This file is expected to be in the `data` directory of the model if it exists.

        If the file does not exist, then the baseline projections
        involve no adjustments to exogenous variables.
        """
        if not hasattr(self, "_baseline_design_file"):
            return None
        return os.path.abspath(
            os.path.join(self.data_directory, self._baseline_design_file)
        )

    @property
    def has_baseline_design_file(self) -> bool:
        """
        `True` if the model has a baseline design file and `False` if the model does not have a baseline design file.
        """
        return self.baseline_design_file is not None

    @property
    def linearisation_year(self):
        """
        The year to use when selecting the database data for model linearisation
        purposes.

        e.g. `2011`.

        The model can be relinearised in projection years, depending on how the model is
        run and how simulation experiments are designed. This is still an experimental feature
        of the model.

        The name for this property in the configuration file is
        `LinearisationYear`.
        """
        return self._linearisation_year

    @linearisation_year.setter
    def linearisation_year(self, value: int):
        """

        ### Overview

        Updates the year to use when selecting the database data for model linearisation
        purposes.

        Modification of the linearisation year is used for relinearisation purposes.

        ### Arguments

        `value`: the new year to use when selecting the database data for model linearisation.

        ### Exceptions

        Raises exceptions if the linearisation year is invalid.

        Updates to the linearisation year are used to adjust the linearisation year to
        a year in which the model is being relinearised, after the original first
        projection year.

        """
        assert value is not None, f"The linearisation year must be specified."
        assert isinstance(value, int), f"The linearisation year must be an integer."
        assert (
            value >= self.original_first_projection_year
        ), f"The linearisation year must be greater than or equal to the original first projection year, {self.original_first_projection_year}."
        self._linearisation_year = value

    @property
    def calibration_year(self):
        """
        The year to use when selecting the database data for model parameter calibration
        purposes.

        e.g. `2011`.

        This is used to calibrate the values of all parameters except those set by the
        user in the `ModelConfiguration.parameters_file` and the carbon emissions coefficients.
        The carbon coefficients can be linearised in a different year, specified via
        `ModelConfiguration.calibration_of_carbon_coefficients_year`

        The name for this property in the configuration file is
        `CalibrationYear`.
        """
        return self._calibration_year

    @property
    def calibration_of_carbon_coefficients_year(self):
        """
        The year to use when selecting the database data
        for model parameter calibration purposes for the
        carbon emissions related parameters.

        e.g. `2018`.

        The name for this property in the configuration file is
        `CalibrationOfCarbonCoefficientsYear`.

        """
        return self._calibration_of_carbon_coefficients_year

    @property
    def base_year(self):
        """
        The year in which all indices are based at 1 (so their log values are 0).
        Typically, this is chosen to be the first projection year, noting that
        the first year of projections are matched up to observed data in that first
        year.

        If the database file has indexes with a base year of 2018, then the configuration
        file would set this property value to `2018`. Note that this property needs to describe
        the actual database file. It should not be a specification of the base year that you
        want to use. Other properties manage how the base year is altered after the data is
        loaded.

        e.g. 2018 if the provided database file has its base year in 2018.

        Databases can be rebased to different years.

        The name for this property in the configuration file
        is `BaseYear`.
        """
        return self._base_year

    @property
    def original_first_projection_year(self):
        """
        The original first projection year. This is tracked
        because, for projections that iterate forward through the projection years,
        the first projection year will be updated with each iteration.

        This property is set equal to the value of the
        `FirstProjectionYear` property in the configuration file.

        It must not be specified
        independently of the `FirstProjectionYear`.
        .
        """
        return self._original_first_projection_year

    @property
    def first_projection_year(self):
        """
        The first year that projections are to be generated for.
        Note that for baseline projections, the projections start
        in a year where the model's database has data, so the projections
        can be lined up with the observed data in the database.

        The name for this property in the configuration file is
        `FirstProjectionYear`.
        """
        return self._first_projection_year

    @first_projection_year.setter
    def first_projection_year(self, value: int):
        """
        Updates the configuration to have a new first projection year,
        updating the linearisation year also but not changing the
        original first projection year.

        The first projection year must only ever be incremented.
        """
        assert value is not None
        assert isinstance(value, int)
        assert value > self.first_projection_year
        self._first_projection_year = value
        self._linearisation_year = value

    @property
    def last_projection_year(self):
        """
        The last year for which data will be projected.

        The name for this property in the configuration file is
        `LastProjectionYear`.
        """
        return self._last_projection_year

    @property
    def last_publishable_projection_year(self):
        """
        The last year for which publishable projection data will be made available.

        It defaults to 30 years before the last projection year.

        The name for this property in the configuration file is
        `LastPublishableProjectionYear`.

        The value must be between the first projection year and the last projection year, inclusive.
        """
        if hasattr(self, "_last_publishable_projection_year"):
            return self._last_publishable_projection_year
        return self._last_projection_year - 30

    @property
    def projection_years(self) -> list[int]:
        """
        The list of integer years from the first projection
        year to the last projection year.
        """
        return range(self.first_projection_year, self.last_projection_year + 1)

    @property
    def projection_years_column_labels(self) -> list[str]:
        """
        A list of string representations of the years from the
        first projection year to the last projection year.
        """
        return [str(x) for x in self.projection_years]

    @property
    def original_projection_years_column_labels(self) -> list[str]:
        """
        A list of string representations of the years from the original
        first projection year to the last projection year.
        """
        return [
            str(x)
            for x in range(
                self.original_first_projection_year, self.last_projection_year + 1
            )
        ]

    @property
    def projection_years_count(self) -> int:
        """
        The number of projection years, from the first to the last.
        """
        return self.last_projection_year - self.first_projection_year + 1

    @property
    def stable_manifold_tolerance(self):
        """
        The maximum size of the change in the stable manifold estimate
        allowed during the search for the stable manifold.

        This configuration value is used to ensure that the search for a stable
        manifold terminates within a reasonable period of time. Consider
        making this value larger if the search is not converging.

        If not specified in the configuration file, then this model configuration
        property defaults to 1e-10.

        The name for this property in the configuration file
        is `StableManifoldTolerance`.
        """
        if not hasattr(self, "_stable_manifold_tolerance"):
            self.self._stable_manifold_tolerance = 1e-10
        return self._stable_manifold_tolerance

    @property
    def stable_manifold_maximum_iterations(self):
        """
        The maximum number of iterations allowed when searching
        for the stable manifold for the model. If this number is reached
        without convergence of the stable manifold, then the model cannot
        be used for projection purposes.

        This configuration value is used to ensure that the search for a stable
        manifold terminates within a reasonable period of time.

        If not specified in the configuration file, then this model configuration
        property defaults to 1000.

        The name for this property in the configuration file
        is `StableManifoldMaximumIterations`.
        """
        if not hasattr(self, "_stable_manifold_maximum_iterations"):
            self.self._stable_manifold_maximum_iterations = 1000
        return self._stable_manifold_maximum_iterations

    @property
    def unit_root_tolerance(self) -> float:
        """
        The tolerance for the unit root test (maximum value that is still treated as not greater than 1, defaults to 1.001).

        This value should not be set to a value that is meaningfully greater than 1.0.

        The name for this property in the configuration file
        is `UnitRootTolerance`.
        """
        if not hasattr(self, "_unit_root_tolerance"):
            self._unit_root_tolerance = 1.001
        return self._unit_root_tolerance

    @property
    def scale_transition_matrix_to_eliminate_explosive_roots(self) -> bool:
        """
        A switch to scale the transition matrix to eliminate explosive roots (If `True`, then the state transition matrix is divided by the maximum
        modulus of its roots to ensure all roots are less than or exactly equal to 1 rather than possibly being greater than 1 by the amount
        allowed by the `UnitRootTolerance` setting).

        This property defaults to `False`.

        The name for this property in the configuration file
        is `ScaleTransitionMatrixToEliminateExplosiveRoots`.
        """
        if not hasattr(self, "_scale_transition_matrix_to_eliminate_explosive_roots"):
            self._scale_transition_matrix_to_eliminate_explosive_roots = False
        return self._scale_transition_matrix_to_eliminate_explosive_roots

    @property
    def neutral_real_interest_rate(self):
        """
        The global neutral real interest rate as a decimal, so a value of 3.6% would
        be specified in the model configuration as 0.036.

        This rate influences model linearisation and projections.
        Linearisation is done around a set of varible values that
        that force the interest rates in the model to be equal to this value.
        Adjustments are then done to the projections to have interest rates
        in the first projection year restored to their original values
        as at the start of the baseline projections.

        The name for this property in the configuration file
        is `NeutralRealInterestRate`.
        """
        if not hasattr(self, "_neutral_real_interest_rate"):
            raise Exception("You must include a global neutral real interest rate.")
        return self._neutral_real_interest_rate

    @property
    def parameters_module_name(self) -> str:
        """
        The name of the Python module that contains the parameters class definition.

        This is always `parameters_<VERSION>_<BUILD>`, where `<VERSION>` is the model version
        and `<BUILD>` is the model build.
        """
        return f"parameters_{self.version}_{self.build}"

    @property
    def parameters_class_file(self) -> str:
        """
        The path to the file containing the parameters calibration class.

        This is a file called `parameters_<VERSION>_<BUILD>.py` in
        the model's Python directory where `<VERSION>` is the model version
        and `<BUILD>` is the model build.
        """
        return os.path.abspath(
            os.path.join(
                self.python_directory,
                f"parameters_{
                    self.version}_{self.build}.py",
            )
        )

    @property
    def parameters_class_name(self) -> str:
        """
        The name of the class to use for calibrating the model parameters.

        This is always `Parameters<VERSION><BUILD>`, where `<VERSION>` is the model version
        and `<BUILD>` is the model build.
        """
        return f"Parameters{self.version}{self.build}"

    @property
    def linearise_around_strict_model_solution(self) -> bool:
        """
        `True` if the model linearisation is done around a strict model
        solution and False if the model linearisation is to instead be done
        around actual data values sourced from the model database or from a
        previous model projection. Set this to False for standard linearisation
        as has been done for G-Cubed for decades. Set this to True if the
        actual data values are to be adjusted to find similar values that exactly
        solve all of the equations in the model before then linearising around
        those similar values.

        This property defaults to `False` unless overridden in the model configuration.

        This property can be modified after the model has been loaded if a different
        behaviour is required.

        The name for this property in the configuration file
        is `LineariseAroundStrictModelSolution`.
        """
        if not hasattr(self, "_linearise_around_strict_model_solution"):
            self._linearise_around_strict_model_solution = False
        return self._linearise_around_strict_model_solution

    @linearise_around_strict_model_solution.setter
    def linearise_around_strict_model_solution(self, value):
        """
        ### Overview

        Set the value to True if the model linearisation is done around a strict model
        solution and False if the model linearisation is to instead be done
        around actual data values sourced from the model database or from a
        previous model projection.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._linearise_around_strict_model_solution = value

    @property
    def use_energy_usage_efficiency_projections(self) -> bool:
        """
        `True if the model should use energy usage efficiency improvements when
        doing exogenous variable projections and `False` if the model should
        instead set the projections of the exogenous variables for energy usage
        efficiency improvements to zero.

        Defaults to `True`.

        If `True`, the data on energy usage efficiency improvements is sourced
        from the CSV file specified by the `aeei_file` property in the model
        configuration file.
        """
        if not hasattr(self, "_use_energy_usage_efficiency_projections"):
            self._use_energy_usage_efficiency_projections = True
        return self._use_energy_usage_efficiency_projections

    @use_energy_usage_efficiency_projections.setter
    def use_energy_usage_efficiency_projections(self, value: bool):
        """
        Set the switch that controls whether to use zero energy usage efficiency improvements when
        setting up exogenous variable projections for the model (These are used for the baseline
        and all projections that build upon that baseline).

        Valid values are `True`, to use the data on energy usage efficiency improvements, or `False`
        to set the projections of the exogenous variable for energy usage efficiency improvements to zero.

        TODO: Add this switch to the configuration file once its value has been proved.
        Until then, create the model configuration and adjust the value once that has been
        done but before the model is created using the model configuration.
        """
        assert (
            value is not None
        ), f"use_energy_usage_efficiency_projections must be True or False."
        assert isinstance(
            value, bool
        ), f"use_energy_usage_efficiency_projections must be True or False."
        self._use_energy_usage_efficiency_projections = value

    @property
    def use_potential_output_growth_projections(self) -> bool:
        """
        `True if the model should use potential output growth when
        doing exogenous variable projections and `False` if the model should
        instead set the projections of the exogenous variables for
        potential output growth to zero.

        Defaults to `True`.

        If `True`, the data on potential output growth is sourced
        from the files specified in the model configuration.
        """
        if not hasattr(self, "_use_potential_output_growth_projections"):
            self._use_potential_output_growth_projections = True
        return self._use_potential_output_growth_projections

    @use_potential_output_growth_projections.setter
    def use_potential_output_growth_projections(self, value: bool):
        """
        Set the switch that controls whether to use potential output growth projections when
        setting up exogenous variable projections for the model (These are used for the baseline
        and all projections that build upon that baseline).

        Valid values are `True`, to use the data on potential output growth projections, or `False`
        to set the projections of the exogenous variables for potential output growth to zero.

        TODO: Add this switch to the configuration file once its value has been proved.
        Until then, create the model configuration and adjust the value once that has been
        done but before the model is created using the model configuration.
        """
        assert (
            value is not None
        ), f"use_potential_output_growth_projections must be True or False."
        assert isinstance(
            value, bool
        ), f"use_potential_output_growth_projections must be True or False."
        self._use_potential_output_growth_projections = value

    @property
    def use_effective_labour_productivity_growth_projections(self) -> bool:
        """
        `True if the model should use effective labour productivity growth projections when
        doing exogenous variable projections and `False` if the model should
        instead set the projections of the exogenous variables for
        effective labour growth to zero.

        Defaults to `True`.

        If `True`, the data on effective labour productivity growth is sourced
        from the files specified in the model configuration.
        """
        if not hasattr(self, "_use_effective_labour_productivity_growth_projections"):
            self._use_effective_labour_productivity_growth_projections = True
        return self._use_effective_labour_productivity_growth_projections

    @use_effective_labour_productivity_growth_projections.setter
    def use_effective_labour_productivity_growth_projections(self, value: bool):
        """
        Set the switch that controls whether to use effective labour productivity growth projections when
        setting up exogenous variable projections for the model (These are used for the baseline
        and all projections that build upon that baseline).

        Valid values are `True`, to use the data on effective labour productivity growth projections, or `False`
        to set the projections of the exogenous variables for effective labour growth to zero.

        TODO: Add this switch to the configuration file once its value has been proved.
        Until then, create the model configuration and adjust the value once that has been
        done but before the model is created using the model configuration.
        """
        assert (
            value is not None
        ), f"use_effective_labour_productivity_growth_projections must be True or False."
        assert isinstance(
            value, bool
        ), f"use_effective_labour_productivity_growth_projections must be True or False."
        self._use_effective_labour_productivity_growth_projections = value

    @property
    def enforce_aggregate_consistency(self) -> bool:
        """
        `True` if the model should enforce aggregate consistency and `False` if the model
        should not enforce aggregate consistency. Aggregates relate to GDP and high-level
        components and they relate to emissions.

        Defaults to `False`.

        Only if `True`, the model will enforce aggregate consistency in the model's projections.

        """
        if not hasattr(self, "_enforce_aggregate_consistency"):
            self._enforce_aggregate_consistency = False
        return self._enforce_aggregate_consistency

    def __load_configuration_details(self, configuration_details: pd.DataFrame):
        """

        ### Overview

        Iterates over the configuration details read in from the CSV configuration
        file, populating the properties of this ModelConfiguration.

        ### Arguments

        configuration_details (pd.DataFrame): The `Panda` dataframe populated by loading
        the CSV model configuration file.

        The CSV file should have the configuration property name in the first column.

        The CSV file should have the configuration property value in the second column.

        All other columns are ignored and so they can be used for documentation purposes.
        """

        for row in configuration_details.itertuples(index=False):
            match row[0]:
                case "Version":
                    self._version: str = str(row[1])
                case "Build":
                    self._build: str = str(row[1])
                    match = re.search(r"^\d+", self.build)
                    if match:
                        self._build_number: int = int(match.group(0))
                    else:
                        raise Exception(
                            "The model build must start with a positive integer."
                        )
                case "SymInputFile":
                    self._sym_input_file: str = row[1]
                case "UserParameters":
                    self._parameters_file: str = row[1]
                case "IOTables":
                    self._io_table_file: str = row[1]
                case "Database":
                    self._database_file: str = row[1]
                case "Productivity":
                    self._productivity_file: str = row[1]
                case "Population":
                    self._population_file: str = row[1]
                case "AutonomousEnergyEfficiencyImprovement":
                    self._aeei_file: str = row[1]
                case "LinearisationYear":
                    self._linearisation_year: int = int(row[1])
                case "CalibrationYear":
                    self._calibration_year: int = int(row[1])
                case "CalibrationOfCarbonCoefficientsYear":
                    self._calibration_of_carbon_coefficients_year: int = int(row[1])
                case "BaseYear":
                    self._base_year: int = int(row[1])
                case "FirstProjectionYear":
                    self._first_projection_year: int = int(row[1])
                    self._original_first_projection_year: int = (
                        self.first_projection_year
                    )
                case "LastProjectionYear":
                    self._last_projection_year: int = int(row[1])
                case "LastPublishableProjectionYear":
                    self._last_publishable_projection_year: int = int(row[1])
                case "StableManifoldTolerance":
                    self._stable_manifold_tolerance = float(row[1])
                case "StableManifoldMaximumIterations":
                    self._stable_manifold_maximum_iterations = int(row[1])
                case "UnitRootTolerance":
                    self._unit_root_tolerance = float(row[1])
                case "ScaleTransitionMatrixToEliminateExplosiveRoots":
                    self._scale_transition_matrix_to_eliminate_explosive_roots = bool(
                        row[1]
                    )
                case "NeutralRealInterestRate":
                    self._neutral_real_interest_rate = float(row[1])
                case "LineariseAroundStrictModelSolution":
                    self._linearise_around_strict_model_solution = bool(row[1])
                case "ParametersClassFile":
                    self._parameters_class_file = str(row[1])
                case "ParametersModuleName":
                    self._parameters_module_name = str(row[1])
                case "ParametersClassName":
                    self._parameters_class_name = str(row[1])
                case "ModprodFile":
                    self._modprod_file = str(row[1])
                case "ExogenousGrowthAndEfficiencyAdjustmentsFile":
                    self._exogenous_growth_and_efficiency_adjustments_file = str(row[1])
                case "BaselineDesignFile":
                    self._baseline_design_file = str(row[1])
                case "CarbonCoefficientsFile":
                    self._carbon_coefficients_file = str(row[1])
                case "EmissionIntensityParameterFileSuffix":
                    self._emission__intensity_file_suffix = str(row[1])
                case "ExogenousGrowthAndEfficiencyAdjustmentsFile":
                    self._exogenous_growth_and_efficiency_adjustments_file = str(row[1])
                case "BaselineDesignFile":
                    self._baseline_design_file = str(row[1])
                case "EnforceAggregateConsistency":
                    self._enforce_aggregate_consistency = bool(int(row[1]))
                    logging.info(
                        f"Enforcing aggregates consistency in publishable results? {
                            self.enforce_aggregate_consistency}"
                    )
                case _:
                    logging.warning(
                        f"Configuration parameter {row[0]} is not recognised."
                    )

    def __validate(self):
        # Check we have a model version and a model build number.
        assert self.version is not None
        assert self.build is not None
        assert self.build_number is not None
        if self.build_number <= 0:
            raise Exception(
                f"The model build must start with a positive integer. It starts with {
                    self.build_number}."
            )

        # Check that all expected directories exist
        assert os.path.isdir(
            self.model_directory
        ), f"Could not find the model directory: {self.model_directory}"
        assert os.path.isdir(
            self.data_directory
        ), f"Could not find the data directory: {self.data_directory}"
        assert os.path.isdir(
            self.sym_directory
        ), f"Could not find the sym directory: {self.sym_directory}"

        if not os.path.isdir(self.diagnostics_directory):
            try:
                os.makedirs(self.diagnostics_directory)
            except Exception as e:
                raise Exception(
                    f"Could not set up the diagnostics directory: {
                        self.diagnostics_directory}"
                )
        if not os.path.isdir(self.chartpacks_directory):
            try:
                os.makedirs(self.chartpacks_directory)
            except Exception as e:
                raise Exception(
                    f"Could not set up the chartpacks directory: {
                        self.chartpacks_directory}"
                )
        assert os.path.isdir(
            self.simulations_directory
        ), f"Could not find the simulations directory: {self.simulations_directory}"
        assert os.path.isdir(
            self.python_directory
        ), f"Could not find the Python directory: {self.python_directory}"

        if not os.path.exists(self.diagnostics_directory):
            os.makedirs(self.diagnostics_directory)
            assert os.path.exists(
                self.diagnostics_directory
            ), f"Failed to create the model diagnostics directory {self.diagnostics_directory}."
        assert os.path.isdir(
            self.diagnostics_directory
        ), f"{
            self.diagnostics_directory} exists but is not a directory."

        assert (
            self.last_publishable_projection_year <= self.last_projection_year
        ), f"The last publishable projection year ({self.last_publishable_projection_year}) must be less than or equal to the last projection year ({self.last_projection_year})."
        assert (
            self.last_publishable_projection_year >= self.first_projection_year
        ), f"The last publishable projection year ({self.last_publishable_projection_year}) must be greater than or equal to the first projection year ({self.first_projection_year})."

        # Check that all of the files named in the configuration exist.
        assert os.path.isfile(
            self.sym_input_file
        ), f"Could not find the sym_input_file: {self.sym_input_file}"

        if not os.path.isfile(self.varmap_file):
            raise Exception(
                f"Could not find the varmap file generated by the SYM processor: {
                    self.varmap_file}"
            )
        assert os.path.isfile(
            self.varmap_file
        ), f"Could not find the varmap file: {self.varmap_file}"
        assert os.path.isfile(
            self.eqnmap_file
        ), f"Could not find the eqnmap file: {self.eqnmap_file}"
        assert os.path.isfile(
            self.variables_info_file
        ), f"Could not find the variables info file: {self.variables_info_file}"
        assert os.path.isfile(
            self.model_summary_file
        ), f"Could not find the model summary file: {self.model_summary_file}"
        assert os.path.isfile(
            self.equations_python_module_file
        ), f"Could not find the equations Python file: {self.equations_python_module_file}"
        if not os.path.isfile(self.database_file):
            logging.warning(
                f"Could not find the database file: {
                    self.database_file}. This will cause an error if you are trying to run the model."
            )
        assert os.path.isfile(
            self.io_table_file
        ), f"Could not find the IO table file: {self.io_table_file}"
        assert os.path.isfile(
            self.parameters_file
        ), f"Could not find the parameters file: {self.parameters_file}"
        assert os.path.isfile(
            self.productivity_file
        ), f"Could not find the productivity file: {self.productivity_file}"
        assert os.path.isfile(
            self.population_file
        ), f"Could not find the population file: {self.population_file}"

        # Check optional files if they are in the configuration.
        if self.carbon_coefficients_file is not None:
            assert os.path.isfile(
                self.carbon_coefficients_file
            ), f"The carbon coefficients file {self._carbon_coefficients_file} does not exist."

        if self.has_emission_intensity_parameters:
            assert os.path.isfile(
                self.household_emission_intensity_file
            ), f"The household emission intensity file {self.household_emission_intensity_file} does not exist."

            assert os.path.isfile(
                self.government_emission_intensity_file
            ), f"The government emission intensity file {self.government_emission_intensity_file} does not exist."

            assert os.path.isfile(
                self.sector_input_emission_intensity_file
            ), f"The sector input emission intensity file {self.sector_input_emission_intensity_file} does not exist."

            assert os.path.isfile(
                self.sector_capital_emission_intensity_file
            ), f"The sector capital emission intensity file {self.sector_capital_emission_intensity_file} does not exist."

            assert os.path.isfile(
                self.sector_labor_emission_intensity_file
            ), f"The sector labor emission intensity file {self.sector_labor_emission_intensity_file} does not exist."

            assert os.path.isfile(
                self.sector_output_emission_intensity_file
            ), f"The sector output emission intensity file {self.sector_output_emission_intensity_file} does not exist."

        if self.baseline_design_file is not None:
            assert os.path.isfile(
                self.baseline_design_file
            ), f"The baseline design file {self.baseline_design_file} is specified but does not exist."

        # Validate the custom parameter calibration class details if they are in the configuration.
        assert os.path.exists(
            self.parameters_class_file
        ), f"The custom parameter calibration class file {self.parameters_class_file} does not exist."
        assert os.path.isfile(
            self.parameters_class_file
        ), f"The custom parameter calibration class file path {self.parameters_class_file} is not a file."
        try:
            if self.python_directory not in sys.path:
                sys.path.insert(0, self.python_directory)
            module = importlib.import_module(f"{self.parameters_module_name}")
            assert hasattr(
                module, self.parameters_class_name
            ), f"The module {self.parameters_module_name} in {self.parameters_class_file} does not include a definition for a parameters calibration class {self.parameters_class_name}."
        except Exception as e:
            assert (
                False
            ), f"Failed to import the {self.parameters_class_name} class. Check the model's python/parameters_{self.version}_{self.build}.py file where it is required to be defined."

        sys.path.append(self.sym_directory)
        equations_module = importlib.import_module(self.sym_output_filename_prefix)
        assert equations_module is not None
        assert getattr(equations_module, "Equations") is not None

        assert self.base_year <= self.first_projection_year

        assert (
            self.first_projection_year + 40
        ) <= self.last_projection_year, f"The first projection year ({self.first_projection_year}) must be at least 40 years before the last projection year ({self.last_projection_year})"

        if self.stable_manifold_tolerance > 1e-3:
            raise Exception(
                "The convergence tolerance when searching for the stable manifold must be less than or equal to 1e-3."
            )

        if self.stable_manifold_maximum_iterations < 30:
            raise Exception(
                "You must allow for at least 30 iterations in converging to the stable manifold. Typically 1000+ are better."
            )
