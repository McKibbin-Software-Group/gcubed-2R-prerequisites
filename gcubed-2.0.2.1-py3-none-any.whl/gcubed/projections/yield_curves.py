"""
This module contains the `'YieldCurves` class,
responsible for computing long bond rates in nominal and
real yield curves from projections of 1-year rates.
"""

import logging
import pandas as pd
import numpy as np
import warnings


class YieldCurves:
    """
    Provides the functionality required to compute long nominal and real interest
    rates from one-year rates.
    """

    @classmethod
    def calculate_long_rates(cls, term: int, rates: pd.DataFrame) -> pd.DataFrame:
        """

        ### Overview

        Utility method that returns the compounding long rates given the yearly rates.

        ### Arguments

        `term`: the number of years of the term of the instrument. 2 for a 2 year bond.
        Valid values are:

        * 2 (for nominal short rates only)
        * 5 (for nominal short rates only)
        * 10 (for real or nominal short rates)

        `rates`: a dataframe with a single row, containing the 1 year interest rates
        (nominal or real) across the columns. The row index is the variable name of the 1
        year interest rate. The column indices are ordered YYYY years (as strings).
        Rates are interpreted as decimal values so 1% is expected to be given as 0.01.

        Returns the long rates that can be computed from the one year rates. This series is shorter
        than the series of one year rates because the required data is not available for
        the last (term-1) observations. It is padded with NaN values in the returned dataframe.
        """

        # Infer the name of the long rates variable.
        name: str = str(rates.index[0])
        name_suffix = name.split("(")[1]
        match str(name).split("(")[0]:
            case "INTN":
                match term:
                    case 2:
                        long_rate_name = "NB02"
                    case 5:
                        long_rate_name = "NB05"
                    case 10:
                        long_rate_name = "NB10"
                    case _:
                        raise Exception(f"Invalid nominal bond term specified: {term}")
            case "INTR":
                match term:
                    case 2:
                        long_rate_name = "RB02"
                    case 5:
                        long_rate_name = "RB05"
                    case 10:
                        long_rate_name = "RB10"
                    case _:
                        raise Exception(f"Invalid real bond term specified: {term}")
            case _:
                raise Exception(
                    f"Invalid variable used to compute bond rates: {
                        str(rates.index[0])}. Use a 1 year interest rate."
                )

        # Set up the long rates dataframe ready to be populated.
        long_rates: pd.DataFrame = rates.copy().map(lambda x: np.nan)
        long_rates.index = [f"{long_rate_name}({name_suffix}"]

        # Calculate the compounding value of $1, given in the year before the first year of short rates.
        compounding_values = rates.copy()
        compounding_values = compounding_values + 1
        compounding_values = compounding_values.cumprod(axis="columns")
        preceding_year: int = int(compounding_values.columns[0]) - 1
        compounding_values.insert(0, str(preceding_year), 1.0)

        # Determine the column index (integer) for the first column that contains a negative value.
        # This is used to ensure that the compounded value never goes negative.
        if (compounding_values < 0).sum(axis=1).any():
            first_negative_column_label: str = (
                (compounding_values < 0).idxmax(axis=1).iloc[0]
            )
            first_negative_column_index: int = compounding_values.columns.get_loc(
                first_negative_column_label
            )
            # logging.warning(
            #     f"The {name} implied value for the {term}-year bond rate is negative in {first_negative_column_label}."
            # )
            compounding_values.iloc[:, first_negative_column_index:] = 0.0

        with warnings.catch_warnings(record=True) as w:
            long_rates.loc[
                :, rates.iloc[:, 0 : (len(rates.columns) - term + 1)].columns
            ] = (
                np.power(
                    compounding_values.iloc[:, term:].to_numpy()
                    / compounding_values.iloc[:, 0:-term:1].to_numpy(),
                    1 / term,
                )
                - 1.0
            )
            if len(w) > 0 and issubclass(w[0].category, DeprecationWarning):
                logging.warning("Caught warning:", w[0].message)
                logging.error(
                    f"Warning issued when calculating {name} from compounding values\n{
                        compounding_values.iloc[:, 0:-term:1]}"
                )
                logging.info(f"numerator\n{compounding_values.iloc[:, term:]}")
                logging.info(
                    f"denominator\n{
                             compounding_values.iloc[:, 0:-term:1]}"
                )

        return long_rates.astype(float)
