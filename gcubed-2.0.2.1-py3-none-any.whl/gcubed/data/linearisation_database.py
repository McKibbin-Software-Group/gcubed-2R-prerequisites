"""
This module contains the `LinearisationDatabase` class, used
for model linearisation.
"""

import logging
import pandas as pd
import numpy as np
from gcubed.base import Base
from gcubed.data.database import Database
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData


class LinearisationDatabase(Database):
    def __init__(self, database: Database, base_year: int) -> None:
        """
        ### Constructor

        Manage loading and provision of linearisation database.

        Encapsulates all of the information about the linearisation data used by a Model.

        Note that this data differs from that used for model calibration in that the data
        for gdp unit variables has been scaled by the GDP ratio for each region to the US.

        ### Arguments

        `database`: the database that this calibration database was derived from.

        `base_year`: the base year for the database.
        """

        assert database is not None, "The database is required"
        assert isinstance(
            database, Database
        ), "The database must be a subclass of gcubed.Database"
        self._sym_data = database.sym_data
        self._configuration = self.sym_data.configuration
        self._variables = database.variables.copy()
        self._data = database.data.copy()
        self._last_available_year = database.last_available_year
        self._first_available_year = database.first_available_year

        assert (
            base_year is not None
        ), "The base year is required to indicate the base year for all indices in the database."
        if database.base_year != base_year:
            logging.info(
                f"Rebasing the database from {database.base_year} to {
                    base_year} for linearisation."
            )
            super().rebase(new_base_year=base_year)
        else:
            logging.info("No need to rebase the database for linearisation.")
            self._base_year = base_year

        self.set_up_yratr()

        self._data = self.data / 100
        self.__multiply_data_by_gdp_ratio()
        self.__log_variables()

        self.__validate()

    @property
    def sym_data(self) -> SymData:
        return self._sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        return self._configuration

    def __multiply_data_by_gdp_ratio(self):
        """
        Scale level variables with 'gdp' units data for each region by the ratio of
        that region's real GDP to US real GDP, in the database's base year.
        Perform this function before using the database for linearisation or
        for projections.

        This operation converts the variables from being fractions of own region GDP (in USD)
        to being fractions of US GDP (again in USD).
        """

        # Iterate over regions, selecting the data to scale by each region
        # This will scale all variables with units equal to
        # gdp, mmtgdp, btugdp, or gwhgdp that DO NOT enter the model in log form.
        variables_to_scale = self.sym_data.variable_summary.units.str.endswith(
            "gdp"
        ) & (self.sym_data.variable_summary.logged == False)

        self.data.loc[variables_to_scale, :] *= (
            self.yratr_scaling_factor(year=self.base_year)
            .loc[variables_to_scale, [str(self.base_year)]]
            .to_numpy()
        )

    def __log_variables(self):
        """
        Compute logs of the variables that have a `logged` attribute in their declaration
        in the SYM file.
        """
        variables_to_log = (self.sym_data.variable_summary.logged == True) & (
            self.sym_data.zero_variables_selector == False
        )

        # Check for negative values that are to be logged.
        temp = self.data.loc[variables_to_log, :]
        rows_with_negatives = temp[(temp < 0).any(axis=1)]
        assert (
            len(rows_with_negatives) == 0
        ), f"Negative values were found in database for variables that enter the model in log form.\n{list(rows_with_negatives.index)}"

        # Log all variables, setting zeros to 1e-20 to avoid log(0) errors.
        self.data.loc[variables_to_log, :] = np.log(
            self.data.loc[variables_to_log, :].replace(0, 1e-20)
        )

    def __validate(self):
        """
        Raise an exception if the linearisation database is invalid.
        """
        pass

    def rebase(self):
        raise Exception(
            "Rebasing operations cannot be performed on a subclass of database. Rebase the original database instead."
        )

    def get_non_negative_data(
        self, variable_name_prefix: str, years: list
    ) -> pd.DataFrame:
        """
        ### Overview

        **This method should not be called on a linearisation database**

        ### Arguments

        `variable_name_prefix`: The variable name prefix.

        `years`: the list of years for which the data is to be retrieved. Note that
        this can be a list of integer values or a list of strings.

        ### Exceptions

        This method always raises an exception because the method should not be called
        on a linearisation database.
        """

        assert (
            False
        ), "Calling this method on a linearisation database indicates a design mistake."
