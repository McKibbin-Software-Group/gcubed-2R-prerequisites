"""
This module contains the `StateSpaceForm` class.

The state space form is simply a matrix representation of the linearised model,
after eliminating the vectors on the left-hand side of the equations from the 
right-hand side of the equations.
"""

from concurrent.futures import process
import os
import logging
import copy
import numpy as np
import pandas as pd
from scipy.linalg import lu_factor, lu_solve
from gcubed.linearisation.linear_model import LinearModel
from gcubed.model import Model
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData


class StateSpaceForm(Base):
    """

    The algebra embodied in this class follows
    https://www.msgpl.com.au/Manuals2021/GGGv20JManual/softwaremanual/algorithm.pdf

    The notation has been extended to also include equations for
    expected endogenous variables to include exogenous variables.

    This class provides the ability to work with the model equations. It
    constructs the matrices of constants associated with the
    state-space form of the linearised model. This involves eliminating
    the endogenous variables from the model via substitution.

    To use this class instantiate it with a linear_model.
    run the generate_state_space_form() method.

    To understanding the naming conventions, the partial
    derivatives matrix associated with the partials of
    x1l with respect to z1r are stored in a property called x1l_z1r_partials.
    The same naming convention is used for all partials matrices:
    <LHS_vector_name>_<RHS_vector_name>_partials.

    The SSF matrices follow a similar naming convention:
    <LHS_vector_name>_<RHS_vector_name>
    """

    def __init__(self, linear_model: LinearModel) -> None:
        """
        ### Constructor

        ### Arguments

        linear_model: The linear approximation to the model that will be algebraicly
        manipulated to produce the state-space form of that linear approximation.

        """

        logging.info("Simplifying the linearised model to get its state space form ...")

        assert linear_model is not None
        assert linear_model.linear_model_is_available
        self._linear_model = linear_model

        # Copy across partial derivative matrices as starting point for ssf matrices.
        self._ssf_matrices: dict[tuple[str, str], np.ndarray] = dict()
        for lhs_vector_name in self.sym_data.lhs_vector_names:
            for rhs_vector_name in self.sym_data.rhs_vector_names:
                self._ssf_matrices[(lhs_vector_name, rhs_vector_name)] = copy.deepcopy(
                    linear_model.get_partials(lhs_vector_name, rhs_vector_name)
                )

        self.__compute_state_space_form()

        # # Log SSF matrices to diagnostics.
        # for lhs_vector_name, rhs_vector_name in self._ssf_matrices:
        #     self.delta_as_dataframe(lhs_vector_name=lhs_vector_name, rhs_vector_name=rhs_vector_name).to_csv(
        #         os.path.join(
        #             self.configuration.diagnostics_directory,
        #             f"ssf_{lhs_vector_name}_{rhs_vector_name}.csv",
        #         )
        #     )

        self.__validate()

    def __validate(self):
        """
        Validate the state space form details.
        """
        logging.info("The State Space Form of the linearised model has been obtained.")

    @property
    def linear_model(self) -> LinearModel:
        """
        The linear model underpinning this state-space form.
        """
        return self._linear_model

    @property
    def model(self) -> Model:
        """
        The full, non-linear model that has this state-space form for the
        given linear approximation.
        """
        return self.linear_model.model

    @property
    def sym_data(self) -> SymData:
        """
        The SYM definition of the model.
        """
        return self.model.sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        """
        The model configuration details.
        """
        return self.model.configuration

    def delta(self, lhs_vector_name, rhs_vector_name) -> np.ndarray:
        """
        ### Overview
        Use the name of the LHS vector and the RHS vector to retrieve
        the matrix for the state-space form.

        ### Arguments

        lhs_vector_name: The name of the LHS vector.

        rhs_vector_name: THe name of the RHS vector

        ### Returns

        The matrix with one row for each equation associated with the LHS vector
        an one column for each variable in the RHS vector.

        """
        if self._ssf_matrices is None:
            raise Exception(
                f"Attempted to access SSF matrix relating {lhs_vector_name} to {
                    rhs_vector_name} before it was created."
            )
        key = (lhs_vector_name, rhs_vector_name)
        if key in self._ssf_matrices:
            return self._ssf_matrices[key]
        return None

    def delta_as_dataframe(self, lhs_vector_name, rhs_vector_name) -> pd.DataFrame:
        """
        ### Arguments

        lhs_vector_name: The name of the LHS vector.

        rhs_vector_name: THe name of the RHS vector

        ### Returns

        The delta matrix as a dataframe labelling rows with LHS variable names
        and columns with RHS variable names.
        """
        if self._ssf_matrices is None:
            raise Exception(
                f"Attempted to access SSF matrix relating {lhs_vector_name} to {
                    rhs_vector_name} before it was created."
            )
        key = (lhs_vector_name, rhs_vector_name)
        if key in self._ssf_matrices:
            result: pd.DataFrame = pd.DataFrame(self._ssf_matrices[key])
            result.index = self.sym_data.vector_variable_names(
                vector_name=lhs_vector_name
            )
            result.columns = self.sym_data.vector_variable_names(
                vector_name=rhs_vector_name
            )
            return result
        return None

    def __compute_state_space_form(self):
        """

        ### Overview

        Use substitution to eliminate LHS variables from the RHS of the model.
        Do this in two steps.

        First solve equation for the RHS variable vector to be eliminated from the RHS.
        This is done using a LU decomposition.

        Second, use the solution to that equation to substitute the
        the LHS for that equation out of the other equations.
        """
        # Track which equations we have processed.
        self._RHS_vectors_to_skip: list[str] = ["z1r"]

        # Used to order the ssf intermediary calculation results
        # when they are written to a CSV file.
        self._counter: int = 1

        logging.info(
            "Obtaining the state space form of the endogenous variable (z1) equations."
        )
        self.process("z1l")
        logging.info(
            "Obtaining the state space form of the expected next-period endogenous variable (ze) equations."
        )
        self.process("zel")
        logging.info(
            "Obtaining the state space form of the costate variable (j1) equations."
        )
        self.process("j1l")
        logging.info(
            "Obtaining the state space form of the state variable (x1) equations."
        )
        self.process("x1l")

        # Delete the SSF matrices associated with the eliminated RHS vectors.
        eliminated_rhs_vector_names: list[str] = []
        for lhs_vector_name in self.sym_data.lhs_vector_names:
            rhs_vector_name: str = self.sym_data.matching_rhs_vector_name(
                lhs_vector_name
            )
            eliminated_rhs_vector_names.append(rhs_vector_name)
        for lhs_vector_name in self.sym_data.lhs_vector_names:
            for rhs_vector_name in eliminated_rhs_vector_names:
                del self._ssf_matrices[(lhs_vector_name, rhs_vector_name)]

    def process(self, lhs_vector_name: str):
        """

        ### Overview

        Do the SSF algebra for the vector of equations
        associated with the given LHS vector name.

        ### Arguments

        `lhs_vector_name`: The name of the LHS vector.

        """
        matched_rhs_vector_name: str = self.sym_data.matching_rhs_vector_name(
            lhs_vector_name
        )

        square_matrix: np.ndarray = self.delta(lhs_vector_name, matched_rhs_vector_name)

        # If the LHS is not related to itself on the RHS, there is nothing to do. Otherwise ...
        # Solve the set of equations associated with the LHS vector to eliminate that vector from its RHS.
        if np.any(square_matrix):  # square_matrix has some non-zero elements
            logging.info(
                f"Using LU-decomposition to eliminate {matched_rhs_vector_name} from the RHS of the {
                    square_matrix.shape[0]} {lhs_vector_name} equations."
            )
            I_A: np.ndarray = 0 - square_matrix
            np.fill_diagonal(I_A, 1 + I_A.diagonal())

            (lu, piv) = lu_factor(I_A)
            for rhs_vector_name in self.sym_data.rhs_vector_names:
                if rhs_vector_name in self._RHS_vectors_to_skip:
                    continue
                if rhs_vector_name == matched_rhs_vector_name:
                    continue
                if self.sym_data.vector_length(vector_name=rhs_vector_name) == 0:
                    continue
                self._ssf_matrices[(lhs_vector_name, rhs_vector_name)] = lu_solve(
                    (lu, piv), self.delta(lhs_vector_name, rhs_vector_name)
                )
                self._counter = self._counter + 1

        self._RHS_vectors_to_skip.append(matched_rhs_vector_name)

        # Adjust other vector equations accordingly to eliminate the matching RHS vector from each of them.
        for other_lhs_vector_name in self.sym_data.lhs_vector_names:
            if other_lhs_vector_name == lhs_vector_name:
                continue
            if self.sym_data.vector_length(vector_name=other_lhs_vector_name) == 0:
                continue

            logging.info(
                f"Adjusting the {other_lhs_vector_name} equations accordingly."
            )

            # Avoid matrix operations that have no effect because this matrix is all zeros.
            if not np.any(self.delta(other_lhs_vector_name, matched_rhs_vector_name)):
                continue

            for rhs_vector_name in self.sym_data.rhs_vector_names:
                if rhs_vector_name in self._RHS_vectors_to_skip:
                    continue
                if rhs_vector_name == matched_rhs_vector_name:
                    continue
                if self.sym_data.vector_length(vector_name=rhs_vector_name) == 0:
                    continue

                # Avoid matrix operations that have no effect because this matrix is all zeros.
                if not np.any(self.delta(lhs_vector_name, rhs_vector_name)):
                    continue

                self._ssf_matrices[
                    (other_lhs_vector_name, rhs_vector_name)
                ] = self.delta(other_lhs_vector_name, rhs_vector_name) + self.delta(
                    other_lhs_vector_name, matched_rhs_vector_name
                ) @ self.delta(
                    lhs_vector_name, rhs_vector_name
                )
                self._counter = self._counter + 1

    def select_delta_coefficients(
        self,
        lhs_vector_name: str,
        rhs_vector_name: str,
        lhs_variable_name_prefix: str = None,
        rhs_variable_name_prefix: str = None,
    ) -> pd.DataFrame:
        """
        ### Overview Retrieve the partial derivatives for the specified LHS vector.

        ### Arguments

        `lhs_vector_name`: The name of the LHS vector, e.g. `x1l` or `j1l`.

        `rhs_vector_name`: The name of the RHS vector, e.g. `yxr` or `j1r`.

        `lhs_variable_name_prefix`: The prefix to use for the LHS variable names, e.g. `PRID(USA`. Defaults to None
        in which case all rows are returned.

        `rhs_variable_name_prefix`: The prefix to use for the RHS variable names, e.g. `TCPS(a11,g02,USA`. Defaults to None
        in which case all columns are returned.

        ### Returns

        The dataframe with the matched rows and columns of the chosen SSF matrix.

        """
        assert (
            lhs_vector_name,
            rhs_vector_name,
        ) in self._ssf_matrices, f"There is no SSF matrix for {
                lhs_vector_name} on {rhs_vector_name}"
        matrix: pd.DataFrame = self.delta_as_dataframe(
            lhs_vector_name=lhs_vector_name, rhs_vector_name=rhs_vector_name
        )

        if lhs_variable_name_prefix is None and rhs_variable_name_prefix is None:
            return matrix

        if rhs_variable_name_prefix is None:
            return matrix.loc[
                matrix.index.str.startswith(lhs_variable_name_prefix), :
            ].copy()

        if lhs_variable_name_prefix is None:
            return matrix.loc[
                :, matrix.columns.str.startswith(rhs_variable_name_prefix)
            ].copy()

        return matrix.loc[
            matrix.index.str.startswith(lhs_variable_name_prefix),
            matrix.columns.str.startswith(rhs_variable_name_prefix),
        ].copy()

    def delta_coefficients_for_given_lhs_variable(
        self,
        lhs_variable_name_prefix: str = None,
    ) -> pd.DataFrame:
        """
        ### Overview Retrieve the delta coefficients for the specified LHS variables.

        ### Arguments

        `lhs_variable_name_prefix`: The prefix to use for the LHS variable names, e.g. `PRID(USA`. Defaults to `None`
        in which case all rows are returned.

        ### Returns

        The dataframe with the partial derivatives for the selected LHS variables.

        """

        lhs_vector_names: list[str] = list(
            set(
                self.sym_data.variable_summary.loc[
                    self.sym_data.variable_summary.index.str.startswith(
                        lhs_variable_name_prefix
                    ),
                    "vector",
                ]
            )
        )
        assert (
            len(lhs_vector_names) == 1
        ), f"Expected one LHS vector name for variables with prefix {lhs_variable_name_prefix}, but got {lhs_vector_names}"
        lhs_vector_name: str = lhs_vector_names[0]

        result: pd.DataFrame = pd.DataFrame()
        for rhs_vector_name in self.sym_data.rhs_vector_names:
            if (
                not (
                    lhs_vector_name,
                    rhs_vector_name,
                )
                in self._ssf_matrices
            ):
                continue

            matrix: pd.DataFrame = self.delta_as_dataframe(
                lhs_vector_name=lhs_vector_name, rhs_vector_name=rhs_vector_name
            )
            matrix: pd.DataFrame = matrix.loc[
                matrix.index.str.startswith(lhs_variable_name_prefix),
            ].copy()

            # Convert the columns to a multi-index with the rhs vector name as the top level.
            matrix.columns = pd.MultiIndex.from_tuples(
                [(rhs_vector_name, column) for column in matrix.columns]
            )

            # Select those columns of the matrix where at least one element in the column is not equal to zero.
            matrix: pd.DataFrame = matrix.loc[:, (matrix != 0).any(axis=0)].copy()

            # Merge the matrix into the result dataframe.
            result = pd.concat([result, matrix], axis=1)

        return result
