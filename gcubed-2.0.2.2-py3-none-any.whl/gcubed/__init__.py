"""
The gcubed package provides a full implementation of the 
G-Cubed model.

An introduction to the G-Cubed Python implementation 
is available [online](https://documentation.gcubed.com/).

Support for G-Cubed is available from 
[McKibbin Software Group](https://gcubed.com/).

©1993-2023 McKibbin Software Group Pty Ltd. All rights reserved.
"""

import os
import math
import logging
import warnings
import traceback
from datetime import datetime
from gcubed.constants import Constants

CONSTANTS: Constants = Constants()


# Do a full stack trace for any exp underflow warnings
def gcubed_warning_handler(message, category, filename, lineno, file=None, line=None):
    """
    Reports warnings in the logs and tries to indicate any G-Cubed related cause of the warning.
    """

    # log warning message details
    logging.warning(f"{filename}:{lineno} {category.__name__}: {message}")

    required_entry: str = None
    for entry in traceback.format_stack():
        if "/gcubed/" in entry:
            required_entry = entry
            continue
        if "/gcubed/" not in entry and required_entry is not None:
            addendum: str = ""
            if "underflow encountered in exp" in str(message):
                addendum = " (exp underflow (exponentiating an excessively large negative number) produces 0)"
            logging.warning(
                f"  {message}: This is probably caused by {required_entry}{addendum}"
            )
            # traceback.print_stack()
            return
    # traceback.print_stack()
    logging.warning(f"{message}")


# Set up the custom warning handler
warnings.showwarning = gcubed_warning_handler


def now() -> str:
    """
    The current time and date as a string with a format that is
    `%Y-%m-%d_%H-%M-%S`

    This is useful for result reporting and debugging purposes when naming
    output files.
    """
    return datetime.now().strftime("%Y-%m-%d_%H-%M-%S")


def log(x: float) -> float:
    """
    The natural logarithm of x.

    This is a convenience function that is provided for
    consistency with the G-Cubed model.

    Parameters
    ----------
    x : float
        The value for which the natural logarithm is required.

    Returns
    -------
    float
        The natural logarithm of x.
    """
    try:
        return math.log(x)
    except ValueError:
        # logging.error(f"Could not log({x})")
        return -1000000


def file_summary(file_path, ancestors=3) -> str:
    """
    ### Overview

    Get a summary of a file path

    ### Arguments

    `file_path` : The file path to summarise.

    `ancestors` : The number of ancestor folders to include in the summary, 3 by default.

    """

    # If the file path is not absolute, return it as is
    if not os.path.isabs(file_path):
        return file_path

    # Get the filename
    filename = os.path.basename(file_path)

    # Get the preceding ancestor folder names
    ancestor_folders = os.path.dirname(file_path).split(os.path.sep)[-ancestors:]

    # Create the final result
    result = os.path.sep.join(ancestor_folders + [filename])

    return result
