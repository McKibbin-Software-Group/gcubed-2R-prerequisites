"""
Model version 2R parameter subclasses.
"""
