"""
This module contains the `Population` class which loads population growth rates.
"""

import logging
import os
import os.path
import pandas as pd
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData


class Population(Base):
    """
    Loads population growth rates for all sectors within each region.
    """

    def __init__(self, sym_data: SymData) -> None:
        """
        ### Arguments

        `sym_data`: The information about the SYM model definition.

        The model configuration is accessible via this argument, thus
        enabling discovery of the location of the population growth rates
        CSV file.

        ### CSV file format

        The population growth rates file records annual
        population growth rates data for all regions,
        expressed as percentages so a value of 1 is a 1% growth rate.

        The CSV file format is as shown below:

        |                   | 2018 | … | 2100 |
        |-------------------|------|---|------|
        | `<REGION_CODE 1>` |    1 |   |    0 |
        | `<REGION_CODE 2>` |    2 |   |    0 |
        ... for all other regions.

        The first row contains the projection years in columns 2 onward.
        The following rows contain the population growth rates for each region.
        Each row of data has the region code in the first column and the
        percentage growth rate for each year in the column corresponding to that year.

        In the example above, the first projection year is 2018 and the last projection
        year is 2100. The region 1 population grows at 1% in 2018 and 0% in 2100.
        The region 2 population grows at 2% in 2018 and 0% in 2100.

        The data is based on the [GTAP database](https://www.gtap.agecon.purdue.edu/databases/)
        and users usually do not need to change the values unless they do so in
        experiment simulation layers.

        The row labels should be the region identifiers from the SYM model definition.
        These might need to be modified from the identifiers used in the Ox versions of this file
        because the region identifiers are prefixed by `pop` in the Ox versions of this file.


        """
        assert sym_data is not None
        assert sym_data.configuration is not None
        self._configuration: ModelConfiguration = sym_data.configuration
        self._sym_data: SymData = sym_data

        self.__load_population_growth_rates()

        self.__validate()

    def __validate(self):
        """
        TODO: Check that growth rate projections extend to the right last year for projections.
        """

        assert self._population_growth_rates is not None

        # The productivity information must extend to the end year for the simulations
        if not self.configuration.last_projection_year == int(
            self._population_growth_rates.columns[-1]
        ):
            logging.warning(
                f"The end year for population projections, {self.configuration.last_projection_year}, does not match the final year, {self._population_growth_rates.columns[-1]}, of the productivity data in {self._filename}"
            )

        # Make sure the productivity data starts early enough to include the years specified in the model configuration.
        assert str(self.configuration.first_projection_year) in self._data_column_names

    @property
    def configuration(self):
        return self._configuration

    @property
    def sym_data(self):
        return self._sym_data

    @property
    def population_growth_rates(self) -> pd.DataFrame:
        return self._population_growth_rates

    def __load_population_growth_rates(self):
        """
        **This function is intended for gcubed module internal use. It is exposed only for documentation purposes.**

        Parse the CSV file into its the dataframe of population
        growth rates expressed as decimal values so 1% growth rate is 0.01.
        """

        # Load the data into a dataframe
        self._filename: str = self.configuration.population_file
        if not os.path.isfile(self._filename):
            raise Exception(
                f"The productivity parameters file {self._filename} does not exist. Check the model configuration."
            )
        population_growth_rates: pd.DataFrame = pd.read_csv(self._filename)
        population_growth_rates.index = population_growth_rates.iloc[:, 0]
        self._data_column_names = self.get_year_labels(
            labels=population_growth_rates.columns
        )
        population_growth_rates = (
            population_growth_rates.loc[:, self._data_column_names] / 100
        )
        population_growth_rates = population_growth_rates.loc[
            :, self.configuration.projection_years_column_labels
        ]
        self._population_growth_rates = population_growth_rates
