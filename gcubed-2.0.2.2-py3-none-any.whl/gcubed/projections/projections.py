"""
This module contains the `Projections` class, used as a base class
for generating baseline and simulation projections. It provides access
to all forms of projections.
"""

# DO NOT DELETE THIS IMPORT
# DO NOT DELETE THIS IMPORT it manages circular references.
import os
from typing import Optional
import logging
import pandas as pd
import numpy as np
import gcubed
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData
from gcubed.model import Model
from gcubed.model_parameters.parameters import Parameters
from gcubed.linearisation.state_space_form import StateSpaceForm
from gcubed.linearisation.stable_manifold import StableManifold
from gcubed.linearisation.linear_model import LinearModel
from gcubed.projections.yield_curves import YieldCurves


class Projections(Base):
    """
    Base class for Simulation Projections and for Baseline Projections.
    """

    def __init__(
        self,
        stable_manifold: StableManifold,
        previous_projections: Optional["Projections"] = None,
    ) -> None:
        """

        ### Arguments

        `stable_manifold`: The stable manifold used for projecting the model.

        `previous_projections`: The previous projections (baseline or simulation layer or other)
        or `None` if these projections have no previous projections.

        ### Exceptions

        Raises an exception if the stable manifold has not been supplied correctly.

        Raises an exception if the stable manifold has not converged.

        """

        assert stable_manifold is not None, "The stable manifold must be supplied."
        assert isinstance(
            stable_manifold, StableManifold
        ), f"The stable manifold must be a StableManifold but it is a {type(stable_manifold)}."
        assert (
            stable_manifold.converged
        ), "The algorithm for determining the stable manifold must have converged but it has not, for the supplied stable manifold."
        self._stable_manifold = stable_manifold

        self._previous_projections = previous_projections
        self._is_first_projections = self.previous_projections is None
        if self.is_first_projections:
            self._first_projections = self
            self._baseline_projections = self
        else:
            self._first_projections = previous_projections.first_projections

        # Set the baseline projections for any projections that are not baseline projections
        if not hasattr(self, "_baseline_projections"):
            self._baseline_projections = previous_projections.baseline_projections

        self._first_projection_year = (
            self.configuration.first_projection_year
        )  # overridden by simulation layer constructors.

        self.__validate()

    def __validate(self):
        """
        TODO:  Validate the projections:
        1. check that they are available for the expected projection years.
        2. Check that the base year projections are equal to the base year data values.
        """
        pass

    @property
    def name(self) -> str:
        """
        The name of these projections.
        """
        if not self._name:
            return f"baseline projections from {self.first_projection_year}"
        return self._name

    @property
    def is_baseline_projections(self) -> bool:
        """
        True if the projections are baseline projections rather than
        some other kind of projections.
        """
        return self == self.baseline_projections

    @property
    def baseline_projections(self) -> Optional["BaselineProjections"]:
        """
        The baseline projections that underpin these projections.
        If these projections are baseline projections then this property is
        this instance.
        """
        return self._baseline_projections

    @property
    def first_projections(self) -> Optional["Projections"]:
        """
        The first projections created (these have no previous projections).
        """
        return self._first_projections

    @property
    def is_first_projections(self) -> bool:
        """
        True if the projections are the first projections and False otherwise.

        This setting is used to determine whether constant adjustments to
        long interest rates (nominal and real bond rates) are calculated to
        ensure first projection year long interest rates match the observed
        data for that year.
        """
        return self._is_first_projections

    @property
    def previous_projections(self) -> Optional["Projections"]:
        """
        The previous projections (baseline or simulation layer or other) or
        `None` if these projections are baseline projections.
        """
        return self._previous_projections

    @property
    def stable_manifold(self) -> StableManifold:
        """
        The stable manifold used for projecting the model.
        """
        return self._stable_manifold

    @property
    def state_space_form(self) -> StateSpaceForm:
        """
        The state-space form of the linearised model.
        """
        return self.stable_manifold.ssf

    @property
    def linear_model(self) -> LinearModel:
        """
        The linearised model.
        """
        return self.state_space_form.linear_model

    @property
    def model(self) -> Model:
        """
        The model being used to generate the projections.
        """
        return self.stable_manifold.model

    @property
    def sym_data(self) -> SymData:
        """
        The SYM processor data generated from the SYM model definition.
        """
        return self.model.sym_data

    @property
    def parameters(self) -> Parameters:
        """
        The calibrated parameters of the model.
        """
        return self.model.parameters

    @property
    def configuration(self) -> ModelConfiguration:
        """
        The model configuration.
        """
        return self.model.configuration

    @property
    def first_projection_year(self) -> int:
        """
        The first projection year for this projection.
        """
        return self._first_projection_year

    @property
    def original_first_projection_year(self) -> int:
        """
        The original first projection year for this projection.
        """
        return self.configuration.original_first_projection_year

    @property
    def last_projection_year(self) -> int:
        """
        The last year of projections
        """
        return self.configuration.last_projection_year

    @property
    def last_publishable_projection_year(self) -> int:
        """
        The last year of projections that are publishable.
        """
        return self.configuration.last_publishable_projection_year

    @property
    def projection_years(self) -> list[int]:
        """
        Returns the list of years for projections from the event year through to
        and including the projection end year.
        """
        return range(self.first_projection_year, self.last_projection_year + 1)

    @property
    def projection_years_count(self) -> list[int]:
        return self.last_projection_year - self.first_projection_year + 1

    @property
    def projection_years_column_labels(self) -> list[str]:
        """
        Returns the ordered list of 4 digit (YYYY) year
        column labels for the projections.
        """
        return [str(x) for x in self.projection_years]

    @property
    def publishable_projection_years(self) -> list[int]:
        """
        Returns the list of years for publishable projections.
        """
        return range(
            self.original_first_projection_year,
            self.last_publishable_projection_year + 1,
        )

    @property
    def publishable_projection_years_column_labels(self) -> list[str]:
        """
        Returns the ordered list of 4 digit (YYYY) year
        publishable projection column labels for the projections.
        """
        return [str(x) for x in self.publishable_projection_years]

    @property
    def projections(self) -> pd.DataFrame:
        """
        Returns the dataframe of projections for all variables in the model that are part of the
        4 vectors specified. There still need to be additional variable projected that are computed
        outside of the system to take non-linearity into account (eg long-term interest rates.)

        ### Exceptions

        Raises an exception if the projections are not yet available.

        """
        assert hasattr(self, "_projections"), f"The projections are not yet available."
        return self._projections

    @property
    def combined_database_and_projections(self) -> pd.DataFrame:
        """
        Returns the dataframe of the original database and the projections
        for all variables in the model.

        This splicing of the database onto the database projections is intended to be used
        for diagnostic purposes only.

        ### Exceptions

        Raises an exception if the combined database and projections are not yet available.

        """
        assert hasattr(
            self, "_combined_database_and_projections"
        ), f"The combined database and projections are not yet available."
        return self._combined_database_and_projections

    @property
    def database_projections(self) -> pd.DataFrame:
        """
        Returns the dataframe of projections for all variables
        in the model in forms that are consistent with
        the values contained in the original model database.

        ### Exceptions

        Raises an exception if the database projections are not yet available.
        """
        assert hasattr(
            self, "_database_projections"
        ), "The database projections are not yet available."
        return self._database_projections

    @property
    def publishable_projections(self) -> pd.DataFrame:
        """
        Returns the dataframe of projections for all variables in the model.

        ### Exceptions

        Raises an exception if the publishable projections are not yet available.

        """
        assert hasattr(
            self, "_publishable_projections"
        ), "The publishable projections are not yet available."
        return self._publishable_projections.loc[
            :, self.publishable_projection_years_column_labels
        ]

    @property
    def yxr_initial_values(self) -> pd.DataFrame:
        """
        The yxr initial values used to start the projections process.

        ### Exceptions

        Raises an exception if the initial values contain NaNs.

        Raises an exception if the initial values are not yet available.
        """
        if hasattr(self, "_yxr_initial_values"):
            return self._yxr_initial_values
        raise Exception(
            f"The initial values for the period t state variable projections (yxr) are not yet available."
        )

    @property
    def yxr_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get yxr variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, "_yxr_projections"):
            return self._yxr_projections
        raise Exception(
            f"The period t state variable projections (yxr) are not yet available."
        )

    @property
    def yxr_projections(self) -> np.ndarray:
        """
        Get yxr variable projection values
        of the projection years.
        """
        if hasattr(self, "_yxr_projections"):
            return self._yxr_projections.to_numpy()
        raise Exception(
            f"The period t state variable projections are not yet available."
        )

    @property
    def yjr_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get yjr variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, "_yjr_projections"):
            return self._yjr_projections
        raise Exception(
            f"The period t costate variable projections (yjr) are not yet available."
        )

    @property
    def yjr_projections(self) -> np.ndarray:
        """
        Get yjr variable projection values
        of the projection years.
        """
        if hasattr(self, "_yjr_projections"):
            return self._yjr_projections.to_numpy()
        raise Exception(
            f"The period t costate variable projections (yjr) are not yet available."
        )

    @property
    def exz_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get exz variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, "_exz_projections"):
            return self._exz_projections
        raise Exception(
            f"The period t expected values for t+1 variables projections (exz) are not yet available."
        )

    @property
    def exz_projections(self) -> np.ndarray:
        """
        Get exz variable projection values
        of the projection years.
        """
        if hasattr(self, "_exz_projections"):
            return self._exz_projections.to_numpy()
        raise Exception(
            f"The period t expected values for t+1 variables projections (exz) are not yet available."
        )

    @property
    def zel_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get zel variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, "_zel_projections"):
            return self._zel_projections
        raise Exception(f"The period t ZEL projections are not yet available.")

    @property
    def zel_projections(self) -> np.ndarray:
        """
        Get zel variable projection values
        of the projection years.
        """
        if hasattr(self, "_zel_projections"):
            return self._zel_projections.to_numpy()
        raise Exception(f"The period t ZEL projections are not yet available.")

    @property
    def z1l_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get z1l variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, "_z1l_projections"):
            return self._z1l_projections
        raise Exception(f"The period t Z1L projections are not yet available.")

    @property
    def z1l_projections(self) -> np.ndarray:
        """
        Get z1l variable projection values
        of the projection years.
        """
        if hasattr(self, "_z1l_projections"):
            return self._z1l_projections.to_numpy()
        raise Exception(f"The period t Z1L projections are not yet available.")

    @property
    def exo_projections(self) -> pd.DataFrame:
        """
        A dataframe (not a numpy array) that contains
        the exogenous variable projection values
        for all of the projection years from the original first
        projection year through to the last projection year,
        as a dataframe.

        The exogenous variable projections for the years before
        the first projection year of this projections object are retained
        because they can be necessary in the event of a
        subsequent model relinearisation.

        ### Exceptions

        Raises an exception if the exogenous variable projections contain NaN values.

        """
        if hasattr(self, "_exo_projections"):
            return self._exo_projections
        raise Exception(f"The exogenous variable projections are not yet available.")

    @property
    def long_rate_constants(self) -> pd.DataFrame:
        """
        The constant adjustments to long bond rates
        (real and nominal) in the base projection year
        to ensure projections equal observed values.
        """
        return self._long_rate_constants

    def _compute_functions_of_future_exogenous_variables(
        self, exogenous_projections: pd.DataFrame
    ):
        """
        ### Overview

        The rules governing the dynamic behaviour of variables depend on functions of the current and future exogenous variables.
        These functions are evaluated and the results are stored in numpy matrices that match the number of rows
        for the related vector of variables and that have a column for each year from the base projection year to the
        last year in the projections.

        ### Arguments

        exogenous_projections: the dataframe of exogenous projections.

        """

        # Set up the arrays that will be populated and initialise them to zeros.

        # // setup for baseline with optimization
        # decl id=invert(unit(nez)-c4n);
        # c4t=id*cz5;

        # decl mu2t=id*c6n;

        # id=invert(unit(njm)-ff-we*mu2t);
        # c6t=id*(cz4+we*c4t);

        # c4t=c4t+mu2t*c6t;
        # c4t=ones(rows(c4t),nobs).*c4t;
        # c6t=ones(rows(c6t),nobs).*c6t;
        # c2t=h2t*exog+c6t+bt2t*gam3t;

        # Determine how many years are involved - we will have a column
        # of functions of future exogenous variables for each year.
        projection_years_count: int = len(exogenous_projections.columns)

        # This is equivalent to h3t in the newsetsymbl.ox script (j by 1 dimensions)
        h3t: np.ndarray = np.zeros(
            shape=(
                self.sym_data.vector_length(vector_name="j1l"),
                projection_years_count,
            )
        )

        # Populate for period T.

        # c4t=invert(unit(nez)-zel_exz_ssf)*cz5   (r by 1 dimensions)
        interim_calculation = self.stable_manifold.Gamma_rT @ self.ze_constants

        # c6t = invert(unit(j)-j1l_yjr_ssf-j1l_exz_ssf*mu2t) * (cz4+j1l_exz_ssf*c4t)
        #     = Gamma_jT (cz4+j1l_exz_ssf*interim_calculation)
        c6T_column = self.stable_manifold.Gamma_jT @ (
            self.j1_constants
            + self.state_space_form.delta("j1l", "exz") @ interim_calculation
        )

        # c4t = c4t + mu2t * c6t (r by 1 dimensions)
        c4T_column = interim_calculation + self.stable_manifold.psi_rj @ c6T_column

        # c4t=ones(rows(c4t),nobs).*c4t (r by T dimensions)
        c4t: np.ndarray = np.tile(c4T_column, (1, projection_years_count))

        # c6t=ones(rows(c6t),nobs).*c6t (j by T dimensions)
        c6t: np.ndarray = np.tile(c6T_column, (1, projection_years_count))

        # c2t=h2t*exog+c6t    (j by T dimensions)
        c2t: np.ndarray = (
            self.stable_manifold.H2 @ exogenous_projections.to_numpy() + c6t
        )

        # (s by T dimensions)
        c5t: np.ndarray = np.zeros(
            shape=(
                self.sym_data.vector_length(vector_name="x1l"),
                projection_years_count,
            )
        )

        # (j by T dimensions)
        c2t_lead: np.ndarray = c2t.copy()
        c4t_lead: np.ndarray = c4t.copy()

        # Populate for earlier periods.
        j = projection_years_count - 1
        for k in range(projection_years_count - 1, -1, -1):
            # c5t[][k] = wvi*(x1l_exz_ssf*c4tl[][j] + cz2)          (s by 1 : note no need for T columns)
            c5t: np.ndarray = self.stable_manifold.Gamma_st @ (
                self.state_space_form.delta("x1l", "exz") @ c4t_lead[:, [j]]
                + self.x1_constants
            )

            # c6t[][k] = fdeltinv*(th6t*c5t[][k] - j1l_exz_ssf*c4tl[][j] + c2tl[][j] - cz4)         (j rows)
            c6t[:, [k]] = self.stable_manifold.Gamma_jt @ (
                self.stable_manifold.common_factor @ c5t
                - self.state_space_form.delta("j1l", "exz") @ c4t_lead[:, [j]]
                + c2t_lead[:, [j]]
                - self.j1_constants
            )

            # c5t[][k] = c5t[][k] + th2t*c6t[][k]
            c5t = c5t + self.stable_manifold.tau_sjt @ c6t[:, [k]]

            # c4t[][k] = mu1tl*c5t[][k] + c4tl[][j]
            c4t[:, [k]] = self.stable_manifold.M1_lead @ c5t + c4t_lead[:, [j]]

            # h3t[][k] = c6t[][k]
            h3t[:, [k]] = c6t[:, [k]].copy()

            # c2t[][k] = h2t*exog[][k] + h3t[][k]
            c2t[:, [k]] = (
                self.stable_manifold.H2 @ exogenous_projections.iloc[:, [k]].to_numpy()
                + h3t[:, [k]]
            )

            # c4tl[][k] = nmu4t*exog[][k] + zel_yjr_ssf*h3t[][k] + zel_exz_ssf*c4t[][k] + cz5
            c4t_lead[:, [k]] = (
                self.stable_manifold.M2 @ exogenous_projections.iloc[:, [k]].to_numpy()
                + self.state_space_form.delta("zel", "yjr") @ h3t[:, [k]]
                + self.state_space_form.delta("zel", "exz") @ c4t[:, [k]]
                + self.ze_constants
            )

            c2t_lead = c2t.copy()

            j = k

        # Store the functions of future exogenous variables to access when doing projections.

        if np.isnan(h3t).any():
            raise Exception(
                "The functions of future exogenous variables, associated with costate variables, contain NaNs."
            )

        if np.isnan(c4t).any():
            raise Exception(
                "The functions of future exogenous variables, associated with expected next-period endogenous variables, contain NaNs."
            )

        self._h3t = h3t.copy()
        self._c4t = c4t.copy()

        pd.DataFrame(self.h3t).to_csv(
            os.path.join(self.configuration.diagnostics_directory, "baseline projections - functions of exogenous variables - h3t.csv")
        )

        pd.DataFrame(self.c4t).to_csv(
            os.path.join(self.configuration.diagnostics_directory, "baseline projections - functions of exogenous variables - c4t.csv")
        )


    @property
    def h3t(self) -> np.ndarray:
        """
        Equivalent to h3t in the Ox implementation

        Returns constants and the functions of current and future exogenous variables affecting J1.
        """
        return self._h3t

    @property
    def c4t(self) -> np.ndarray:
        """
        Equivalent to c4t in the Ox implementation

        Returns constants and the functions of current and future exogenous variables affecting ZE.
        """
        return self._c4t

    @property
    def h3t_as_dataframe(self) -> pd.DataFrame:
        """
        Returns constants and the functions of current and future exogenous variables affecting J1.
        as a dataframe, indexing the rows with costate variable names and the columns
        with projection years.
        """
        result: pd.DataFrame = pd.DataFrame(self.h3t)
        result.index = self.sym_data.vector_variable_names(vector_name="j1l")
        result.columns = self.projection_years_column_labels
        return result

    @property
    def c4t_as_dataframe(self) -> pd.DataFrame:
        """
        Returns constants and the functions of current and future exogenous variables affecting ZE.
        as a dataframe, indexing the rows with costate variable names and the columns
        with projection years.
        """
        result: pd.DataFrame = pd.DataFrame(self.c4t)
        result.index = self.sym_data.vector_variable_names(vector_name="zel")
        result.columns = self.projection_years_column_labels
        return result

    def _generate_projections(self):
        """
        Implements the projection logic in msgsimBL.ox. This runs the various equations
        to project variables based on the starting state vector and the values of
        exogenous variables in all years. The steps are as follows:

        Step 1.
        Recalculate the functions of future exogenous variables, incorporating
        the updated exogenous variable projections and all constant adjustments:
        the intertemporal constants and the other constants  capturing the difference
        between the SSF equation results in the base year and the observed
        values in the base year.

        Step 2.
        Project the state vector. (x_t+1 as a function of x_t and exogenous variables and constant adjustments)
        This uses the Anew and Znew matrices computed as part of getting the stable manifold.

        Step 3.
        Combine all variable projections into a single data frame.

        Step 4.
        Sort the variables in the projection dataframe into the same order as the original database.

        ### Exceptions

        Exceptions are raised if any of the raw projections have NaN (not a number) values.

        """

        exogenous_projections: pd.DataFrame = self.exo_projections.loc[
            :, self.projection_years_column_labels
        ]

        # Step 1.
        self._compute_functions_of_future_exogenous_variables(
            exogenous_projections=exogenous_projections
        )

        # Step 2.
        self._constantBL: pd.DataFrame = pd.DataFrame(
            self.stable_manifold.Znew @ exogenous_projections.to_numpy()
            + self.state_space_form.delta("x1l", "yjr") @ self.h3t
            + self.state_space_form.delta("x1l", "exz") @ self.c4t
            + self.x1_constants
        )
        self._constantBL.columns = self.projection_years_column_labels
        self._constantBL.index = self.sym_data.vector_variable_names(vector_name="yxr")
        yxr: pd.DataFrame = pd.DataFrame(
            index=self.sym_data.vector_variable_names(vector_name="yxr"),
            columns=self.projection_years_column_labels,
        )
        yxr.loc[:, [str(self.first_projection_year)]] = self.yxr_initial_values

        previous_year_label = str(self.first_projection_year)
        assert previous_year_label == yxr.columns[0]

        for year in yxr.columns[
            1:
            # omit the first year - those values are set already as state variables.
        ]:
            yxr.loc[:, [year]] = (
                self.stable_manifold.Anew @ yxr.loc[:, [previous_year_label]].to_numpy()
                + self.constantBL.loc[:, [previous_year_label]].to_numpy()
            )
            previous_year_label = year

        # Project J1
        # er = h1t*x + h2t*exog[][1:nobs] + h3t
        yjr: pd.DataFrame = pd.DataFrame(
            self.stable_manifold.H1 @ (yxr.to_numpy())
            + self.stable_manifold.H2 @ exogenous_projections.to_numpy()
            + self._h3t
        )
        yjr.columns = self.projection_years_column_labels
        yjr.index = self.sym_data.vector_variable_names(vector_name="j1l")
        self._yjr_projections = yjr

        # Project time t expected value of ZE in period t+1 (EXZ)
        # Project time t expected value of ZE in period t+1 (EXZ)
        # tzl = mu1t*x + mu4t*exog[][1:nobs] + c4t
        exz: pd.DataFrame = pd.DataFrame(
            self.stable_manifold.mu1 @ yxr.to_numpy()
            + self.stable_manifold.mu2 @ exogenous_projections.to_numpy()
            + self._c4t
        )
        exz.columns = self.projection_years_column_labels
        exz.index = self.sym_data.vector_variable_names(vector_name="zer")
        self._exz_projections = exz

        # Project time t values of ZE using the SSF equation (this should be done with M1 and M2?)
        # What about the functions of future exogenous variables and the constant adjustments
        zel: pd.DataFrame = pd.DataFrame(
            self.state_space_form.delta("zel", "yxr") @ yxr
            + self.state_space_form.delta("zel", "exz") @ exz
            + self.state_space_form.delta("zel", "yjr") @ yjr
            + self.state_space_form.delta("zel", "exo")
            @ exogenous_projections.to_numpy()
        )
        zel.columns = self.projection_years_column_labels
        zel.index = self.sym_data.vector_variable_names(vector_name="zel")
        self._zel_projections = zel + self.ze_constants

        # Project Z1 using the SSF equation
        z1l: pd.DataFrame = pd.DataFrame(
            self.state_space_form.delta("z1l", "yxr") @ yxr
            + self.state_space_form.delta("z1l", "exz") @ exz
            + self.state_space_form.delta("z1l", "yjr") @ yjr
            + self.state_space_form.delta("z1l", "exo")
            @ exogenous_projections.to_numpy()
        )
        z1l.columns = self.projection_years_column_labels
        z1l.index = self.sym_data.vector_variable_names(vector_name="z1l")
        self._z1l_projections = z1l + self.z1_constants

        # timeshift forward the special state variables by 1 period.
        for variable_name_prefix in gcubed.CONSTANTS.STATE_LEAD_VARIABLES:
            matching_variables = yxr.index.str.startswith(variable_name_prefix)
            yxr.iloc[matching_variables, 0:-2] = yxr.iloc[matching_variables, 1:-1]
            # Duplicate the T-1 value to produce the T value for these variables
            # See
            yxr.loc[matching_variables, yxr.columns[-1]] = yxr.loc[
                matching_variables, yxr.columns[-2]
            ]

        self._yxr_projections = yxr

        if self.yxr_projections_as_dataframe.isna().any().any():
            raise Exception("The raw state variable projections contain NaNs.")
        if self.z1l_projections_as_dataframe.isna().any().any():
            raise Exception("The raw endogenous variable projections contain NaNs.")
        if self.zel_projections_as_dataframe.isna().any().any():
            raise Exception(
                "The raw expected next-period exogenous variable projections contain NaNs."
            )
        if self.yjr_projections_as_dataframe.isna().any().any():
            raise Exception("The raw costate variable projections contain NaNs.")

        # Combine the projections into a single dataframe in the same order as the database
        self._projections = pd.concat(
            [
                self.yxr_projections_as_dataframe,
                self.z1l_projections_as_dataframe,
                self.zel_projections_as_dataframe,
                self.yjr_projections_as_dataframe,
                exogenous_projections,
            ]
        )
        database_ordered_variable_list: pd.DataFrame = self.database.variables.name
        self._projections = pd.concat(
            [database_ordered_variable_list, self._projections], axis=1
        )
        self._projections.drop("name", inplace=True, axis=1)

        self._projections = self._projections.astype(float)

    @property
    def constantBL(self) -> pd.DataFrame:
        """
        The constantBL matrix used to generate the state variable projections.
        """
        return self._constantBL

    def _generate_database_projections(self):
        """
        Converts the raw projections into projections that are consistent with the database being used
        by the model. These projections can be spliced on to the original database (as opposed to the
        GDP scaled database) that was loaded with the model used to produce the projections.

        Implements the first parts of the projection conversion logic in datamsymbl.ox.

        #### Step 1.
        Get a copy of the raw projections.

        #### Step 1.1
        Reverse the log transformation of the variables with the logged attribute.

        #### Step 2.
        Divide the projections by YRATR in the projection base year
        for every variable that IS NOT logged and that has units of:

        * `gdp`
        * `btugdp`
        * `gwhgdp`
        * `mmtgdp`
        * `mmtusgdp`

        #### Step 3.
        If the baseline projections started from the neutral real interest rate,
        adjust the interest rate variables using the intcons adjustment, adding
        the difference between the base-projection year interest rate and the
        assumed neutral real interest rate to each of the interest rate variables.
        This ensures that the result short interest rates are comparable to the
        original database, aside from scaling by 100.

        Note that, at this stage the interest rates are expressed as decimals
        so 0.02 is a 2% interest rate.

        ##### Step 4.
        Calculate long rates from short rates using annual compounding.
        This ensures that the long interest rates are derived from the short rates.

        ##### Step 5.
        Adjust long rate projections by adding long rate constants that
        are calculated as part of baseline projections to ensure
        that the long rates are equal to the observed values in the
        original first year. This ensures that the long interest rates
        are comparable to the original database, aside from scaling by 100.

        #### Step 6.
        Get LGDPR (real GDP level) data in the projection base year for each
        region and grow over projection years at rate given by 'labgrow' parameter.
        Store the LGDPR projections as part of the database projections.

        #### Step 7.
        Multiply projection values by 100
        This ensures that the projections are scaled in the same way as the original database.

        Saves the result in the _database_projections property.

        These database projections should be associated with the publication_units of measurement
        available from the sym_data variable summary.

        #### Step 8.
        Splice the database projections onto the existing database for previous projection years.

        """

        # Step 1.
        database_projections: pd.DataFrame = self.projections.copy()

        # Step 1.1
        variables_to_exponentiate = (self.sym_data.variable_summary.logged == True) & (
            self.sym_data.zero_variables_selector == False
        )

        database_projections.loc[variables_to_exponentiate, :] = np.exp(
            database_projections.loc[variables_to_exponentiate, :]
        )

        # Check if any element in each row is 'inf'
        # Filter the DataFrame to get rows with 'inf' values
        mask = database_projections.isin([np.inf]).any(axis=1)
        problem_variables: list[str] = list(database_projections[mask].index)
        if problem_variables:
            logging.warning(
                f"Some variables have projections that include infinite values, typically because projections of their log values became very large."
            )
            # logging.warning(
            #     f"Original log projections of the variables:\n{self.projections.loc[mask,:]}"
            # )
            # logging.warning(
            #     f"Level projections of the variables:\n{database_projections.loc[mask,:]}"
            # )

        # Step 2.
        variables_to_scale = self.sym_data.variable_summary.units.str.endswith(
            "gdp"
        ) & (self.sym_data.variable_summary.logged == False)
        database_projections.loc[variables_to_scale, :] /= (
            self.database.yratr_scaling_factor(
                year=self.configuration.original_first_projection_year
            )
            .loc[variables_to_scale, :]
            .to_numpy()
        )

        # Step 3.
        # Make the adjustment to convert back to actual interest rates from 
        # the neutral real interest rate if required by user.
        # This step is no longer done

        # Step 4.
        # Calculate the long rates.
        real_interest_rates: pd.DataFrame = database_projections.loc[
            database_projections.index.str.startswith(
                f"{gcubed.CONSTANTS.REAL_INTEREST_RATE_PREFIX}("
            ),
            str(self.first_projection_year) :,
        ].copy()
        for variable_name in real_interest_rates.index:
            rb10: pd.DataFrame = YieldCurves.calculate_long_rates(
                term=10, rates=real_interest_rates.loc[[variable_name], :]
            )
            database_projections.loc[[str(rb10.index[0])], :] = rb10
        nominal_interest_rates: pd.DataFrame = database_projections.loc[
            database_projections.index.str.startswith(
                f"{gcubed.CONSTANTS.NOMINAL_INTEREST_RATE_PREFIX}("
            ),
            str(self.first_projection_year) :,
        ].copy()
        for variable_name in nominal_interest_rates.index:
            nb02: pd.DataFrame = YieldCurves.calculate_long_rates(
                term=2, rates=nominal_interest_rates.loc[[variable_name], :]
            )
            database_projections.loc[[str(nb02.index[0])], :] = nb02
            nb05: pd.DataFrame = YieldCurves.calculate_long_rates(
                term=5, rates=nominal_interest_rates.loc[[variable_name], :]
            )
            database_projections.loc[[str(nb05.index[0])], :] = nb05
            nb10: pd.DataFrame = YieldCurves.calculate_long_rates(
                term=10, rates=nominal_interest_rates.loc[[variable_name], :]
            )
            database_projections.loc[[str(nb10.index[0])], :] = nb10

        # Step 5.
        # Only if doing baseline projections:
        # Determine the constants to add to the long rates to match
        # the original base projection year observed and projected values.
        if self.is_first_projections:
            self._long_rate_constants: pd.DataFrame = None
            for prefix in gcubed.CONSTANTS.BOND_RATE_PREFIXES:
                observed_values: pd.DataFrame = self.database.data.loc[
                    self.database.variables.name.str.startswith(f"{prefix}("),
                    [str(self.first_projection_year)],
                ].copy()
                projected_values: pd.DataFrame = database_projections.loc[
                    database_projections.index.str.startswith(f"{prefix}("),
                    [str(self.first_projection_year)],
                ].copy()
                constants: pd.DataFrame = observed_values - projected_values
                constants.columns = [str(self.first_projection_year)]
                constants.index = observed_values.index
                if self._long_rate_constants is None:
                    self._long_rate_constants = constants
                else:
                    self._long_rate_constants = pd.concat(
                        [self._long_rate_constants, constants], axis=0
                    )

        # For all projections, baseline and otherwise:
        # Add the baseline projection long-rate constant to the interest rate's long rate projections
        # to line the long rate projections up with observed data in the first projection year.
        for variable_name in self.long_rate_constants.index:
            database_projections.loc[[variable_name], :] += float(
                self.long_rate_constants.loc[variable_name, :].iloc[0]
            )

        # Step 6.
        rows_containing_LGDPR_data = self.database.variables.name.str.startswith(
            f"{gcubed.CONSTANTS.REAL_GDP_PREFIX}("
        )
        lgdpr_data: pd.DataFrame = self.database.data.loc[
            rows_containing_LGDPR_data,
            [str(self.configuration.original_first_projection_year)],
        ]

        # Note - use the exp function because the index is given in log form.
        us_longrun_effective_labour_productivity_index: pd.DataFrame = np.exp(
            self.model.effective_labour_productivity.us_longrun_effective_labour_log_index.loc[
                :, self.projection_years_column_labels
            ]
        )

        lgdpr_longrun_projections: pd.DataFrame = pd.DataFrame(
            lgdpr_data.values * us_longrun_effective_labour_productivity_index.values
        )
        lgdpr_longrun_projections.columns = self.projection_years_column_labels
        lgdpr_longrun_projections.index = (
            lgdpr_data.index
        )  # Index with the LGDPR full variable names
        database_projections.loc[rows_containing_LGDPR_data, :] = (
            lgdpr_longrun_projections
        )

        # Step 7.
        database_projections *= 100.0

        # Step 8.
        # Splice on the actual data from the model database from the original first projection year onwards.
        # Make sure that we have database projections back to the original first projection year.
        data: pd.DataFrame = (
            self.model.database.data
            if self.previous_projections is None
            else self.previous_projections.database_projections
        )
        for column in data.columns[::-1]:
            # if int(column) >= self.configuration.original_first_projection_year:
            if not (column in database_projections.columns):
                if int(column) < int(database_projections.columns[0]):
                    database_projections.insert(0, column, data.loc[:, column], True)
                else:
                    break

        # Save the combined database and database projections for diagnostic analysis.
        self._combined_database_and_projections = database_projections.astype(float)

        # Save the database projection only (not the years before the original first projection year) for use in publishable projection generation etc..
        self._database_projections = (
            database_projections.loc[
                :, self.configuration.original_projection_years_column_labels
            ]
            .copy()
            .astype(float)
        )

    def _generate_publishable_projections(self):
        """

        Uses the real GDP trend growth projections to adjust
        the projections of all variables with units equal to
        'usgdp' or 'gdp'.

        Implements the real GDP scaling part of the projection conversion logic in datamsymbl.ox.

        Step 1.
        For all projections with units equal to usgdp, multiply the projection
        by the US LGDPR projection computed in step 4 when producing the database projections.

        Step 2.
        For all projections with units equal to 'gdp', multiply the projection by the associated
        region's LGDPR projection computed in step 4 when producing the database projections.

        Step 3.
        Ensure that macroeconomic aggregates have components consistent with aggregates.

        These publishable projections should be associated with the publication_units of measurement
        available from the sym_data variable summary.

        Saves the result in the _publishable_projections property.
        """

        publication_projections: pd.DataFrame = self.database_projections.copy()

        # Real GDP scaling

        # Get the LGDPR projections.
        # There will be one row per region.
        lgdpr_database_projections: pd.DataFrame = self.database_projections.loc[
            self.database_projections.index.str.startswith(
                f"{gcubed.CONSTANTS.REAL_GDP_PREFIX}("
            ),
            :,
        ]

        lgdpr_database_projections.index = self.model.sym_data.regions_members
        for variable_name in publication_projections.index:
            units_for_variables_with_given_name_prefix: str = str(
                self.database.variables.loc[variable_name, "units"]
            )
            match units_for_variables_with_given_name_prefix:
                case "usgdp" | "mmtusgdp" | "btuusgdp":
                    publication_projections.loc[[variable_name], :] *= (
                        lgdpr_database_projections.loc[
                            [self.sym_data.us_region], :
                        ].values
                        / 100
                    )
                case "gdp" | "mmtgdp" | "btugdp" | "gwhgdp":
                    variable_region: str = str(
                        self.database.variables.loc[variable_name, "region"]
                    )
                    publication_projections.loc[[variable_name], :] *= (
                        lgdpr_database_projections.loc[[variable_region], :].values
                        / 100
                    )
                case "dollar":
                    publication_projections.loc[[variable_name], :] /= 100

        # Ensure components sum to aggregates (addressing impact of linearisation errors.)
        if self.configuration.enforce_aggregate_consistency:

            # Get the names of the variables
            names = publication_projections.index.str

            # --------------------------------------------------------------------
            # Scale The trade balance to match total exports less total imports
            # --------------------------------------------------------------------
            TBAL: pd.DataFrame = publication_projections.loc[
                names.startswith(f"TBAL("), :
            ]

            EXQT: pd.DataFrame = publication_projections.loc[
                names.startswith(f"EXQT("), :
            ]

            IMQT: pd.DataFrame = publication_projections.loc[
                names.startswith(f"IMQT("), :
            ]

            # Force TBAL = EXQT-IMQT exactly.
            components_TBAL: pd.DataFrame = TBAL.copy() * 0.0
            components_TBAL.loc[:, :] = EXQT.to_numpy() - IMQT.to_numpy()
            # scale_factor: pd.DataFrame = abs(components_TBAL.div(TBAL))
            publication_projections.loc[names.startswith(f"TBAL("), :] = (
                components_TBAL.to_numpy()
            )

            # --------------------------------------------------------------------
            # Scale sectoral investment components
            # --------------------------------------------------------------------
            INVP: pd.DataFrame = publication_projections.loc[
                names.startswith(f"INVP("), :
            ]
            components_INVP: pd.DataFrame = INVP.copy() * 0.0
            for region in self.sym_data.regions_members:
                region_INV = publication_projections.loc[
                    names.match(rf"INV\(.+\b{region}\)"), :
                ]
                components_INVP.loc[[f"INVP({region})"], :] += np.array(
                    [region_INV.sum().values]
                )
            scale_factor: pd.DataFrame = components_INVP.div(INVP)
            publication_projections.loc[
                names.startswith(f"INVP("), :
            ] *= scale_factor.to_numpy()

            # --------------------------------------------------------------------
            # Scale total investment components
            # --------------------------------------------------------------------
            INVT: pd.DataFrame = publication_projections.loc[
                names.startswith(f"INVT("), :
            ]
            INVY: pd.DataFrame = publication_projections.loc[
                names.startswith(f"INVY("), :
            ]
            INVZ: pd.DataFrame = publication_projections.loc[
                names.startswith(f"INVZ("), :
            ]
            INVP: pd.DataFrame = publication_projections.loc[
                names.startswith(f"INVP("), :
            ]

            components_INVT: pd.DataFrame = INVT.copy() * 0.0
            components_INVT.loc[:, :] = (
                INVY.to_numpy() + INVZ.to_numpy() + INVP.to_numpy()
            )
            scale_factor: pd.DataFrame = components_INVT.div(INVT)
            publication_projections.loc[
                names.startswith(f"INVT("), :
            ] *= scale_factor.to_numpy()

            # --------------------------------------------------------------------
            # Scale consumption for energy goods
            # --------------------------------------------------------------------
            CNPE: pd.DataFrame = publication_projections.loc[
                names.startswith(f"CNPE("), :
            ]

            components_CNPE: pd.DataFrame = CNPE.copy() * 0.0
            for region in self.sym_data.regions_members:
                for good in self.sym_data.energy_goods_members:
                    components_CNPE.loc[
                        [f"CNPE({region})"], :
                    ] += publication_projections.loc[
                        [f"CON({good},{region})"], :
                    ].to_numpy()
            scale_factor: pd.DataFrame = components_CNPE.div(CNPE)

            publication_projections.loc[
                names.startswith(f"CNPE("), :
            ] *= scale_factor.to_numpy()

            # --------------------------------------------------------------------
            # Scale consumption for ordinary goods
            # --------------------------------------------------------------------
            CNPO: pd.DataFrame = publication_projections.loc[
                names.startswith(f"CNPO("), :
            ]

            components_CNPO: pd.DataFrame = CNPO.copy() * 0.0
            for region in self.sym_data.regions_members:
                for good in self.sym_data.material_goods_members:
                    if self.sym_data.has_variable(
                        variable_name=f"CON({good},{region})"
                    ):  # Ignore durable goods
                        components_CNPO.loc[
                            [f"CNPO({region})"], :
                        ] += publication_projections.loc[
                            [f"CON({good},{region})"], :
                        ].to_numpy()
            scale_factor: pd.DataFrame = components_CNPO.div(CNPO)
            publication_projections.loc[
                names.startswith("CNPO("), :
            ] *= scale_factor.to_numpy()

            # --------------------------------------------------------------------
            # Scale consumption components
            # --------------------------------------------------------------------
            CONP: pd.DataFrame = publication_projections.loc[
                names.startswith(f"CONP("), :
            ]
            CNPE: pd.DataFrame = publication_projections.loc[
                names.startswith(f"CNPE("), :
            ]
            CNPO: pd.DataFrame = publication_projections.loc[
                names.startswith(f"CNPO("), :
            ]
            CNPK: pd.DataFrame = publication_projections.loc[
                names.startswith(f"CNPK("), :
            ]
            CNPL: pd.DataFrame = publication_projections.loc[
                names.startswith(f"CNPL("), :
            ]

            components_CONP: pd.DataFrame = CONP.copy()
            components_CONP.loc[:, :] = (
                CNPE.to_numpy() + CNPO.to_numpy() + CNPK.to_numpy() + CNPL.to_numpy()
            )
            scale_factor: pd.DataFrame = components_CONP.div(CONP)
            publication_projections.loc[
                names.startswith(f"CONP("), :
            ] *= scale_factor.to_numpy()

            # --------------------------------------------------------------------
            # Scale GDP to match components
            # --------------------------------------------------------------------
            GDPR: pd.DataFrame = publication_projections.loc[
                names.startswith(f"GDPR("), :
            ]
            CONP: pd.DataFrame = publication_projections.loc[
                names.startswith(f"CONP("), :
            ]
            GCET: pd.DataFrame = publication_projections.loc[
                names.startswith(f"GCET("), :
            ]
            INVT: pd.DataFrame = publication_projections.loc[
                names.startswith(f"INVT("), :
            ]
            TBAL: pd.DataFrame = publication_projections.loc[
                names.startswith(f"TBAL("), :
            ]

            components_GDPR: pd.DataFrame = GDPR.copy()
            components_GDPR.loc[:, :] = (
                CONP.to_numpy() + GCET.to_numpy() + INVT.to_numpy() + TBAL.to_numpy()
            )
            # assert that none of the elements in components_GDPR are zero or negative
            if (components_GDPR <= 0).any().any():
                logging.error(
                    "The components of GDP sum to a non-positive value for one or more regions in one or more projection years. This suggests a problem with TBAL projections."
                )

            scale_factor: pd.DataFrame = components_GDPR.div(GDPR)
            publication_projections.loc[
                names.startswith(f"GDPR("), :
            ] *= scale_factor.to_numpy()

            # --------------------------------------------------------------------
            # Compute output growth rates directly from OUTPUT levels
            # --------------------------------------------------------------------
            YGRO: pd.DataFrame = publication_projections.loc[
                names.startswith(f"YGRO("), :
            ]
            OUTP: pd.DataFrame = publication_projections.loc[
                names.startswith(f"OUTP("), :
            ]
            lnOUP: pd.DataFrame = np.log(OUTP)
            # Compute the log difference in OUTP
            calcYGRO: pd.DataFrame = 100 * lnOUP.diff(axis=1)
            publication_projections.loc[
                names.startswith(f"YGRO("), publication_projections.columns[1:]
            ] = calcYGRO.iloc[:, 1:].to_numpy()

            # --------------------------------------------------------------------
            # Scale emissions to match totals with components
            # --------------------------------------------------------------------
            if self.sym_data.has_variable(
                variable_name=f"EMCO({self.sym_data.us_region})"
            ):  # If we have aggregate CO2 emissions data in the model
                EMCO: pd.DataFrame = publication_projections.loc[
                    names.startswith(f"EMCO("), :
                ]

                EMCO2FD: pd.DataFrame = publication_projections.loc[
                    names.startswith(f"EMCO2FD("), :
                ]

                components_EMCO: pd.DataFrame = EMCO.copy() * 0.0 + EMCO2FD.to_numpy()
                for region in self.sym_data.regions_members:
                    for sector in self.sym_data.standard_sectors_members:
                        components_EMCO.loc[
                            [f"EMCO({region})"], :
                        ] += publication_projections.loc[
                            [f"EMCO2({sector},{region})"], :
                        ].to_numpy()
                scale_factor: pd.DataFrame = components_EMCO.div(EMCO)

                publication_projections.loc[
                    names.startswith(f"EMCO("), :
                ] *= scale_factor.to_numpy()

        # Remove any invalid values.
        publication_projections.replace([np.nan, np.inf, -np.inf], None, inplace=True)

        # Save the results for use later.
        self._publishable_projections = publication_projections.astype(float)

    def __add_projection_annotation_columns(
        self,
        projections: pd.DataFrame,
        publishable: bool = False,
        charting: bool = False,
    ):
        """

        ### Overview

        Insert columns containing annotation details about each of the variables
        in the projections. The changes are made directly to the dataframe
        so the function has not return value.

        ### Arguments

        `projections`: The projections to annotate.

        `publishable`: If `True`, the projections are publishable projections.
        Otherwise, the projections are database or raw projections. This affects the units that
        are included in the resulting dataframe.

        """
        projections.insert(
            0, "region", self.model.sym_data.variable_summary.loc[:, ["region"]]
        )
        projections.insert(
            0,
            "vector",
            self.model.sym_data.variable_summary.loc[:, ["vector"]],
        )
        if publishable:
            projections.insert(
                0,
                "units",
                self.model.sym_data.variable_summary.loc[:, ["publication_units"]],
            )
            pass
        else:
            projections.insert(
                0,
                "units",
                self.model.sym_data.variable_summary.loc[:, ["units"]],
            )
        projections.insert(
            0,
            "description",
            self.model.sym_data.variable_summary.loc[:, ["description"]],
        )
        if charting:
            projections.insert(
                0,
                "set_member_descriptions",
                self.model.sym_data.variable_summary.loc[
                    :, ["set_member_descriptions"]
                ],
            )
            projections.insert(
                0,
                "prefix",
                self.model.sym_data.variable_summary.loc[:, ["prefix"]],
            )

    @property
    def annotated_projections(self) -> pd.DataFrame:
        """
        Raw projections along with annotations for
        units and variable descriptions.
        """
        result: pd.DataFrame = self.projections.copy()
        self.__add_projection_annotation_columns(projections=result)
        return result

    @property
    def annotated_database_projections(self) -> pd.DataFrame:
        """
        Database projections along with annotations for
        units and variable descriptions.
        """
        result: pd.DataFrame = self.database_projections.copy()
        self.__add_projection_annotation_columns(projections=result)
        return result

    @property
    def annotated_combined_database_and_projections(self) -> pd.DataFrame:
        """
        Combined database and projections along with annotations for
        units and variable descriptions.
        """
        result: pd.DataFrame = self.combined_database_and_projections.copy()
        self.__add_projection_annotation_columns(projections=result)
        return result

    @property
    def annotated_publishable_projections(self) -> pd.DataFrame:
        """
        Publication projections along with annotations for
        units and variable descriptions.
        """
        result: pd.DataFrame = self.publishable_projections.copy()
        self.__add_projection_annotation_columns(projections=result, publishable=True)
        return result

    @property
    def charting_projections(self) -> pd.DataFrame:
        """
        Charting projections along with annotations for
        set member descriptions and prefix.
        """
        result: pd.DataFrame = self.publishable_projections.copy()
        self.__add_projection_annotation_columns(
            projections=result, publishable=True, charting=True
        )
        return result
