"""
This module provides the Productivity class which loads baseline
productivity growth projections.
"""

import logging
import os
import os.path
import pandas as pd
import numpy as np
import gcubed
from gcubed.base import Base
from gcubed.constants import Constants
from gcubed.sym_data import SymData


# The name of the variable in the modprod file (labor-augmenting technical change)
varname: str = "LATC"

# These labels are used to parse the productivity input CSV file into its constituent parts.
# They are searched for as row markers of the start of the new type of information in the file.
label_productivity_growth: str = "productivity growth"
label_us_sector_convergence_rates: str = "convergence rate across US sectors"
label_regional_sector_ratio_to_us: str = "sector ratio to the USA leader"
label_regional_sector_catchup_to_us_rates: str = "catchup rate"


class Productivity(Base):
    """
    This class loads productivity parameters and converts them
    into productivity projections for all regions and all sectors
    within each region.
    """

    def __init__(self, sym_data: SymData) -> None:
        """

        ### Constructor

        Creates productivity projections from the data describing the
        productivity growth behaviour for all regions and all
        sectors within each region.

        ### Arguments

        sym_data: The information about the SYM model definition.

        The model configuration is accessible via this argument, thus
        enabling discovery of the location of the information determining
        productivity growth rates.

        ### CSV file format

        The productivity growth rates file specifies productivity growth rates for all years in the projection.
        When doing baseline projections, the population and productivity growth rate projections are combined
        into exogenous effective labour productivity (AL) growth rate projections.

        The first row of the file contains column labels. The first column label is `region`.
        The second column label is `sector`. The remaining column labels are the years from a year
        at or before the first projection year through to the last projection year.

        The file contains:

        * productivity growth in each year of the projection for each sector of the US. A value of 1 implies a 1% simple annual growth rate.

        * For each non-US region, for each sector, specify the starting period fraction of US productivity for the same sector (a value of 1 implies the same productivity). This is only required in the initial period.

        * For each non-US region, for each sector, in each year of the projection, specify the catch-up rate as that non-US region’s sector catches up to the productivity of the same sector in the US. A value of 0.02 implies that the gap in productivity from the previous year declines by 2% to determine the new gap to US productivity. Note that this is not the same as the productivity growth rate information.

        Each of these three elements are contained in the file, one after the other. Their beginning in the file is identified
        by a text heading in column 1 of the row before where they start.

        The labels for the three sections of this file are:

        1. `productivity growth`
        2. `sector ratio to the USA leader`
        3. `catchup rate`

        These labels are case sensitive, they must be in the first column
        and they are relied upon when loading the productivity data.

        #### Example for a 2 region/2 sector model

        The region identifiers are USA and ROW.

        | region                             | sector | 2015 | 2016 | 2017 | 2018 | .... | 2100 |
        | ---------------------------------- | ------ | ---- | ---- | ---- | ---- | ---- | ---- |
        | productivity growth                |        |      |      |      |      |      |
        | USA                                 |        |      |      |      |      |      |      |
        |                                    | a01    | 1.4  | 1.4  | 1.4  | 1.4  | 1.4  | 1.4  |
        |                                    | a02    | 1.4  | 1.4  | 1.4  | 1.4  | 1.4  | 1.4  |
        | convergence rate across US sectors |        |      |      |      |      |
        |                                    | a01    |      | 0.03 | 0.03 | 0.03 | 0.03 | 0.03 |
        |                                    | a02    |      | 0.03 | 0.03 | 0.03 | 0.03 | 0.03 |
        |                                    |        |      |      |      |      |      |      |
        | sector ratio to the USA leader     |        |      |      |      |      |
        | ROW                                 |        |      |      |      |      |      |      |
        |                                    | a01    | 1    |      |      |      |      |      |
        |                                    | a02    | 1    |      |      |      |      |      |
        | catchup rate                       |        |      |      |      |      |      |
        | ROW                                 |        |      |      |      |      |      |      |
        |                                    | a01    | 0.02 | 0.02 | 0.02 | 0.02 | 0.02 | 0.02 |
        |                                    | a02    | 0.02 | 0.02 | 0.02 | 0.02 | 0.02 | 0.02 |

        #### Productivity growth data for USA sectors

        The first row of this section of data just contains the region identifier for the United States in the
        first column, `USA`.

        There is then one row for each of the members of the `sectors` set in the SYM model definition, `a01` through
        to `a02`, if there are 2 such sectors. They must be in the same order as the sector membership declaration
        in the SYM model definition.

        For each sector's row, the first column is blank and the second column is the sector identifier, e.g. `a01`.
        The row then contains a percentage growth rate for the sector in the column corresponding to each year column
        in the file.

        #### Sector ratios to the United States

        This section of the file has one table per non-United States region.

        For each region, the table begins with a row that contains the region identifier, e.g. `ROW`,
        in the first column and nothing else in any of the other columns.

        There is then one row for each of the members of the `sectors` set in the SYM model definition, `a01` through
        to `a02`, if there are 2 such sectors. They must be in the same order as the sector membership declaration
        in the SYM model definition.

        For each sector's row, the first column is blank and the second column is the sector identifier, e.g. `a01`.
        The third column is the productivity ratio to the same sector in the United States. Thus, a value of 0.5 would mean
        productivity for that region is half the productivity of the same sector for the United States. No other columns
        have values.

        #### Catchup rates to the United States

        This section of the file has one table per non-United States region.

        For each region, the table begins with a row that contains the region identifier, e.g. `ROW`,
        in the first column and nothing else in any of the other columns.

        There is then one row for each of the members of the `sectors` set in the SYM model definition, `a01` through
        to `a02`, if there are 2 such sectors. They must be in the same order as the sector membership declaration
        in the SYM model definition.

        For each sector's row, the first column is blank and the second column is the sector identifier, e.g. `a01`.
        The row then contains a decimal catchup rate for the sector in the column corresponding to each year column
        in the file. Thus a value of 0.02 in a particular year means that 2% of the remaining gap in productivity
        is closed in that year.

        """
        assert (
            sym_data is not None
        ), f"sym_data is None instead of a valid SymData instance."
        assert isinstance(sym_data, SymData), f"sym_data is not a SymData instance."
        self._sym_data: SymData = sym_data

        # Prioritise the existing productivity growth rates file
        if os.path.exists(self.configuration.modprod_file):
            self.__load_from_growth_rates_file()
        else:
            self.__load_productivity_parameters()
            self.__create_productivity_projections()

        self.__validate()

        if not os.path.exists(self.configuration.modprod_file):
            self.__write_growth_rates_file()

    def __validate(self):
        """
        Make sure projections are valid for all regions.
        """
        for region in self.sym_data.regions_members:
            assert (
                region in self.region_productivity_growth_rates
            ), f"The productivity growth rates for {region} are missing."
            assert (
                len(self.productivity_growth_rates(region=region).index)
                == self.sym_data.sectors_count
            ), f"The productivity growth rates for {region} do not have the expected number of sectors, {self.sym_data.sectors_count}."
            assert (
                len(self.productivity_growth_rates(region=region).columns)
                == self.configuration.projection_years_count
            ), f"The productivity growth rates for {region} do not have the expected number of projection years, {self.configuration.projection_years_count}."
            assert self.productivity_growth_rates(region=region).columns[-1] == str(
                self.configuration.last_projection_year
            ), f"The productivity growth rates for {region} do not extend to the last projection year, {self.configuration.last_projection_year}."
            assert self.productivity_growth_rates(region=region).columns[0] == str(
                self.configuration.first_projection_year
            ), f"The productivity growth rates for {region} do not start in the first projection year, {self.configuration.first_projection_year}."

    @property
    def configuration(self):
        """
        The model configuration
        """
        return self.sym_data.configuration

    @property
    def sym_data(self):
        """
        The SYM model details
        """
        return self._sym_data

    @property
    def region_productivity_growth_rates(self) -> dict[str, pd.DataFrame]:
        """
        The dictionary of dataframes used to store sectoral productivity growth rate
        projections for each region. It is indexed by region code.
        The dataframes are indexed by sector code.
        The columns of the dataframes are the projection years.
        """
        if not hasattr(self, "_region_productivity_growth_rates"):
            self._region_productivity_growth_rates: dict[str, pd.DataFrame] = dict()
        return self._region_productivity_growth_rates

    def productivity_growth_rates(self, region: str) -> pd.DataFrame:
        """
        ### Overview

        Accessor for productivity growth projections
        for all sectors in the specified region.

        ### Arguments

        `region`: The region for which the productivity growth rates
        are required.

        ### Returns

        The dataframe of productivity growth rate
        projections for all sectors in the region
        with rows indexed by sector code and
        columns indexed by projection year.

        ### Exceptions

        Raises an exception if the region is not valid.

        """
        if not region in self.region_productivity_growth_rates:
            raise Exception(
                f"Region {region} does not have productivity growth rate data."
            )
        return self.region_productivity_growth_rates[region]

    def __get_index_of(self, label: str) -> int:
        """
        Get the row index of the productivity parameters dataframe
        where the value in the region column is equal to the specified label.

        This is used to find each of the various types of data in the productivity parameters
        CSV file.

        The labels that are searched for are:

        """

        if self._input is None:
            raise Exception(
                "The productivity growth parameters have not been read from the CSV file."
            )
        matching_indexes: list[int] = self._input[
            self._input.region == label
        ].index.to_list()
        match len(matching_indexes):
            case 0:
                raise Exception(
                    f"There are no rows matching {label} in column 1 of the productivity parameters file."
                )
            case 1:
                return matching_indexes[0]
            case _:
                raise Exception(
                    f"There is more than one row matching {label} in column 1 of the productivity parameters file."
                )

    def __load_productivity_parameters(self):
        """

        ### Overview

        **This function is intended for gcubed module internal use.**

        Parse the CSV file into its various components and store them as properties.

        """

        # The list of regions defined in the SYM file
        regions_members: list[str] = self.sym_data.regions_members

        # The list of sectors defined in the SYM file (not sectors Y and Z that are common to all models and not explicit in the SYM file.)
        sectors_members: list[str] = self.sym_data.sectors_members

        # Load the data into a dataframe
        self._filename: str = self.configuration.productivity_file
        if not os.path.isfile(self._filename):
            raise Exception(
                f"The productivity parameters file {self._filename} does not exist. Check the model configuration."
            )
        self._input: pd.DataFrame = pd.read_csv(self._filename)
        self._input.reset_index()

        # Get the data column names. (YYYY format column labels)
        self._data_column_names = self.get_year_labels(labels=self._input.columns)

        # Get years range
        table_columns: list = range(2, 2 + len(self._data_column_names))
        list_column: list = [2]

        # US productivity growth rates (Stored in CSV as percentages so we divide by 100 before storing as a dataframe)
        label_row: int = self.__get_index_of(label_productivity_growth) + 2
        us_productivity_rows: list[int] = range(
            label_row, label_row + self.sym_data.sectors_count
        )
        if len(us_productivity_rows) < self.sym_data.sectors_count:
            raise Exception(
                f"The US sector productivity data is available for {us_productivity_rows} sectors but the model has {self.sym_data.sectors_count} sectors."
            )
        if len(us_productivity_rows) > self.sym_data.sectors_count:
            raise Exception(
                f"The US sector productivity data is available for {us_productivity_rows} sectors but the model has {self.sym_data.sectors_count} model-specific sectors."
            )
        self._us_productivity_growth_rates = self._input.iloc[
            us_productivity_rows, table_columns
        ].copy()
        self._us_productivity_growth_rates = self._us_productivity_growth_rates.head(
            self.sym_data.sectors_count
        )
        self._us_productivity_growth_rates = self._us_productivity_growth_rates.loc[
            :, self.configuration.projection_years_column_labels
        ]
        self._us_productivity_growth_rates = self._us_productivity_growth_rates / 100
        self._us_productivity_growth_rates.index = sectors_members

        # Load the ratio to US productivity for each region, by sector.
        # (A value of 1 means the productivity is the same)
        label_row: int = self.__get_index_of(label_regional_sector_ratio_to_us) + 2
        self._region_productivity_ratios: dict[str, pd.DataFrame] = dict()
        for region_index, region in enumerate(regions_members[1:]):
            first_row = label_row + region_index * (self.sym_data.sectors_count + 1)
            region_productivity_ratio_rows: list[int] = range(
                first_row, first_row + self.sym_data.sectors_count
            )
            if len(region_productivity_ratio_rows) != self.sym_data.sectors_count:
                raise Exception(
                    f"The {region} region productivity ratios data is available for {region_productivity_ratio_rows} sectors but the model has {self.sym_data.sectors_count} sectors."
                )
            region_productivity_ratios = self._input.iloc[
                region_productivity_ratio_rows, list_column
            ].copy()
            region_productivity_ratios = region_productivity_ratios.head(
                self.sym_data.sectors_count
            )
            region_productivity_ratios.columns = ["ratio"]
            region_productivity_ratios.index = sectors_members
            self._region_productivity_ratios[region] = region_productivity_ratios

        # Load the regional catchup rate projections by sector (decimal)
        # A value of 0.02 means a 2% reduction in the gap to the US productivity level.
        label_row: int = (
            self.__get_index_of(label=label_regional_sector_catchup_to_us_rates) + 2
        )
        self._region_catchup_rates: dict[str, pd.DataFrame] = dict()
        for region_index, region in enumerate(regions_members[1:]):
            first_row = label_row + region_index * (self.sym_data.sectors_count + 1)
            region_catchup_rates_rows: list[int] = range(
                first_row, first_row + self.sym_data.sectors_count
            )
            if len(region_catchup_rates_rows) != self.sym_data.sectors_count:
                raise Exception(
                    f"The {region} region catchup rate data is available for {region_catchup_rates_rows} sectors but the model has {self.sym_data.sectors_count} sectors."
                )
            region_catchup_rates = self._input.iloc[
                region_catchup_rates_rows, table_columns
            ].copy()
            region_catchup_rates = region_catchup_rates.head(
                self.sym_data.sectors_count
            )
            region_catchup_rates.columns = self._data_column_names
            region_catchup_rates.index = sectors_members
            self._region_catchup_rates[region] = region_catchup_rates

    def __create_productivity_projections(self):
        """

        ### Overview

        **This function is intended for gcubed module internal use.**

        Generate productivity growth and index projections
        from the first projection year to the last projection year
        for all regions and sectors.
        """

        projection_years: list[str] = self.configuration.projection_years_column_labels
        first_year: str = projection_years[0]
        last_year: str = projection_years[-1]
        later_years: list[str] = projection_years[1:]
        earlier_years: list[str] = projection_years[:-1]

        # Project levels for the US, setting the level to 1 for each sector in the base year.
        # The indices are used to calculate the growth rates for other regions.
        us_log_indices: pd.DataFrame = self._us_productivity_growth_rates[
            projection_years
        ].copy()
        us_log_indices[first_year] = 0.0
        us_log_indices[later_years] = us_log_indices[later_years].cumsum(axis="columns")

        # Determine growth rates for each region, applying catchup rates etc.
        for region in self.sym_data.regions_members:
            # We already have the US productivity growth rates.
            if region == self.sym_data.us_region:
                self.region_productivity_growth_rates[
                    self.sym_data.regions_members[0]
                ] = self._us_productivity_growth_rates.copy()
                continue

            # Create the dataframe that will hold the indices for the region
            log_indices: pd.DataFrame = self._region_catchup_rates[region].copy()

            # Set the index in the first year to the fraction of US productivity
            # that is given in the parameters for each sector in each region
            log_indices.loc[:, first_year] = np.log(
                (self._region_productivity_ratios[region].loc[:, "ratio"].to_numpy())
            )

            # Iterate through the second year updating the indices
            previous_year: str = first_year
            for year in later_years:
                # The productivity index in the year is determined as US index in the same
                # year percentage gap in previous year adjusted for
                # a year of catch-up based on the catch-up rate over the previous year.
                log_indices.loc[:, year] = us_log_indices.loc[:, year] + (
                    1 - self._region_catchup_rates[region].loc[:, previous_year]
                ) * (
                    log_indices.loc[:, previous_year]
                    - us_log_indices.loc[:, previous_year]
                )
                previous_year = year

            # Now calculate the growth rates for the region from its indices
            # using log differences.
            growth_rates: pd.DataFrame = log_indices.copy()
            growth_rates.loc[:, earlier_years] = (
                log_indices.loc[:, later_years].to_numpy()
                - log_indices.loc[:, earlier_years].to_numpy()
            )

            # Handle the final year by assuming continuation of
            # the final year growth and catchup rates.
            final_year_log_indices: np.ndarray = log_indices[last_year].to_numpy()
            final_year_catchup_rates: np.ndarray = self._region_catchup_rates[region][
                last_year
            ].to_numpy()
            final_year_us_log_indices: np.ndarray = us_log_indices[last_year].to_numpy()
            next_year_us_log_indices: np.ndarray = (
                final_year_us_log_indices
                + self._us_productivity_growth_rates[last_year].to_numpy()
            )
            next_year_log_indices: np.ndarray = next_year_us_log_indices + (
                (1 - final_year_catchup_rates)
                * (final_year_log_indices - final_year_us_log_indices)
            )
            growth_rates[last_year] = next_year_log_indices - final_year_log_indices

            # Store the growth rates for the region
            self.region_productivity_growth_rates[region] = growth_rates

        # Clean up loaded productivity parameters and related information.
        delattr(self, "_us_productivity_growth_rates")
        delattr(self, "_region_productivity_ratios")
        delattr(self, "_region_catchup_rates")
        delattr(self, "_input")

    def __write_growth_rates_file(self):
        """

        ###Overview

        Responsible for writing out the productivity projections to a data CSV file
        using the name specified in the model configuration.

        """

        projections: pd.DataFrame = None
        for region in self.sym_data.regions_members:
            region_productivity: pd.DataFrame = self.productivity_growth_rates(
                region=region
            ).copy()

            new_index: pd.Index = pd.Index(
                [
                    f"{varname}({sector},{region})"
                    for sector in region_productivity.index
                ]
            )
            region_productivity.index = new_index
            if projections is None:
                projections = region_productivity
            else:
                projections = pd.concat([projections, region_productivity])

        projections *= 100.0
        projections.to_csv(
            self.configuration.modprod_file,
            index=True,
            header=True,
        )

        logging.warning(
            f"Create a new productivity growth rates file, {gcubed.file_summary(file_path=self.configuration.modprod_file)}"
        )

    def __load_from_growth_rates_file(self):
        """

        ###Overview

        Loads the growth rate prjections directly
        from the productivity growth rates file
        specified in the model configuration.

        This is useful in cases where the productivity growth rates
        have been manually adjusted.

        """

        assert os.path.exists(
            self.configuration.modprod_file
        ), f"The productivity growth rates file {self.configuration.modprod_file} does not exist. It should be regenerated automatically but something went wrong."

        projections: pd.DataFrame = (
            pd.read_csv(
                self.configuration.modprod_file,
                header=0,
                index_col=0,
            )
            / 100.0
        )

        for region in self.sym_data.regions_members:
            region_productivity: pd.DataFrame = projections.loc[
                [
                    f"{varname}({sector},{region})"
                    for sector in self.sym_data.sectors_members
                ],
                self.configuration.projection_years_column_labels,
            ]
            region_productivity.index = self.sym_data.sectors_members
            if region == self.sym_data.us_region:
                self._us_productivity_growth_rates = region_productivity
            self.region_productivity_growth_rates[region] = region_productivity
