"""
Parameter calibration.
"""

import logging
import pandas as pd
import numpy as np
from gcubed.model_parameters.parameters import Parameters
from gcubed.data.database import Database


class Parameters6G176ECBr9(Parameters):
    """
    This class does customised parameter calibration.
    """

    def __init__(self, database: Database, base_year: int) -> None:
        """
        ### Arguments

        `database`: The database used to calibrate the parameters.

        `base_year`: The base year that the database needs to be rebased to before
        calibration of the parameters.

        """
        super().__init__(database=database, base_year=base_year)

        self.__set_delta_ed()

        self.__set_delta_eG()

        # Required statements in all final subclasses of the parameter class.
        self._parameter_values.index = self._parameter_full_names
        self.validate()

    def validate(self):
        super().validate()

    def __set_delta_ed(self):
        """
        delta_ed (note the transpose before storing and vectorising )
        """

        delta_ed: pd.DataFrame = self.zeros(
            rows=self.sym_data.electricity_generation_goods_count,
            cols=self.sym_data.regions_count,
        )
        delta_ed.index = self.sym_data.electricity_generation_goods_members
        delta_ed.columns = self.sym_data.regions_members

        for region in self.sym_data.regions_members:
            io_table: pd.DataFrame = self._io_data.io_table(region)
            if io_table is None:
                raise Exception(f"There is no IO table for region {region}")

            # delta_ed
            if self.sym_data.electricity_generation_goods_count > 0:
                delta_ed_intermediate: pd.DataFrame = io_table.loc[
                    self.sym_data.electricity_generation_goods_members,
                    (self.sym_data.sectors_members[0]),
                ]
                delta_ed_intermediate = (
                    delta_ed_intermediate / delta_ed_intermediate.sum()
                )
                delta_ed.loc[:, region] = delta_ed_intermediate.to_numpy()
            else:
                pass  # delta_ed has been initialised to zeros so we are done.

        # Store delta_ed - after transposing it.
        delta_ed = delta_ed.transpose()
        self.insert_parameter(parameter_name="delta_ed", parameter_value=delta_ed)

    def __set_delta_eG(self):
        """
        Override the setting of delta_eG in the gcubed.parameters module.

        delta_eG - G: government column of IO table - energy sectors

        The original Ox calculation was:
        delta_eG[][i] = xx[1:numener][numsect+3] / sumc(xx[1:numener][numsect+3]);

        The new Ox calculation is:
        if (sumc(xx[1:numener][numsect+3])>0) {
            delta_eG[][i] = xx[1:numener][numsect+3] / sumc(xx[1:numener][numsect+3]);
        } else {
            delta_eG[][i] = 0;
        }

        """

        delta_eG: pd.DataFrame = pd.DataFrame(
            index=self.sym_data.energy_goods_members,
            columns=self.sym_data.regions_members,
        )
        delta_eG.index = self.sym_data.energy_goods_members
        delta_eG.columns = self.sym_data.regions_members
        delta_eG.loc[:, :] = 0.0
        delta_eG = delta_eG.astype(float)

        for region in self.sym_data.regions_members:
            io_table: pd.DataFrame = self._io_data.io_table(region)
            energy_goods_govt_io: pd.DataFrame = io_table.loc[
                self.sym_data.energy_goods_members, "G"
            ]
            energy_goods_govt_io_total: float = float(energy_goods_govt_io.sum())
            if energy_goods_govt_io_total > 0:
                energy_goods_govt_io /= energy_goods_govt_io_total
            delta_eG.loc[:, region] = energy_goods_govt_io.to_numpy()

        delta_eG.replace(0, 1e-40, inplace=True)
        self.insert_parameter("delta_eG", delta_eG)
