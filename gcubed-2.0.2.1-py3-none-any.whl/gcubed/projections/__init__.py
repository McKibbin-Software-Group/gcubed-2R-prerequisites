"""
This module contains the simulation experiment and projection functionality.

It also provides functions for :

1. computing differences between two sets of projections
2. computing percentage deviations between two sets of projections
3. obtaining an extract from a set of projections


"""

import logging
import pandas as pd
import numpy as np
import regex as re
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData
from gcubed.projections.projections import Projections
from gcubed.constants import Constants as CONSTANTS


def extract(
    projections: pd.DataFrame,
    variable_name_prefixes: list[str] = None,
    years: list = None,
) -> pd.DataFrame:
    """
    ### Overview

    Generates an extract of a projections dataframe.

    ### Arguments

    `projections`: A dataframe of projections - annotated or not annotated.

    `variable_name_prefixes`: A list of the prefixes for the variable names to include in the extract.
    Defaults to `None` which means that all variables will be included in the extract.

    `years`: A list of the years to include in the extract. Defaults to `None` which means
    that all years will be included in the extract.

    ### Returns

    A dataframe of the extract from the projections.

    ### Exceptions

    If the inputs are not valid, an exception is raised.

    """
    if variable_name_prefixes is None:
        filtered_projections: pd.DataFrame = projections
    else:
        filtered_projections: pd.DataFrame = projections[
            projections.index.str.startswith(tuple(variable_name_prefixes))
        ]

    if years is None:
        return filtered_projections
    else:
        return filtered_projections.loc[:, years]


def differences(
    new_projections: pd.DataFrame, original_projections: pd.DataFrame
) -> pd.DataFrame:
    """
    ### Overview

    Subtracts the second set of projections from the first set of projections.

    No changes are made to the units of the original projections.

    ### Arguments

    new_projections: A dataframe of projections

    original_projections: A second dataframe of projections

    Produce a dataframe of differences between two projections (new_projections - original_projections).

    Note that this can be used for raw, database, publishable and graphable projection types. However, the new
    and original projections must be the same type for the results to be meaningful.

    ### Exceptions

    Raises exceptions if the dataframes have different indexes or different columns.
    """

    if not new_projections.index.equals(original_projections.index):
        raise Exception(
            "The two sets of projections are not for identical lists of variables. Make sure they are both for the same model."
        )
    if not new_projections.columns.equals(original_projections.columns):
        raise Exception(
            "The two sets of projections are not for identical years so differences between them cannot be calculated."
        )

    # Determine the columns of the projections that contain data
    regular_expression = re.compile("[1-9][0-9]{3}")
    data_column_names = list(filter(regular_expression.match, new_projections.columns))

    # Start with a copy of the new projections to preserve non-data annotation columns.
    result: pd.DataFrame = new_projections.copy()

    # Subtract data values for the original projections
    result.loc[:, data_column_names] -= original_projections.loc[:, data_column_names]

    return result


def deviations(
    new_projections: Projections,
    original_projections: Projections,
) -> pd.DataFrame:
    """
    ### Overview

    Computes deviations between the new and original projections. The form of deviation that is computed depends on the units
    of the variables and the variables themselves.

    ### Arguments

    new_projections: The new projections

    original_projections: The original projections

    charting: `True` if the deviations are to be used for charting with the hypercube charting system. Defaults to `False`.

    ### Returns

    A dataframe of the deviations of the new publishable projections from the original publishable projections.

    The units for the resulting deviations are determined by the nature of the deviation that is computed.

    ### Exceptions

    Raises exceptions if the dataframes have different indexes or different columns.

    Raises exceptions if the dataframes are not annotated publishable projections.

    """

    # Get the new and the original annotated publishable projections.
    original_data: pd.DataFrame = original_projections.charting_projections
    new_data: pd.DataFrame = new_projections.charting_projections

    # First compute the differences.
    results: pd.DataFrame = differences(
        new_projections=new_data,
        original_projections=original_data,
    )

    # Determine the columns of the projections that contain data
    regular_expression = re.compile("[1-9][0-9]{3}")
    data_column_names = list(filter(regular_expression.match, results.columns))

    # Get metadata about the variables
    publication_units: pd.DataFrame = (
        original_projections.sym_data.variable_summary.loc[:, ["publication_units"]]
    )
    regions: pd.DataFrame = original_projections.sym_data.variable_summary.loc[
        :, ["region"]
    ]
    deviation_units: pd.DataFrame = (
        original_projections.sym_data.variable_summary.loc[:, ["deviation_units"]]
        + " deviation"
    )

    # No longer used. We just report NaN values in these cases now.
    # Determine variables where it is safe to calculate
    # percentage changes for all projection years.
    # because the new projections are zero in all
    # years where the original projections are zero or negative.
    # division_by_zero_check: pd.DataFrame = (
    #     original_data.loc[:, data_column_names] > 0
    # ) | (results.loc[:, data_column_names] == 0)
    # safe_to_compute_percentages = division_by_zero_check.all(axis=1)

    # Compute log-difference percent deviations for index variables
    # When computing log differences, for those cases where there is no change in
    # the variable, set the percentage change to zero.
    # even if the original value is non-positive.
    # Note that this will not guarantee replacement of all NaN values in the deviations.
    # because there may be some perverse cases where the numerator or denominator is
    # negative but there has been a change between the original and the new values.
    index_mask = publication_units["publication_units"].isin(["index"])
    percentage_changes: pd.DataFrame = 100.0 * (
        np.log(
            np.where(
                new_data.loc[index_mask, data_column_names] > 0,
                new_data.loc[index_mask, data_column_names],
                np.nan,
            )
        )
        - np.log(
            np.where(
                original_data.loc[index_mask, data_column_names] > 0,
                original_data.loc[index_mask, data_column_names],
                np.nan,
            )
        )
    )
    percentage_changes[results.loc[index_mask, data_column_names] == 0] = 0
    results.loc[index_mask, data_column_names] = percentage_changes

    # Compute percentage point deviations for pct variables
    # Already done using the differences.

    # Compute percentage point deviations for del variables
    # Already done using the differences.

    # Compute the deviations for dollar units
    # Already done using the differences.

    # Compute percent deviations where possible for mmt, btu and gwh
    quantities_mask = publication_units["publication_units"].isin(["mmt", "btu", "gwh"])
    percentage_changes: pd.DataFrame = 100.0 * (
        np.log(
            np.where(
                new_data.loc[quantities_mask, data_column_names] > 0,
                new_data.loc[quantities_mask, data_column_names],
                np.nan,
            )
        )
        - np.log(
            np.where(
                original_data.loc[quantities_mask, data_column_names] > 0,
                original_data.loc[quantities_mask, data_column_names],
                np.nan,
            )
        )
    )
    percentage_changes[results.loc[quantities_mask, data_column_names] == 0] = 0
    results.loc[quantities_mask, data_column_names] = percentage_changes

    # Save the original projections of GDPR for all regions. These will be used for scaling.
    original_gdpr_projections: pd.DataFrame = original_data.loc[
        original_data.index.str.startswith(f"{CONSTANTS().GDPR_PREFIX}("), :
    ]

    # Compute percent of GDP deviations for all $US billion variables that are not for a specific sector or good.
    usbillions_mask = publication_units["publication_units"].isin(["$US billion"])
    labo_mask = original_data.index.str.startswith("LABO(")
    sector_mask = original_projections.sym_data.variable_summary.sets.str.contains(
        "sec"
    ) | original_projections.sym_data.variable_summary.sets.str.contains("good")
    usbillions_percent_of_gdp_mask = usbillions_mask & ~(sector_mask | labo_mask)
    for region in original_projections.sym_data.regions_members:
        region_mask: list[bool] = usbillions_percent_of_gdp_mask & (
            regions["region"] == region
        )
        results.loc[region_mask, data_column_names] = (
            100.0
            * results.loc[region_mask, data_column_names]
            / original_gdpr_projections.loc[
                original_gdpr_projections.region == region, data_column_names
            ].to_numpy()
        )

    us_billions_percentage_change_mask = usbillions_mask & (sector_mask | labo_mask)
    percentage_changes: pd.DataFrame = 100.0 * (
        np.log(
            np.where(
                new_data.loc[us_billions_percentage_change_mask, data_column_names] > 0,
                new_data.loc[us_billions_percentage_change_mask, data_column_names],
                np.nan,
            )
        )
        - np.log(
            np.where(
                original_data.loc[us_billions_percentage_change_mask, data_column_names]
                > 0,
                original_data.loc[
                    us_billions_percentage_change_mask, data_column_names
                ],
                np.nan,
            )
        )
    )
    percentage_changes[
        results.loc[us_billions_percentage_change_mask, data_column_names] == 0
    ] = 0
    results.loc[us_billions_percentage_change_mask, data_column_names] = (
        percentage_changes
    )
    deviation_units.loc[us_billions_percentage_change_mask, :] = "percent deviation"

    # LGDPR and LGDPN deviations
    lgdp_mask = publication_units["publication_units"].isin(
        ["nomusdbillion", "realusdbillion"]
    )
    percentage_changes: pd.DataFrame = 100.0 * (
        np.log(
            np.where(
                new_data.loc[lgdp_mask, data_column_names] > 0,
                new_data.loc[lgdp_mask, data_column_names],
                np.nan,
            )
        )
        - np.log(
            np.where(
                original_data.loc[lgdp_mask, data_column_names] > 0,
                original_data.loc[lgdp_mask, data_column_names],
                np.nan,
            )
        )
    )
    percentage_changes[results.loc[lgdp_mask, data_column_names] == 0] = 0
    results.loc[lgdp_mask, data_column_names] = percentage_changes

    # Issue a warning if the deviations contain NaN values
    rows_with_nan = results.loc[:, data_column_names].isnull().any(axis=1)
    indices_with_nan: list[str] = list(rows_with_nan[rows_with_nan].index)
    if len(indices_with_nan) > 0:
        logging.warning(
            f"Some variables have missing (NaN) deviation values, typically because their level projections were infinite or negative."
        )

    # Set the units for the deviations
    deviation_units.columns = ["units"]
    results.loc[:, "units"] = deviation_units

    return results


def adjusted_publishable_projections(
    original_projections: Projections,
) -> pd.DataFrame:
    """
    ### Overview

    Ensures GDP aggregates add up across consumption, investment
    government and trade.

    ### Arguments

    `original_projections`: A a projections object that provides access to model
    details as well as the publishable projections that are to be adjusted.

    ### Returns

    A dataframe of adjusted publishable projections in levels.

    """
    projections = original_projections.publishable_projections.copy()
    names = projections.index.str
    configuration: ModelConfiguration = original_projections.configuration
    sym_data: SymData = original_projections.sym_data

    # Get the column labels for the projection years.
    years: list[str] = list(
        [
            str(year)
            for year in range(
                configuration.first_projection_year,
                configuration.last_publishable_projection_year + 1,
            )
        ]
    )

    # --------------------------------------------------------------------
    # Investment - Constant adjustment to fix the INVT database issue
    # where INVZ and INVY are not part of the database INVT.
    # --------------------------------------------------------------------
    original_INVT: pd.DataFrame = projections.loc[names.startswith(f"INVT("), :]
    INVY: pd.DataFrame = projections.loc[names.startswith(f"INVY("), :]
    INVZ: pd.DataFrame = projections.loc[names.startswith(f"INVZ("), :]
    INV: pd.DataFrame = projections.loc[names.startswith(f"INV("), :]

    components_INVT: pd.DataFrame = original_INVT.copy()
    components_INVT.loc[:, years] = (
        INVY.loc[:, years].to_numpy() + INVZ.loc[:, years].to_numpy()
    )
    for region in sym_data.regions_members:
        region_INV = projections.loc[names.match(rf"INV\(.+\b{region}\)"), years]
        aggregate_INV = np.array([region_INV.loc[:, years].sum().values])
        components_INVT.loc[[f"INVT({region})"], years] += aggregate_INV

    projections.loc[names.startswith(f"INVT("), years] = components_INVT.loc[:, years]

    # Adjust GDPR to reflect the INVT fix above (add new INVT and remove old INVT)
    projections.loc[names.startswith(f"GDPR("), years] += (
        projections.loc[names.startswith(f"INVT("), years].to_numpy()
        - original_INVT.loc[:, years].to_numpy()
    )

    # --------------------------------------------------------------------
    # Scale GDP components
    # --------------------------------------------------------------------
    GDPR: pd.DataFrame = projections.loc[names.startswith(f"GDPR("), :]
    CONP: pd.DataFrame = projections.loc[names.startswith(f"CONP("), :]
    GCET: pd.DataFrame = projections.loc[names.startswith(f"GCET("), :]
    INVT: pd.DataFrame = projections.loc[names.startswith(f"INVT("), :]
    TBAL: pd.DataFrame = projections.loc[names.startswith(f"TBAL("), :]

    components_GDPR: pd.DataFrame = GDPR.copy()
    components_GDPR.loc[:, years] = (
        CONP.loc[:, years].to_numpy()
        + GCET.loc[:, years].to_numpy()
        + INVT.loc[:, years].to_numpy()
        + TBAL.loc[:, years].to_numpy()
    )
    scale_factor: pd.DataFrame = GDPR.loc[:, years].div(components_GDPR.loc[:, years])

    projections.loc[names.startswith(f"CONP("), years] *= scale_factor.to_numpy()
    projections.loc[names.startswith(f"GCET("), years] *= scale_factor.to_numpy()
    projections.loc[names.startswith(f"INVT("), years] *= scale_factor.to_numpy()
    projections.loc[names.startswith(f"TBAL("), years] *= scale_factor.to_numpy()

    # --------------------------------------------------------------------
    # Scale investment components
    # --------------------------------------------------------------------
    INVT: pd.DataFrame = projections.loc[names.startswith(f"INVT("), :]
    INVY: pd.DataFrame = projections.loc[names.startswith(f"INVY("), :]
    INVZ: pd.DataFrame = projections.loc[names.startswith(f"INVZ("), :]

    components_INVT: pd.DataFrame = INVT.copy()
    components_INVT.loc[:, years] = (
        INVY.loc[:, years].to_numpy() + INVZ.loc[:, years].to_numpy()
    )
    for region in sym_data.regions_members:
        region_INV = projections.loc[names.match(rf"INV\(.+\b{region}\)"), years]
        aggregate_INV = np.array([region_INV.loc[:, years].sum().values])
        components_INVT.loc[[f"INVT({region})"], years] += aggregate_INV

    for sector in sym_data.standard_sectors_members:
        projections.loc[
            names.match(rf"INV\({sector}\b.*\)"), years
        ] *= scale_factor.to_numpy()
    projections.loc[names.startswith(f"INVY("), years] *= scale_factor.to_numpy()
    projections.loc[names.startswith(f"INVZ("), years] *= scale_factor.to_numpy()

    # --------------------------------------------------------------------
    # Scale consumption components
    # --------------------------------------------------------------------
    CONP: pd.DataFrame = projections.loc[names.startswith(f"CONP("), :].copy()
    CNPE: pd.DataFrame = projections.loc[names.startswith(f"CNPE("), :]
    CNPO: pd.DataFrame = projections.loc[names.startswith(f"CNPO("), :]
    CNPK: pd.DataFrame = projections.loc[names.startswith(f"CNPK("), :]
    CNPL: pd.DataFrame = projections.loc[names.startswith(f"CNPL("), :]

    components_CONP: pd.DataFrame = CONP.copy()
    components_CONP.loc[:, years] = (
        CNPE.loc[:, years].to_numpy()
        + CNPO.loc[:, years].to_numpy()
        + CNPK.loc[:, years].to_numpy()
        + CNPL.loc[:, years].to_numpy()
    )
    scale_factor: pd.DataFrame = CONP.loc[:, years].div(components_CONP.loc[:, years])

    projections.loc[names.startswith(f"CNPE("), years] *= scale_factor.to_numpy()
    projections.loc[names.startswith(f"CNPO("), years] *= scale_factor.to_numpy()
    projections.loc[names.startswith(f"CNPK("), years] *= scale_factor.to_numpy()
    projections.loc[names.startswith(f"CNPL("), years] *= scale_factor.to_numpy()

    # --------------------------------------------------------------------
    # Scale consumption for energy goods
    # --------------------------------------------------------------------
    if sym_data.energy_goods_count > 0:
        CNPE: pd.DataFrame = projections.loc[names.startswith(f"CNPE("), :]

        components_CNPE: pd.DataFrame = CNPE.copy()
        components_CNPE.loc[:, years] *= 0.0

        for region in sym_data.regions_members:
            aggregate_CON: pd.DataFrame = components_CNPE.loc[
                [f"CNPE({region})"], years
            ].copy()
            aggregate_CON.loc[:, years] *= 0.0
            for good in sym_data.energy_goods_members:
                CON = projections.loc[names.match(rf"CON\({good},{region}\)"), years]
                if len(CON.index) > 0:
                    aggregate_CON += CON.to_numpy()
            components_CNPE.loc[[f"CNPE({region})"], years] = aggregate_CON
        scale_factor: pd.DataFrame = CNPE.loc[:, years].div(
            components_CNPE.loc[:, years]
        )

        for good in sym_data.energy_goods_members:
            projections.loc[
                names.startswith(f"CON({good}"), years
            ] *= scale_factor.to_numpy()

    # --------------------------------------------------------------------
    # Scale consumption for ordinary goods
    # --------------------------------------------------------------------
    if sym_data.material_goods_count > 0:
        CNPO: pd.DataFrame = projections.loc[names.startswith(f"CNPO("), :]

        components_CNPO: pd.DataFrame = CNPO.copy()
        components_CNPO.loc[:, years] *= 0.0

        for region in sym_data.regions_members:
            aggregate_CON: pd.DataFrame = components_CNPO.loc[
                [f"CNPO({region})"], years
            ].copy()
            aggregate_CON.loc[:, years] *= 0.0
            for good in sym_data.material_goods_members:
                CON = projections.loc[names.match(rf"CON\({good},{region}\)"), years]
                if len(CON.index) > 0:
                    aggregate_CON += CON.to_numpy()
            components_CNPO.loc[[f"CNPO({region})"], years] = aggregate_CON
        scale_factor: pd.DataFrame = CNPO.loc[:, years].div(
            components_CNPO.loc[:, years]
        )

        for good in sym_data.material_goods_members:
            selector: pd.Series = names.startswith(f"CON({good}")
            if selector.any():
                projections.loc[selector, years] *= scale_factor.to_numpy()

    return projections
