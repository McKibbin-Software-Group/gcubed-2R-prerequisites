"""
This module contains the `SymData` class, which loads and provides access to all of the
information about the model contained in the SYM model definition.
"""

import logging
import warnings
import os
import pandas as pd
import regex as re
import gcubed
from gcubed.model_configuration import ModelConfiguration


class SymData:
    """

    #### Overview

    The model equations are expressed in terms of various vectors of variables
    and a vector of parameters.

    Each vector is a different type of variable.
    Note the naming conventions for the lefthand side (LHS) variable vectors:

    a. `x1l` - the vector of left-hand side state variables
    b. `j1l` - the vector of left-hand side costate or jump variables
    c. `zel` - the vector of left-hand side expected endogenous variables
    d. `z1l` - the vector of left-hand side endogenous variables

    These 4 vectors of variables are functions of:

    1. `x1r` is right-hand side state variables
    2. `j1r` is right-hand side costate or jump variables
    3. `zer` is right-hand side endogenous variables LOGY, PRCT, PRID
    4. `exz` is right-hand side the lead expected ze variables
    5. `yxr` is right-hand side state variables lagged by 1 period
    6. `yjr` is right-hand side costate variables lagged by 1 period
    7. `exo` is exogenous variables (by definition only appearing on the right-hand side)
    8. `z1r` is right-hand side endogenous variables.

    The parameters are a vector of parameters, `par`.

    """

    # Class properties reducing the need to instantiate these lists on each call.
    _lhs_vector_names: list[str] = ["x1l", "j1l", "zel", "z1l"]
    _rhs_vector_names: list[str] = [
        "x1r",
        "j1r",
        "zer",
        "exz",
        "yxr",
        "yjr",
        "exo",
        "z1r",
    ]

    _ssf_rhs_vector_names: list[str] = ["exz", "yxr", "yjr", "exo"]

    # Those vectors that are projected forward using the model
    _projection_vector_names: list[str] = ["x1l", "j1l", "zel", "z1l", "exo"]

    def vector_type(self, vector_name: str) -> str:
        """
        ### Overview

        Convert a vector name in the model to the type of variable it represents
        as defined by the variable summary `var_type` column.

        ### Arguments

        `vector_name`: The name of the vector (any one of the LHS or RHS vector names)

        ### Exceptions

        Raises an exception if the vector name is not recognised.

        """

        match vector_name:
            case "x1l" | "x1r" | "yxr":
                return "x1l"
            case "j1l" | "j1r" | "yjr":
                return "j1l"
            case "zel" | "zer" | "exz":
                return "zel"
            case "z1l" | "z1r":
                return "z1l"
            case "exo":
                return "exo"

        assert (
            False
        ), f"Invalid vector name {vector_name}. Could not determine its type."

    def __init__(self, configuration: ModelConfiguration) -> None:
        """

        ### Constructor

        Loads and provides access to all of the information about the model contained
        in the SYM model definition.

        ### Arguments

        `configuration`: The configuration details for the model.

        """

        assert isinstance(configuration, ModelConfiguration)
        self._configuration = configuration
        self.__load_vars()
        self.__load_varinfo()
        self.__load_varmap()
        self.__load_model_summary()
        self.__summarise_sym_information()
        self.__generate_variable_summary()
        self.__validate()

    @property
    def configuration(self):
        """
        The configuration details for the model.
        """
        return self._configuration

    @property
    def var_info(self) -> pd.DataFrame:
        """
        The dataframe of information about the model variables, loaded from the var_info file
        produced by processing the SYM model definition with the SYM processor.
        """
        return self._variable_information

    @property
    def var_map(self) -> pd.DataFrame:
        """
        The dataframe containing the map of the model variables, loaded from the var_map file
        produced by processing the SYM model definition with the SYM processor.
        """
        return self._variable_map

    def matching_rhs_vector_name(self, lhs_vector_name: str) -> str:
        """

        ### Arguments

         `lhs_vector_name`: the name of the LHS vector.

        ### Returns

         the matching RHS vector name, replacing the last character, l, with an r.
        """
        return f"{lhs_vector_name[0:2]}r"

    def varmap_variable_type(self, vector_name: str):
        """
        Convert a vector name in the model to the varmap file variable type to lookup for
        the varmap information associated with the vector.
        """
        match vector_name:
            case "x1r" | "x1l":
                return "x1l"
            case "yxr":
                return "x1l"
            case "j1r" | "j1l":
                return "j1l"
            case "yjr":
                return "j1l"
            case "zer" | "zel":
                return "zel"
            case "exz":
                return "zel"
            case "z1r" | "z1l":
                return "z1l"
            case "exo":
                return "exo"
            case _:  # LHS vector names.
                raise Exception(
                    f"Requested varmap variable type for a vector {vector_name} that is not defined by the SYM processor."
                )

    def projection_vector_for_variable(self, variable_name: str) -> str:
        """
        ### Arguments

         `vector_name`: The fully qualified name of the variable

         ### Returns

         The string ID of the projection vector that the variable is in.
        """
        var_types: pd.Series = self.var_map.loc[[variable_name], "var_type"]
        if len(var_types) == 0:
            raise Exception(f"{variable_name} is not declared in the SYM model.")
        vector_name = var_types.values[0]
        return self.varmap_variable_type(vector_name=vector_name)

    @property
    def set_memberships(self) -> dict[str, list[str]]:
        """
        A dictionary mapping from a set name
        to the list of set members, in the order
        in which they were defined in the SYM model
        definition.
        """
        return self._set_memberships

    def set_members(self, set_name: str) -> str:
        """
        ### Arguments

        `set_name`: The name of the SYM model definition set of interest, e.g. 'region'.

        ### Returns

        The members of the named set, as a list of strings, or the empty list if
        the named set is not part of the SYM model definition.

        """
        if set_name in self.set_memberships:
            return self.set_memberships[set_name]
        return []

    @property
    def set_descriptions(self) -> dict[str, str]:
        """
        A dictionary mapping from set name to set description.
        """
        return self._set_descriptions

    def set_description(self, set_name: str) -> str:
        """
        ### Arguments
        `set_name`: The name of the set.

        ### Returns
        The description of the set.
        """
        if set_name in self.set_descriptions:
            return self.set_descriptions[set_name]
        return set_name

    @property
    def set_member_descriptions(self) -> dict[str, str]:
        """
        A dictionary mapping from set member name to
        set member description.
        """
        return self._set_member_descriptions

    def set_member_description(self, set_member_name: str) -> str:
        """
        ### Arguments
        `set_member_name`: The name of the set member.

        ### Returns
        The description of the set member.
        """
        if set_member_name in self.set_member_descriptions:
            return self.set_member_descriptions[set_member_name]
        return set_member_name

    def __set_members_count(self, set_name: str) -> int:
        """
        ### Arguments

        `set_name`: The name of the SYM model definition set of interest, e.g. 'region'.

        ### Returns

        The number of members of the named set.

        """
        members = self.set_members(set_name)
        if members:
            return len(members)
        return 0

    @property
    def goods_members(self) -> list[str]:
        """
        The list of goods produced in the economy. These are the members of the
        `goods` set, that is a part of every G-Cubed model SYM definition.
        """
        return self.set_members("goods")

    @property
    def goods_count(self) -> int:
        """
        The number of goods produced in the economy. These are the members of the
        `goods` set, that is a part of every G-Cubed model SYM definition.
        """
        return self.__set_members_count("goods")

    @property
    def energy_goods_members(self) -> list[str]:
        """
        The list of energy goods produced in the economy. These are the outputs
        of the energy producing sectors in the economy.

        They are identified by being  members of the `goods_e` set, that is a part of
        every G-Cubed model SYM definition.
        """
        return self.set_members("goods_e")

    @property  # numener # g01 for version R of the model
    def energy_goods_count(self) -> int:
        """
        The number of energy goods produced in the economy. These are the outputs
        of sectors in the economy that deal with extraction and value addition for
        fuel sources (e.g.coal, gas, oil, petroleum refining etc) as well as the
        electricity distribution sector.

        They are identified by being members of the `goods_e` set, that is a part of
        every G-Cubed model SYM definition.
        """
        return self.__set_members_count("goods_e")

    @property
    def electricity_generation_goods_members(self) -> list[str]:
        """
        The list of goods in the economy that are produced by electricity generation sectors.
        All of those sectors produce electricity, so their output is the same in some sense. However,
        the output of each industry is identified by its own 'good' identifier.

        They are identified by being  members of the `goods_g` set.
        """
        return self.set_members("goods_g")

    @property
    def electricity_generation_goods_count(self) -> int:
        """
        The number of goods in the economy that are produced by electricity generation sectors.
        All of those sectors produce electricity, so their output is the same in some sense. However,
        the output of each industry is identified by its own 'good' identifier.

        They are identified by being  members of the `goods_g` set.
        """
        return self.__set_members_count("goods_g")

    @property
    def non_energy_goods_members(self) -> list[str]:
        """
        The list of goods in the economy that are not
        energy goods (those that are members of the `goods_e` set).
        """
        match self.configuration.version:
            case "2R" | "6G":
                return self.set_members("goods_m")
            case _:
                return self.set_members("goods_n")

    @property
    def non_energy_goods_count(self) -> int:
        """
        The number of goods in the economy that are not
        energy goods (those that are members of the `goods_e` set).
        """
        match self.configuration.version:
            case "2R" | "6G":
                return self.__set_members_count("goods_m")
            case _:
                return self.__set_members_count("goods_n")

    @property
    def non_electricity_generation_goods_members(self) -> list[str]:
        """
        The list of goods in the economy that are not
        electricity generation goods (those that are members of the `goods_g` set).
        """
        return self.set_members("goods_o")

    @property
    def non_electricity_generation_goods_count(self) -> int:
        """
        The number of goods in the economy that are not
        electricity generation goods (those that are members of the `goods_g` set).
        """
        return self.__set_members_count("goods_o")

    @property
    def has_electricity_distribution_good(self) -> bool:
        """
        A flag indicating whether the model has an electricity distribution good.
        """
        result: list[str] = self.set_members(set_name="good_electricity_distribution")
        return len(result) > 0

    @property
    def electricity_distribution_good(self) -> str:
        """
        The list of electricity distribution goods produced in the model.

        Typically, this is a single good is only defined in models that break out electricity into
        a single distribution sector that aggregates the output from one or more electricity
        generation sectors.

        ### Exceptions

        Raises an exception if the electricity distribution good is not defined in the model.
        """
        result: list[str] = self.set_members(set_name="good_electricity_distribution")
        if result:
            return result[0]
        raise Exception(
            f"An electricity distribution good is not defined in model version {self.configuration.version}."
        )
        return self.set_members("")

    @property
    def standard_goods_members(self) -> list[str]:
        """
        The list of sectors explicitly defined in the SYM model definition that
        have a standard treatment of their production functions (this typically just excludes
        the electricity distribution sector).
        """
        standard_sectors: list[str] = self.standard_sectors_members
        return self.goods_produced_by(standard_sectors)

    # Note that if there is no electricity distribution sectors, then distribution is lumped in with
    # the more broadly defined energy sector(s).
    @property  # numsecstd
    def standard_goods_count(self) -> int:
        """
        The number of sectors explicitly defined in the SYM model definition that are
        not responsible for electricity distribution.
        """
        return self.__set_members_count("sec_std")

    @property
    def material_goods_members(self) -> list[str]:
        """
        The list of material goods in the economy (those that
        are not energy goods or electricity generation goods).
        """
        return self.set_members("goods_m")

    @property
    def material_goods_count(self) -> int:
        """
        The number of material goods in the economy (those that
        are not energy goods or electricity generation goods).
        """
        return self.__set_members_count("goods_m")

    @property
    def ordinary_nondurable_goods_members(self) -> list[str]:
        """
        The list of non-durable goods in the economy that are not
        electricity generation goods.
        """
        return self.set_members("goods_oc")

    @property
    def ordinary_nondurable_goods_count(self) -> int:
        """
        The number of non-durable goods in the economy that are not
        electricity generation goods.
        """
        return self.__set_members_count("goods_oc")

    @property
    def has_durable_manufacturing_good(self) -> bool:
        """
        A flag indicating whether the model has a durable manufacturing good.
        """
        result: list[str] = self.set_members(set_name="good_durable_manufacturing")
        return len(result) > 0

    @property
    def durable_manufacturing_good(self) -> list[str]:
        """
        The durable manufacturing good produced in the economy.

        Typically there is a single sector producing a single durable
        manufacturing good.

        The exception is the 2 sector model where there is no durable
        manufacturing good.

        ### Exceptions

        Raises an exception if the durable manufacturing good is not defined in the model.
        """
        result: list[str] = self.set_members(set_name="good_durable_manufacturing")
        if result:
            return result[0]
        raise Exception(
            f"There is no durable manufacturing good in model version {self.configuration.version}."
        )

    @property
    def capital_sectors_members(self) -> list[str]:
        """
        The capital sectors that are part of all G-Cubed models. There are two of them:

        1. sector Y, the sector that produces capital for firms.

        2. sector Z, the sector that produces capital for households.

        """
        return ["Y", "Z"]

    @property
    def all_sectors_members(self) -> list[str]:
        """
        The list of all sectors defined in the SYM model definition plus the
        two capital producing sectors that are common to all model versions.
        """
        result = self.set_members("sectors")
        for capital_sector in self.capital_sectors_members:
            result.append(capital_sector)
        return result

    @property  # numsect # a01,a02, Y and Z for version R of the model
    def all_sectors_count(self) -> int:
        """
        The number of sectors defined in the SYM model definition plus the
        two capital producing sectors that are common to all model versions.
        """
        return len(self.all_sectors_members)

    @property
    def sectors_members(self) -> list[str]:
        """
        The list of sectors that are explicitly defined in the SYM model definition.
        These are the members of the `sectors` set.

        The list does not include the two capital producing sectors
        that are common to all model versions.
        """
        return self.set_members("sectors")

    @property  # numsect # a01,a02 for version R of the model
    def sectors_count(self) -> int:
        """
        The number of sectors that are explicitly defined in the SYM model definition.
        These are the members of the `sectors` set.

        The number does not include the two capital producing sectors
        that are common to all model versions.
        """
        return self.__set_members_count("sectors")

    @property
    def non_energy_or_generation_sectors_members(self) -> list[str]:
        """
        The list of sectors explicitly defined in the SYM model definition except
        for sectors that are involved in electricity generation or energy.
        """
        return self.sectors_producing(self.material_goods_members)

    @property
    def has_electricity_distribution_sector(self) -> bool:
        """
        A flag indicating whether the model has an electricity distribution sector.
        """
        result: list[str] = self.set_members(set_name="sec_ed")
        return len(result) > 0

    @property
    def electricity_distribution_sector(self) -> str:
        """
        The list of sectors explicitly defined in the SYM model definition that are
        responsible for electricity distribution.

        This is typically just the first sector, in those models that include such a sector.

        ### Exceptions

        Raises an exception if the electricity distribution sector is not defined in the model.

        """
        result: list[str] = self.set_members(set_name="sec_ed")
        if result:
            return result[0]
        raise Exception(
            f"An electricity distribution sector is not defined in model version {self.configuration.version}."
        )

    @property
    def has_electricity_generation_sectors(self) -> bool:
        """
        A boolean flag indicating whether the model has electricity generation sectors.
        """
        result: list[str] = self.set_members(set_name="sectors_g")
        return len(result) > 0

    @property
    def electricity_generation_sectors_members(self) -> list[str]:
        """
        The list of sectors explicitly defined in the SYM model definition that are
        responsible for electricity distribution.

        """
        return self.set_members("sectors_g")

    @property
    def electricity_generation_sectors_count(self) -> int:
        """
        The number of sectors explicitly defined in the SYM model definition except
        for sectors that are involved in electricity generation.
        """
        return self.__set_members_count("sectors_g")

    @property
    def non_electricity_generation_sectors_members(self) -> list[str]:
        """
        The list of sectors explicitly defined in the SYM model definition except
        for sectors that are involved in electricity generation.
        """
        return self.set_members("sectors_o")

    @property
    def non_electricity_generation_sectors_count(self) -> int:
        """
        The number of sectors explicitly defined in the SYM model definition that are
        not responsible for electricity generation.
        """
        return self.__set_members_count("sectors_o")

    @property
    def standard_sectors_members(self) -> list[str]:
        """
        The list of sectors explicitly defined in the SYM model definition that
        have a standard treatment of their production functions (this typically just excludes
        the electricity distribution sector).
        """
        return self.set_members(set_name="sec_std")

    # Note that if there is no electricity distribution sectors, then distribution is lumped in with
    # the more broadly defined energy sector(s).
    @property  # numsecstd
    def standard_sectors_count(self) -> int:
        """
        The number of sectors explicitly defined in the SYM model definition that are
        not responsible for electricity distribution.
        """
        return self.__set_members_count("sec_std")

    @property
    def non_energy_sectors_members(self) -> list[str]:
        """
        The list of sectors explicitly defined in the SYM model definition that are
        not responsible for electricity distribution.
        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "22P":
                return self.set_members("sectors_m")
            case _:
                return self.set_members("sectors_n")

    @property
    def non_energy_sectors_count(self) -> int:
        """
        The number of sectors explicitly defined in the SYM model definition that are
        not responsible for electricity distribution.
        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "22P":
                return self.__set_members_count("sectors_m")
            case _:
                return self.__set_members_count("sectors_n")

    @property
    def material_sectors_members(self) -> list[str]:
        """
        The list of sectors producting material goods in the economy (those that
        are not energy goods or electricity generation goods).
        """
        return self.set_members("sectors_m")

    @property
    def material_sectors_count(self) -> int:
        """
        The number of sectors producing material goods in the economy (those that
        are not energy goods or electricity generation goods).
        """
        return self.__set_members_count("sectors_m")

    @property
    def gas_sector(self) -> str:
        """
        The string identifier of the gas sector.

        Model versions with more than 2 sectors typically include a gas sector.

        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "22P":
                result: list[str] = self.set_members(set_name="sector_gas")
                if result:
                    return result[0]
            case _:
                raise Exception(
                    f"Gas production is not defined in model version {self.configuration.version}."
                )

    @property
    def oil_sector(self) -> str:
        """
        The string identifier of the oil refining sector.
        This is currently the sector associated with oil-related carbon emissions.
        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "22P":
                result: list[str] = self.set_members(set_name="sector_oil_refining")
                if result:
                    return result[0]
        raise Exception(
            f"Oil production is not defined in model version {self.configuration.version}."
        )

    @property
    def coal_sector(self) -> str:
        """
        The string identifier of the coal sector
        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "22P":
                result: list[str] = self.set_members(set_name="good_coal")
                if result:
                    return result[0]
        raise Exception(
            f"Coal production is not defined in model version {self.configuration.version}."
        )

    @property
    def coal_generation_sector(self) -> str:
        """
        The string identifier of the coal generation sector
        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "22P":
                result: list[str] = self.set_members(set_name="sector_coal_generation")
                if result:
                    return result[0]
        raise Exception(
            f"Coal generation is not defined in model version {self.configuration.version}."
        )

    @property
    def gas_generation_sector(self) -> str:
        """
        The string identifier of the gas generation sector
        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "22P":
                result: list[str] = self.set_members(set_name="sector_gas_generation")
                if result:
                    return result[0]
        raise Exception(
            f"Gas generation is not defined in model version {self.configuration.version}."
        )

    @property
    def oil_generation_sector(self) -> str:
        """
        The string identifier of the oil generation sector
        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "22P":
                result: list[str] = self.set_members(set_name="sector_oil_generation")
                if result:
                    return result[0]
        raise Exception(
            f"Oil generation is not defined in model version {self.configuration.version}."
        )

    @property
    def nuclear_generation_sector(self) -> str:
        """
        The string identifier of the nuclear generation sector
        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "22P":
                result: list[str] = self.set_members(
                    set_name="sector_nuclear_generation"
                )
                if result:
                    return result[0]
        raise Exception(
            f"Nuclear generation is not defined in model version {self.configuration.version}."
        )

    @property
    def wind_generation_sector(self) -> str:
        """
        The string identifier of the wind generation sector
        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "22P":
                result: list[str] = self.set_members(set_name="sector_wind_generation")
                if result:
                    return result[0]
        raise Exception(
            f"Wind generation is not defined in model version {self.configuration.version}."
        )

    @property
    def solar_generation_sector(self) -> str:
        """
        The string identifier of the solar generation sector
        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "22P":
                result: list[str] = self.set_members(set_name="sector_solar_generation")
                if result:
                    return result[0]
        raise Exception(
            f"Solar generation is not defined in model version {self.configuration.version}."
        )

    @property
    def hydro_generation_sector(self) -> str:
        """
        The string identifier of the hydro generation sector
        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "22P":
                result: list[str] = self.set_members(set_name="sector_hydro_generation")
                if result:
                    return result[0]
        raise Exception(
            f"Hydro generation is not defined in model version {self.configuration.version}."
        )

    @property
    def other_generation_sector(self) -> str:
        """
        The string identifier of the other generation sector
        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "22P":
                result: list[str] = self.set_members(set_name="sector_other_generation")
                if result:
                    return result[0]
        raise Exception(
            f"Other generation is not defined in model version {self.configuration.version}."
        )

    @property
    def services_sector(self) -> str:
        """
        The string identifier of the services sector
        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "6G":
                result: list[str] = self.set_members(set_name="sector_services")
                if result:
                    return result[0]
        raise Exception(
            f"Services sector is not defined in model version {self.configuration.version}."
        )

    @property
    def has_durable_manufacturing_sector(self) -> bool:
        """
        A flag indicating whether the model has a durable manufacturing sector.
        """
        result: list[str] = self.set_members(set_name="sector_durable_manufacturing")
        return len(result) > 0

    @property
    def durable_manufacturing_sector(self) -> list[str]:
        """
        The durable manufacturing sector in the economy.

        Typically there is a single sector producing a single durable
        manufacturing good.

        The exception is the 2 sector model where there is no durable
        manufacturing good.

        ### Exceptions

        Raises an exception if the durable manufacturing sector is not defined in the model.

        """
        result: list[str] = self.set_members(set_name="sector_durable_manufacturing")
        if result:
            return result[0]
        raise Exception(
            f"There is no durable manufacturing sector in model version {self.configuration.version}."
        )

    @property
    def regions_members(self) -> list[str]:
        """
        The list of regions explicitly defined in the SYM model definition as part
        of the `regions` set.
        """
        return self.set_members(set_name="regions")

    @property  # countopt
    def regions_count(self) -> int:
        """
        The number of regions explicitly defined in the SYM model definition as part
        of the `regions` set.
        """
        return self.__set_members_count("regions")

    @property
    def us_region(self) -> str:
        """
        The string identifier of the USA region. This must always be the first region
        defined in the SYM `regions` set and it will be the first region in the list
        of region members.
        """
        return self.regions_members[0]

    @property
    def gas_sector_good(self) -> str:
        """
        The string identifier of the good produced by the sector that
        includes gas extraction and gas utilities.
        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "22P":
                return self.set_members(set_name="good_gas")
            case _:
                raise Exception(
                    f"Gas production is not defined in model version {self.configuration.version}."
                )

    @property
    def oil_sector_good(self) -> str:
        """
        The string identifier of the good produced by the oil refining sector.
        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "22P":
                return self.set_members(set_name="good_oil_refining")
            case _:
                raise Exception(
                    f"Oil production is not defined in model version {self.configuration.version}."
                )

    @property
    def coal_sector_good(self) -> str:
        """
        The string identifier of the good produced by the coal sector.
        """
        match self.configuration.version:
            case "20R" | "20C" | "22C" | "22P":
                return self.set_members(set_name="good_coal")
            case _:
                raise Exception(
                    f"Coal production is not defined in model version {self.configuration.version}."
                )

    @property
    def services_sector_good(self) -> str:
        """
        The string identifier of the 'good' produced by the services sector.
        """

        match self.configuration.version:
            case "20R" | "20C" | "22C" | "6G":
                result: list[str] = self.set_members(set_name="good_services")
                if result:
                    return result[0]
        raise Exception(
            f"Services sector good is not defined in model version {self.configuration.version}."
        )

    @property
    def fossil_fuel_goods_members(self) -> list[str]:
        """
        The list of sectors explicitly defined in the SYM model definition that are
        responsible for fossil fuel extraction and production in alphabetical order
        of the sector identifiers.

        * gas
        * oil
        * coal

        """
        match self.configuration.version:
            case "20R" | "20J" | "20C" | "22C":
                return [
                    self.gas_sector_good,
                    self.oil_sector_good,
                    self.coal_sector_good,
                ].sort()
            case _:
                raise Exception(
                    f"Sectors producing fossil fuel goods are not identified for model version {self.configuration.version}."
                )

    @property
    def fossil_fuel_goods_count(self) -> int:
        """
        The number of goods that are fossil fuels
        """
        return len(self.fossil_fuel_goods_members)

    @property
    def sector_prefix(self) -> str:
        """
        The first letter of the first sector identifier.
        This is typically `a`.
        """
        return self.sectors_members[0][0]

    @property
    def good_prefix(self) -> str:
        """
        The first letter of the first good identifier.
        This is typically `g`.
        """
        return self.goods_members[0][0]

    def sector_producing(self, good: str) -> str:
        """
        ### Arguments

        `good`: The identifier of the good produced by the sector of interest.

        ### Returns

        the sector identifier for the sector that produces the
        specified good.
        """
        return self.sector_prefix + good[1:]

    def sectors_producing(self, goods: list[str]) -> str:
        """
        ### Arguments

        `goods`: The list of identifiers of the goods produced by the sectors of interest.

        ### Returns

        the list of sector identifiers for the sectors that produces the
        goods in the supplied list.
        """
        return [self.sector_producing(x) for x in goods]

    def good_produced_by(self, sector: str) -> str:
        """
        ### Arguments

        `sector`: The identifier of the sector that produces the good of interest.

        ### Returns

        the good identifier produced by the specified sector.
        """
        return self.good_prefix + sector[1:]

    def goods_produced_by(self, sectors: list[str]) -> str:
        """
        ### Arguments

        `sectors`: The list of identifiers of the sectors that produce
        the goods of interest.

        ### Returns

        the list of good identifiers for the goods produced by the
        specified sectors.
        """
        return [self.good_produced_by(x) for x in sectors]

    @property
    def gases_members(self) -> list[str]:
        """
        The list of greenhouse gases that are part of the `ghg` set in the SYM model definition.
        """
        return self.set_members("gases")

    @property
    def gases_count(self) -> int:
        """
        The number of greenhouse gases that are part of the `ghg` set in the SYM model definition.
        """
        return self.__set_members_count("gases")

    def __vector_length(self, vector_name: str) -> int:
        """
        ### Arguments
        `vector_name`: The name of a LHS or RHS vector in the model.

        One of:

        1. x1l or x1r or yxr (all equal to the number of state variables in the model)
        2. j1l or j1r or yjr (all equal to the number of costate variables in the model)
        3. zel or zer or exz (all equal to the number of expected endogenous variables in the model)
        4. z1l or z1r (all equal to the number of other endogenous variables in the model)
        5. exo (equal to the number of exogenous variables in the model)

        ### Returns
        The lengths of various vectors used to express the model equations.
        These vector lengths are determined from the SYM definition of the model.
        """
        return self._vector_length[vector_name]

    @property  # nxg
    def exogenous_variable_count(self):
        """
        The number of exogenous variables in the model (The length of the EXO vector).
        """
        return self.__vector_length("exogenous_variables")

    @property  # nz and nz1
    def endogenous_variable_count(self):
        """
        The number of endogenous variables in the model (The length of the Z1L, Z1R vectors).
        """
        return self.__vector_length("endogenous_variables")

    @property  # nez
    def expected_endogenous_variable_count(self):
        """
        The number of expected endogenous variables in the model
        (The length of the ZEL, ZER and EXZ vectors).
        """
        return self.__vector_length("expected_endogenous_variables")

    @property  # njm
    def jump_variable_count(self):
        """
        The number of costate or jump variables in the model
        (The length of the J1L, J1R and YJR vectors).
        """
        return self.__vector_length("jump_variables")

    @property  # nst
    def state_variable_count(self):
        """
        The number of state variables in the model
        (The length of the X1L, X1R and XJR vectors).
        """
        return self.__vector_length("state_variables")

    @property  # npar
    def parameter_count(self):
        """
        The number of parameters in the model.
        """
        return self.__vector_length("parameters")

    @property
    def resources_members(self) -> list[str]:
        """
        The list of resources other than energy or material goods that are used in production.
        """
        return ["K", "L"]

    @property
    def resources_count(self) -> int:
        """
        The number of resources other than energy or material goods that are used in production.
        """
        return len(self.resources_members)

    @property
    # TODO: Consider adding these factors of production (K,L,E,M) to the
    # SYM model definition so they are not hard-coded.
    def factors_of_production_members(self) -> list[str]:
        """
        The four string identifiers of the factors of production:

        1. `K` for capital
        2. `L` for labour
        3. `E` for energy
        4. `M` for material

        """
        result = self.resources_members.copy()
        result.append("E")
        result.append("M")
        return result

    @property
    def factors_of_production_count(self) -> int:
        """
        The number of factors of production (4).
        """
        return len(self.factors_of_production_members)

    @property
    def lhs_vector_names(self) -> list[str]:
        """
        A list of the model's LHS vector names.

        Note the lowercase naming conventions for the lefthand side (LHS) variable vectors:

        1. `x1l` (the vector of state variables) X=S=State
        2. `j1l` (the vector of costate or jump variables) J=C=Costate
        3. `zel` (the endogenous variables LOGY, PRCT, PRID)
        4. `z1l` (the other endogenous variables)
        """
        return SymData._lhs_vector_names

    @property
    def rhs_vector_names(self) -> list[str]:
        """
        1. S - state - x1r is right hand side (RHS) state variables
        2. J - jump - j1r is RHS costate or jump variables
        3. R - ? - zer is special RHS endogenous variables LOGY, PRCT, PRID that also appear as expected next-period values on the RHS of the equations.
        4. exz is RHS the lead expected R (Expected value in next period of R)
        5.  S_{t-1} yxr is RHS state variables lagged by 1 period
        6. yjr is RHS costate variables lagged by 1 period
        7. exo is exogenous variables (by definition only appearing on RHS)
        8. z1r is RHS other endogenous variables.
        """
        return SymData._rhs_vector_names

    @property
    def ssf_rhs_vector_names(self) -> list[str]:
        """
        4. exz is RHS the lead expected endogenous variables (Expected value in next period of a subset of the endogenous variables)
        5. yxr is RHS state variables lagged by 1 period
        6. yjr is RHS costate variables lagged by 1 period
        7. exo is exogenous variables (by definition only appearing on RHS)
        """
        return SymData._ssf_rhs_vector_names

    @property
    def projection_vector_names(self) -> list[str]:
        return SymData._projection_vector_names

    def vector_length(self, vector_name: str) -> int:
        """
        Argument:

        vector_name: The 3 character acronym identifying the LHS or RHS vector in the model.

        Returns the integer length of the specified vector.
        """
        match vector_name:
            case "z1l" | "z1r":
                return self.endogenous_variable_count

            case "x1l" | "x1r" | "yxr":
                return self.state_variable_count

            case "j1l" | "j1r" | "yjr":
                return self.jump_variable_count

            case "zel" | "zer" | "exz":
                return self.expected_endogenous_variable_count

            case "exo":
                return self.exogenous_variable_count

            case _:
                raise Exception(
                    f"No vector length available for the {vector_name} vector."
                )

    def vector_variable_names(self, vector_name: str) -> list[str]:
        """
        ### Arguments
         vector_name: the name of the vector

         Returns the SYM ordered fully articulated variable names for the
         variables in the given model vector.

         This is useful for labelling the rows/columns of dataframes containing
         linear model partial derivatives, and SSF matrices.
        """
        variable_type: str = self.varmap_variable_type(vector_name=vector_name)
        matching_var_type: pd.Series = self.var_map.var_type == variable_type
        result: pd.DataFrame = self.var_map.loc[
            matching_var_type, ["name", "sequence"]
        ].sort_values("sequence")
        return result.name.to_list()

    @property
    def no_exogenous_variables(self) -> bool:
        """
        Used in place of the swtch variable in the Ox implementation.
        """
        return self.vector_length("exo") == 0

    @property
    def no_jump_variables(self) -> bool:
        """
        Used in place of the swtch variable in the Ox implementation.
        """
        return self.vector_length("j1r") == 0

    @property
    def no_expected_exogenous_variables(self) -> bool:
        """
        Used in place of the swtch variable in the Ox implementation.
        """
        return self.vector_length("zer") == 0

    def __load_varmap(self):
        """
        Load the list of variables and parameters in the model, along with their details.
        """
        filename: str = self.configuration.varmap_file

        if not os.path.isfile(filename):
            raise Exception(
                "Could not load parameter listing from "
                + filename
                + " because the file does not exist."
            )
        data: pd.DataFrame = pd.read_csv(filename, header=None)
        data.columns = [
            "name",
            "code",
            "var_type",
            "sequence",
            "name_with_no_punctuation",
        ]

        data.index = data.name
        self._variable_map = data

    def __load_vars(self):
        """
        Load the list of variables in the model, along with the details produced by the SYM processor
        from the file with the `_vars.csv` suffix.
        """
        filename: str = self.configuration.variables_file
        if not os.path.isfile(filename):
            raise Exception(
                "Could not load variables data from "
                + filename
                + " because the file does not exist."
            )
        data: pd.DataFrame = pd.read_csv(filename, header=None, index_col=None)
        # Drop any columns that are all NaN values
        data = data.dropna(axis=1, how="all")
        data.columns = [
            "sequence",
            "name",
            "description",
            "units",
            "region",
        ]
        data.index = data.name
        data.index.name = "name"
        self._vars = data

    def __load_varinfo(self):
        """
        Load the information in the varinfo file generated by the SYM processor.

        The attributes are of specific interest.

        The variable information dataframe is indexed by the variable name prefixes.

        The variable information dataframe has the following columns:

        - name: The variable name with sets in brackets after the prefix.
        - prefix: The variable name prefix.
        - size: The number of variables with that prefix.
        - var_type: The type of variable or parameter, one of par, end, exo, sta, stl, cos, ets.
        - units: The units for the variable - None for parameters
        - description: A description of the variable or parameter
        - attributes: A string containing the comma-delimited attributes of the variable or parameter.
        - logged: A boolean indicator that is `True` for variables that must be logged when preparing
        for use in the model (for linearisation or projections). Those variables enter equations in a
        way that assumes they have alredy been logged (using the natural log function).
        -lagged: A boolean indicator that is `True` for variables that are one period lagged version of
        another variable (e.g. lead(EXCL) = EXCH defines EXCL as being a one period lag of EXCL)
        - index: A boolean indicator that is `True` for variables that are an index. Note that an index
        can also be logged so interpretation of an index variable depends on its logged attribute.
        """
        filename: str = self.configuration.variables_info_file
        if not os.path.isfile(filename):
            raise Exception(
                "Could not load varinfo from "
                + filename
                + " because the file does not exist."
            )
        data: pd.DataFrame = pd.read_csv(filename, header=None)
        data.columns = [
            "name",
            "size",
            "var_type",
            "units",
            "description",
            "attributes",
        ]
        data.index = data.iloc[:, 0]
        data["prefix"] = data.index.str.extract(r"^([^\(]+)\(", expand=False)
        data["logged"] = data.attributes.str.contains(r"\blogged\b")
        data["idx"] = data.attributes.str.contains(r"\bidx\b")
        data["lagged"] = data.attributes.str.contains(r"\blagged\b")
        data["intertemporal_constant"] = data.attributes.str.contains(
            r"\bintertemporal_constant\b"
        )
        self._variable_information = data

    def __load_model_summary(self):
        """
        Load the model summary details from the file with the .lis extension.
        Use the model summary information to retrieve descriptions of sets
        and their members.

        The following dictionaries are populated:

        - _set_memberships = The map from set name to the list of its members.
        - _set_descriptions = The map from set name to its description.
        - _set_member_descriptions = The map from set member to its description.

        """
        # Initialise these dictionaries.
        self._set_memberships: dict[str, list[str]] = dict()
        self._set_descriptions: dict[str, str] = dict()  # Store the descriptions

        filename: str = self.configuration.model_summary_file
        if not os.path.isfile(filename):
            raise Exception(
                "Could not load model summary from "
                + filename
                + " because the file does not exist."
            )

        # Find all sets and store their name and members in a dictionary of lists,
        # where each list of set members is in the same order as specified in the
        # SYM model definition.
        file = open(filename, "r")
        lines = file.readlines()

        processing_sets = False
        set_name = None
        set_description = None
        set_members = None
        base_set_detected = False

        for line in lines:
            if line.isspace():
                set_name = None
                set_description = None
                set_members = None
                base_set_detected = False
                continue

            if "Parameters:" in line:
                break

            if "Sets:" in line:
                processing_sets = True
                continue

            if processing_sets:
                stripped_line = line.strip()
                if stripped_line:
                    if set_name is None:
                        set_name = stripped_line
                    elif "Base set:" in stripped_line:
                        base_set_detected = True
                    elif base_set_detected:
                        if line.startswith("         ") and set_description is None:
                            if set_members is None:
                                set_members: list[str] = stripped_line.split(",")
                            else:
                                set_members.extend(stripped_line.split(","))
                            if set_members:
                                set_members = [x for x in set_members if x.strip()]
                            self._set_memberships[set_name] = set_members
                        set_description = stripped_line
                        self._set_descriptions[set_name] = set_description
                        base_set_detected = False
                    else:
                        if not line.startswith("         "):
                            continue
                        if set_members is None:
                            set_members: list[str] = stripped_line.split(",")
                        else:
                            set_members.extend(stripped_line.split(","))
                        if set_members:
                            set_members = [x for x in set_members if x.strip()]
                        self._set_memberships[set_name] = set_members
                        continue
        file.close()

        # Now get mappings from set name to list of set members
        # for all sets that have exactly one member.
        filtered_dict: dict[str, list[str]] = {
            key: value
            for key, value in self._set_memberships.items()
            if len(value) == 1
        }
        # Convert into a map from set member to set name
        swapped_dict: dict[str, str] = {
            value[0]: key for key, value in filtered_dict.items()
        }
        # Replace the set name with the set description so we have a map
        # from set member code to set member description.
        transformed_dict: dict[str, str] = {
            key: self._set_descriptions[value]
            for key, value in swapped_dict.items()
            if value in self._set_descriptions
        }
        self._set_member_descriptions: dict[str, str] = transformed_dict

    def __summarise_sym_information(self):
        """
        Analyses the data loaded from the files produced by SYM to populate
        a variety of constants that determine model dimensions etc.
        """
        data: dict[str, any] = dict()
        data["parameters"] = self.__get_vector_size_by_type(["par"])  # npar in Ox
        data["state_variables"] = self.__get_vector_size_by_type(
            ["sta", "stl"]
        )  # nst in Ox
        data["jump_variables"] = self.__get_vector_size_by_type(
            ["cos"]
        )  # njm in Ox: for costate variables
        data["expected_endogenous_variables"] = self.__get_vector_size_by_type(
            ["ets"]
        )  # nez in Ox
        data["exogenous_variables"] = self.__get_vector_size_by_type(
            ["exo"]
        )  # nxg in Ox
        data["endogenous_variables"] = self.__get_vector_size_by_type(
            ["end"]
        )  # nz and nz1 in Ox

        self._vector_length = data

    @property
    def parameter_name_prefixes(self) -> list[str]:
        full_parameter_names = (
            self._variable_information.loc[
                self._variable_information["var_type"].isin(["par"]), "name"
            ]
        ).to_list()
        parameter_name_prefixes = [
            re.sub(r"^([^\(]+)($|\(.+$)", r"\g<1>", full_parameter_name)
            for full_parameter_name in full_parameter_names
        ]
        return parameter_name_prefixes

    def __get_vector_size_by_type(self, types: list[str]):
        """
        Determine the length of various vectors used by the model.

        ### Arguments

         self: The model

         types: a list of types of variables (or parameters)

         Return the sum of the size of each entry in the variable information table with a type matching any of
         the members of the types list.
        """
        return self._variable_information.loc[
            self._variable_information["var_type"].isin(types), "size"
        ].sum()

    def __validate(self):
        """
        Validates the SYM data about the model.
        """
        # Validate regions
        if self.regions_count < 2:
            raise Exception("The model needs to include at least 2 regions.")

        # Validate goods
        if self.goods_count < 2:
            raise Exception("The model needs to include at least 2 goods.")

        # Validate sectors
        if self.sectors_count < 2:
            raise Exception("The model needs to include at least 2 sectors.")
        if self.goods_count != self.sectors_count:
            logging.error(f"The goods are:\n{self.goods_members}")
            logging.error(f"The sectors are:\n{self.sectors_members}")
            raise Exception(
                f"The number of 'goods', {self.goods_count}, must be equal to the number of sectors, {self.sectors_count}."
            )

        match self.configuration.version:
            case "2R":
                assert self.sectors_count == 2
            case "6G" | "6W":
                assert self.sectors_count == 6
            case "20C" | "20R":
                assert self.sectors_count == 20
            case "22C":
                assert self.sectors_count == 22
            case _:
                pass

        # Validate equation vector lengths for LHS and RHS vectors
        assert len(self.lhs_vector_names) == 4
        assert len(self.rhs_vector_names) == 8

        # Check for endogenous variables without equations and with duplicated equations
        variables: pd.DataFrame = self.variable_summary.copy()
        variables = variables[~(variables.var_type == "exo")]

        self._equations_map: dict[tuple[str, int], list[tuple[str, int]]] = dict()

        equations: pd.DataFrame = pd.read_csv(
            self.configuration.eqnmap_file, header=None
        )
        equations.columns = ["vector", "sequence"]
        equations = equations.loc[equations.vector.str.endswith("l"), :]
        equations["var"] = equations.vector + equations.sequence.astype(str)

        duplicated_equations = equations[
            equations.duplicated(subset="var", keep=False)
        ].copy()
        duplicated_equations.drop_duplicates(subset="var", keep="first")

        equations.drop_duplicates(subset="var", keep="first")

        variables_without_equations = variables.loc[
            ~(
                variables.vector.isin(equations.vector)
                & variables.sequence.isin(equations.sequence)
            ),
            :,
        ]

        variables_without_equations.to_csv(
            os.path.join(
                self.configuration.diagnostics_directory,
                "endogenous variables without equations.csv",
            )
        )

        variables_with_duplicated_equations = variables.loc[
            (
                variables.vector.isin(duplicated_equations.vector)
                & variables.sequence.isin(duplicated_equations.sequence)
            ),
            :,
        ]

        variables_with_duplicated_equations.to_csv(
            os.path.join(
                self.configuration.diagnostics_directory,
                "endogenous variables with duplicated equations.csv",
            )
        )

        assert (
            len(variables_with_duplicated_equations.index) == 0
        ), f"Model has duplicated equations. Check the diagnostics folder for details in 'endogenous variables with duplicated equations.csv'."

    def has_variables(self, variable_name_prefix: str) -> bool:
        """

        ### Overview

        Used to check whether the model includes variables with names that start with the
        supplied prefix. The prefix is matched as a string rather than a regular expression.

        ### Arguments

        `variable_name_prefix`: The variable name prefix string.

        ### Returns

        True iff the SYM model definition includes a variable with the given root name.

        """
        return self.var_map.name.str.startswith(variable_name_prefix).any()

    def has_variable(self, variable_name: str) -> bool:
        """

        ### Overview

        Used to check whether the model includes the named variable.

        ### Arguments

        `variable_name`: The complete variable name including
        the set qualifier in round brackets (e.g. `INFL(USA)`).

        ### Returns

        True if the SYM model definition includes
        a variable with the given complete name.

        """
        return (self.var_map.name == variable_name).any()

    def variable_index(self, vector_name: str, variable_name: str) -> int:
        """

        ### Overview

        Used to get the integer index of a variable  in the specified vector.

        ### Arguments

        `variable_name`: The complete variable name including
        the set qualifier in round brackets (e.g. `INFL(USA)`).

        ### Returns

        The integer indicating the row index of the variable in the given vector.
        Indexing starts from `0`.

        ### Throws

        An exception is thrown if the named variable is not unique within the SYM model
        though that should not be possible once the SYM processor has run without problems.

        """
        variable_type: str = self.varmap_variable_type(vector_name=vector_name)
        type_matches: list[bool] = self.var_map.var_type == variable_type
        name_matches: list[bool] = self.var_map.name == variable_name
        result: pd.Series = self.var_map.loc[type_matches & name_matches, "sequence"]
        if len(result) == 0:
            raise Exception(
                f"The variable name, {variable_name} is not defined in the SYM model as part of vector {vector_name}."
            )
        if len(result) != 1:
            raise Exception(
                f"The variable name, {variable_name} must be unique within the SYM model to retrieve its unique index."
            )
        return int(result.values[0])

    def units_for_variables_with_given_name_prefix(
        self, vector_name: str, variable_name_prefix: str
    ) -> str:
        """
        ### Arguments

        vector_name: The name of the vector that contains the variable.

        variable_name_prefix: The prefix is the set of characters up to but not including the
        round bracket that starts the full qualification of the variable based on the sets it is
        defined over.

        e.g. use SHL for SHL(region,sector)

        ### Returns

        The units of measurement for the variables that match the given name prefix
        and that are of the variable type associated with the given vector name.
        """
        variable_type: str = self.varmap_variable_type(vector_name=vector_name)
        type_matches: list[bool] = self.var_info.var_type == variable_type
        name_matches: list[bool] = self.var_info.name.str.startswith(
            f"{variable_name_prefix}("
        )
        result = self.var_info.loc[type_matches & name_matches, "units"]
        if len(result) == 0:
            raise Exception(
                f"The variable name prefix, {variable_name_prefix}, is not defined in the SYM model as part of vector {vector_name}."
            )
        if len(result) != 1:
            raise Exception(
                f"The variable name prefix, {variable_name_prefix}, must be unique within the SYM model to retrieve its unique index."
            )
        return str(result)

    @property
    def intertemporal_constant_variables(self) -> pd.DataFrame:
        """

        ### Overview

        Provides access to the information about the variables that are associated with intertemporal constants.

        The intertemporal constants are used to ensure that jump variables equal to their observed values in the year
        where there is available data (typically the base projection year, one year before the start of projections).

        An intertemporal constant is also used in each WAGE equation to ensure that real interest rates align with nominal
        interest rates less expected inflation in the next year.

        ### Returns

        A dataframe containing a row per variable that has an intertemporal constant in its equation.
        The dataframe has the following columns:
        * `name` variable name (complete with set identifiers for region/sector etc.)
        * `var_type` variable type (the associated LHS vector name)
        * `sequence` the index of the variable in the associated vector

        """

        return self.variable_summary.loc[
            self.variable_summary.intertemporal_constant,
            ["name", "vector", "sequence"],
        ]

    @property
    def variables_adjusted_by_intertemporal_constants(self) -> pd.DataFrame:
        """
        ### Overview

        Provides access to the information about the variables that have their values adjusted
        by the intertemporal constants. Note that this list is slightly different from the
        list of variables that have intertemporal constants added to their equations in the model
        to match up model projections with observed values at the start of the projections because
        a constant is added to the WAGE equation but it is used to adjust the WAGE equation in a way
        that leads to the required expected price inflation rate.

        ### Returns

        A dataframe containing a row per variable that has an intertemporal constant in its equation.
        The dataframe has the following columns:

        * `name` variable name (complete with set identifiers for region/sector etc.)
        * `var_type` variable type (the associated LHS vector name)
        * `sequence` the index of the variable in the associated vector
        """

        return self.variable_summary.loc[
            self.variable_summary.adjusted_by_intertemporal_constant,
            ["name", "vector", "sequence"],
        ]

    def __generate_variable_summary(self):
        """

        ### Overview

        Combines the information in the varmap and in the varinfo files generated by sym so that
        we have a single dataframe, indexed by variable name and with a column for each of:

        - Variable name with all set identifiers e.g. GDPN(USA)
        - Variable name prefix e.g. GDPN
        - Variable units as specified in the varinfo.
        - 'publication_units' - the units code to use when publishing variable projections.
        - Variable description
        - Projection vector that the variable is associated with (j1l, x1l, z1l, zel or exo).
        - Index of the variable in its projection vector (the sequence number accessible from the varmap).
        - Column indicating if it has an intertemporal constant in its equation. Column should be a missing value if not
            and the index of the intertemporal constant if it is.
        - Column indicating if it is the target of an intertemporal constant adjustment. Column should be a missing value if not
            and the index of the intertemporal constant if it is.
        - Column indicating variables used in logged form in the model equations
        - Column indicating variables that are indexes
        - Column indicating variables that are the lag of another variable.
        """

        # Get the varinfo extract
        varinfo_columns: pd.DataFrame = self.var_info.loc[
            ~self.var_info["var_type"].isin(
                [
                    "par",
                ],
            ),
            [
                "description",
                "units",
                "var_type",
                "logged",
                "lagged",
                "idx",
                "intertemporal_constant",
            ],
        ]
        varinfo_columns["name"] = varinfo_columns.index
        varinfo_columns["prefix"] = varinfo_columns.name.str.extract(r"^([\w\d]+)")
        varinfo_columns["set_names"] = varinfo_columns.name.str.extract(
            r"^[\w\d]+\(([^\)]+)\)$"
        )
        varinfo_columns.drop(columns=["name"], inplace=True)

        # Get the varmap extract
        self._variable_summary = self.var_map.loc[
            ~self.var_map["var_type"].isin(
                [
                    "par",
                    "x1r",
                    "z1r",
                    "j1r",
                    "zer",
                    "yjr",
                    "yxr",
                    "exz",
                ],
            ),
            ["name", "var_type", "sequence"],
        ]

        # Incorporate other values from the variable map data
        self._variable_summary = self._variable_summary.rename(
            columns={"var_type": "vector"}
        )

        self._variable_summary["prefix"] = self._variable_summary.name.str.extract(
            r"^(.*?)\(.*?\)$"
        )
        self._variable_summary["set_members"] = self._variable_summary.name.str.extract(
            r"^.*\((.*)\)$"
        )

        # Make sure that each row of the summary corresponds to a unique variable.
        assert (
            self._variable_summary.index.is_unique
        ), f"The variable summary dataframe index contains duplicated values."

        # Merge the DataFrames based on the 'common_column'
        self._variable_summary = self._variable_summary.merge(
            varinfo_columns, on="prefix", how="inner", suffixes=("", "_varinfo")
        )

        # Drop unnecessary columns
        self._variable_summary = self._variable_summary.rename(
            columns={"sets_varinfo": "set_names"}
        )

        # Complete setting up flags for the intertemporal constants
        self._variable_summary.loc[
            self._variable_summary.vector == "j1l", "intertemporal_constant"
        ] = True

        # Manage the special case for United States region REXC which is always equal to 1
        # It does not require an intertemporal constant.
        self._variable_summary.loc[
            self._variable_summary.name
            == f"{gcubed.CONSTANTS.REXC_PREFIX}({self.us_region})",
            "intertemporal_constant",
        ] = False

        # Manage the special case for the WAGE intertemporal constant being used to
        # ensure that PRID is equal to the observed value in the base year.
        self._variable_summary["adjusted_by_intertemporal_constant"] = (
            self._variable_summary["intertemporal_constant"]
        )

        # Manage the special case for the WAGE intertemporal constant being used to
        # ensure that PRID is equal to the observed value in the base year.
        if (
            len(
                self._variable_summary.loc[
                    (
                        (self._variable_summary.prefix == "WAGE")
                        & (self._variable_summary.intertemporal_constant)
                    ),
                    :,
                ].index
            )
            > 0
        ):
            self._variable_summary.loc[
                self._variable_summary.prefix == "WAGE",
                "adjusted_by_intertemporal_constant",
            ] = False
            self._variable_summary.loc[
                self._variable_summary.prefix == "PRID",
                "adjusted_by_intertemporal_constant",
            ] = True

        def populate_sets(row):
            if isinstance(row["set_names"], float):
                return pd.Series(
                    {
                        "sets": None,
                    }
                )
            set_names: list[str] = row["set_names"].split(",")
            set_members: list[str] = row["set_members"].split(",")
            assert len(set_members) == len(
                set_names
            ), f"Sets {row['set_names']} and set members {row['set_members']} do not match for variable {row['name']}"
            value: str = ",".join([f"{a}={b}" for a, b in zip(set_names, set_members)])
            return pd.Series(
                {
                    "sets": value,
                }
            )

        self._variable_summary: pd.DataFrame = pd.concat(
            [
                self._variable_summary,
                self._variable_summary.apply(populate_sets, axis=1),
            ],
            axis=1,
        )
        self._variable_summary.drop(columns=["set_names", "set_members"], inplace=True)

        def process_set_member_descriptions(set_string):
            if not set_string:
                return ""

            # Split the set string by comma
            set_pairs = set_string.split(",")

            # Replace each set member with its description
            for i, pair in enumerate(set_pairs):
                set_name, member = pair.split("=")
                description = self.set_member_descriptions.get(member, member)
                set_pairs[i] = f"{set_name}={description}"

            return ",".join(set_pairs)

        # Apply the function to the 'sets' column
        self._variable_summary["set_member_descriptions"] = self._variable_summary[
            "sets"
        ].apply(process_set_member_descriptions)

        # Set the variable region based on the data in the SYM-generated vars file.
        # OBSOLETE region identifier (this old version does not work for ASSE variables):
        # self._variable_summary["region"] = self._vars.region.to_numpy()

        # NEW region identifier (this new version sets ASSE variable region to the owner region):
        # Extract region information from the "sets" column based on different patterns
        # For each pattern, extract the next two characters after the equal sign
        # self._variable_summary["region"] = None
        self._variable_summary["region"] = None
        self._variable_summary.region = self._variable_summary.region.astype(str)
        for pattern in ["regions=", "owner=", "dest=", "capcon="]:
            selector: pd.Series = (
                self._variable_summary.sets.str.contains(pattern)
                .astype(bool)
                .fillna(False)
            )
            self._variable_summary.loc[selector, ["region"]] = (
                self._variable_summary.loc[selector, "sets"]
                .str.extract(rf"{pattern}(\w+)")
                .to_numpy()
            )

        # Create the publication units column
        self._variable_summary["publication_units"] = self._variable_summary.loc[
            :, "units"
        ]

        # Create the deviation units column
        self._variable_summary["deviation_units"] = self._variable_summary.loc[
            :, "units"
        ]

        # idx -> index
        variable_selector = self._variable_summary.units.isin(["idx"])
        self._variable_summary.loc[variable_selector, "publication_units"] = "index"
        self._variable_summary.loc[variable_selector, "deviation_units"] = "percent"

        # pct -> percent
        variable_selector = self._variable_summary.units.isin(["pct"])
        self._variable_summary.loc[variable_selector, "publication_units"] = "percent"
        self._variable_summary.loc[variable_selector, "deviation_units"] = (
            "percentage point"
        )

        # del -> percentage points
        variable_selector = self._variable_summary.units.isin(["del"])
        self._variable_summary.loc[variable_selector, "publication_units"] = (
            "percentage point"
        )
        self._variable_summary.loc[variable_selector, "deviation_units"] = (
            "percentage point"
        )

        # dollar -> dollars
        variable_selector = self._variable_summary.units.isin(["dollar"])
        self._variable_summary.loc[variable_selector, "publication_units"] = "dollars"
        self._variable_summary.loc[variable_selector, "deviation_units"] = "dollar"

        # usgdp, gdp -> $US billion
        variable_selector = self._variable_summary.units.isin(["usgdp", "gdp"])
        self._variable_summary.loc[variable_selector, "publication_units"] = (
            "$US billion"
        )
        self._variable_summary.loc[variable_selector, "deviation_units"] = (
            "percent of GDP"
        )

        # mmtusgdp, mmtgdp -> mmt
        variable_selector = self._variable_summary.units.isin(["mmtusgdp", "mmtgdp"])
        self._variable_summary.loc[variable_selector, "publication_units"] = "mmt"
        self._variable_summary.loc[variable_selector, "deviation_units"] = "percent"

        # btuusgdp, btugdp -> btu
        variable_selector = self._variable_summary.units.isin(["btuusgdp", "btugdp"])
        self._variable_summary.loc[variable_selector, "publication_units"] = "btu"
        self._variable_summary.loc[variable_selector, "deviation_units"] = "percent"

        # gwhgdp -> gwh
        variable_selector = self._variable_summary.units.isin(["gwhgdp"])
        self._variable_summary.loc[variable_selector, "publication_units"] = "gwh"
        self._variable_summary.loc[variable_selector, "deviation_units"] = "percent"

        # nomusdbillion -> nominal $US billion
        variable_selector = self._variable_summary.units.isin(["nomusdbillion"])
        self._variable_summary.loc[variable_selector, "publication_units"] = (
            "nominal $US billion"
        )
        self._variable_summary.loc[variable_selector, "deviation_units"] = "percent"

        # realusdbillion -> real $US billion
        variable_selector = self._variable_summary.units.isin(["realusdbillion"])
        self._variable_summary.loc[variable_selector, "publication_units"] = (
            "real $US billion"
        )
        self._variable_summary.loc[variable_selector, "deviation_units"] = "percent"

        self._variable_summary.index = self._variable_summary.name

        # Save variable summary data.
        self._variable_summary.to_csv(
            os.path.join(
                self.configuration.diagnostics_directory, "variable summary.csv"
            )
        )

    @property
    def variable_summary(self) -> pd.DataFrame:
        """

        ### Overview

        This summary dataframe of the SYM information about variables
        should be used to drive a lot of the
        variable filtering during model processing.

        The rows of the dataframe are the variable names.

        The columns of the dataframe are:

        * `name` - the full name of the variable
        * `prefix` - the name prefix - up to the open bracket.
        * `units` - the units code.
        * `publication_units` - the units code to use when publishing variable projections.
        * `description` - the description
        * `var_type` - one of:
            - `par` = parameter
            - `ets` = expected next-period value of an endogenous variable
            - `end` = endogenous
            - `sta` = state
            - `stl` = lead state variable
            - `exo` = exogenous
            - `cos` = costate or jump
        * `vector` - the vector name e.g. `z1l`, `yxr`, `exo` etc.
        * `vector_code` - the vector name and index combination - e.g. `exo[3]`.
        * `sequence` - the index in the vector that corresponds to the variable - e.g `3`.
        * `is_intertemp` - the index of the variable in the vector of intertemporal constants (or NaN)
        * `is_adjusted` - the index of the variable in the vector of variables being adjusted by intertemporal constants (or NaN)

        ### Returns

        The variable summary dataframe.

        """
        return self._variable_summary

    def variable_units(self, variable_name: str) -> str:
        """
        ### Arguments

        variable_name: The full name of the variable including details of set membership: e.g. `WAGE(AA)`.

        ### Returns

        The units of measurement for the variable with the given name.

        ### Exceptions

        Raises an exception if the named variable is not in the model.

        """
        try:
            return str(self.variable_summary.at[variable_name, "units"])
        except:
            raise Exception(
                f"Failed to retrieve the publicaion units of variable {variable_name}. It may not be the complete name of a variable in the model."
            )

    def variable_publication_units(self, variable_name: str) -> str:
        """
        ### Arguments

        variable_name: The full name of the variable including details of set membership: e.g. `WAGE(AA)`.

        ### Returns

        The publication units of measurement for the variable with the given name.

        ### Exceptions

        Raises an exception if the named variable is not in the model.

        """
        try:
            return str(self.variable_summary.at[variable_name, "publication_units"])
        except:
            raise Exception(
                f"Failed to retrieve the publicaion units of variable {variable_name}. It may not be the complete name of a variable in the model."
            )

    def variable_var_type(self, variable_name: str) -> str:
        """
        ### Arguments

        variable_name: The full name of the variable including details of set membership: e.g. `WAGE(AA)`.

        ### Returns

        The variable type of the vector that the variable is in. One of:

        - `par` = parameter
        - `ets` = expected next-period value of an endogenous variable
        - `end` = endogenous
        - `sta` = state
        - `stl` = lead state variable
        - `exo` = exogenous
        - `cos` = costate or jump

        ### Exceptions

        Raises an exception if the named variable is not in the model.

        """
        try:
            return str(self.variable_summary.at[variable_name, "var_type"])
        except Exception as e:
            logging.warning(e)
            raise Exception(
                f"Failed to retrieve the type of variable {variable_name}. It may not be the complete name of a variable in the model."
            )

    def variable_region(self, variable_name: str) -> str:
        """
        ### Arguments

        variable_name: The full name of the variable including details of set membership: e.g. `WAGE(AA)`.

        ### Returns

        The region code for the named variable or None if the variable has no region.

        ### Exceptions

        Raises an exception if the named variable is not in the model.

        """
        try:
            value: any = self.variable_summary.at[variable_name, "region"]
            if value is None:
                return None
            if isinstance(value, str):
                return value
            return None
        except:
            raise Exception(
                f"Failed to retrieve the region for variable {variable_name}. It may not be the complete name of a variable in the model."
            )

    def is_exogenous(self, variable_name: str) -> bool:
        """
        ### Arguments

        variable_name: The full name of the variable.

        ### Returns

        `True` if the variable is exogenous and `False` otherwise.

        ### Throws

        Exception if the named variable is not in the model.

        """
        try:
            return self.variable_var_type(variable_name=variable_name) == "exo"
        except:
            raise Exception(
                f"{variable_name} does not appear to be the full name of a variable in the model."
            )

    def is_state(self, variable_name: str) -> int:
        """
        ### Arguments

        variable_name: The full name of the variable.

        ### Returns

        `True` if the variable is a state or lead state variable and `False` otherwise.

        ### Throws

        Exception if the named variable is not in the model.

        """
        try:
            match self.variable_var_type(variable_name=variable_name):
                case "sta" | "stl":
                    return True
                case _:
                    return False
        except:
            raise Exception(
                f"{variable_name} does not appear to be the full name of a variable in the model."
            )

    def is_adjustable_in_simulations(self, variable_name: str) -> int:
        """
        ### Arguments

        variable_name: The full name of the variable.

        ### Returns

        `True` if the variable can be adjusted in a simulation layer
        and `False` otherwise.

        ### Throws

        Exception if the named variable is not in the model.

        """
        try:
            match self.variable_var_type(variable_name=variable_name):
                case "sta" | "stl" | "exo":
                    return True
                case _:
                    return False
        except:
            raise Exception(
                f"{variable_name} does not appear to be the full name of a variable in the model."
            )

    @property
    def zero_variables_selector(self) -> pd.Series:
        """

        ## Overview

        Some variables have equations defined for them by SYM but should instead be set to
        zero in the model. This method enables those variables to be selected.

        ## Returns

        The series contains `True` iff the variable is to have its equation modified to ensure the
        variable always evaluates to zero.
        """

        warnings.filterwarnings(
            "ignore",
            message="This pattern is interpreted as a regular expression, and has match groups. To actually get the groups, use str.extract.",
        )

        # List of regular expressions to match variables that should be set to zero
        regex_list: list[str] = [
            r"IMP\(g\d+,(?P<group>\w+),\1\)",  # imports from a region to itself
            rf"EMG\(",  # emissions due to government consumption of goods.
            rf"EMSL\(",  # emissions due to sectoral use of labor.
            rf"EMSK\(",  # emissions due to sectoral use of capital.
            rf"EMSO\(a08",  # emissions due to sectoral output.
            rf"EMSO\(a11",  # emissions due to sectoral output.
            rf"EMSO\(a14",  # emissions due to sectoral output.
            rf"EMSO\(a15",  # emissions due to sectoral output.
            rf"EMSO\(a16",  # emissions due to sectoral output.
            rf"EMSO\(a17",  # emissions due to sectoral output.
            rf"EMSO\(a18",  # emissions due to sectoral output.
            rf"EMSO\(a19",  # emissions due to sectoral output.
            rf"EMSO\(a20",  # emissions due to sectoral output.
            rf"EMSO\(a21",  # emissions due to sectoral output.
            rf"EMSO\(a22",  # emissions due to sectoral output.
        ]

        # Also eliminate Australia's nuclear electricity generation sector.
        try:
            nuclear_generation_sector: str = self.nuclear_generation_sector
            regex_list.append(
                rf"EMS\w?\({nuclear_generation_sector},AA\)",  # emissions from Australia's uranium industry
            )
            regex_list.append(
                rf"EMS\w?\({nuclear_generation_sector},AUS\)",  # emissions from Australia's uranium industry
            )

        except:
            pass

        # Combine the list of regular expressions into a single pattern
        combined_pattern = "|".join(regex_list)

        # Create the selector mask and return it.
        return self.variable_summary.name.str.contains(combined_pattern, regex=True)

        # Obsolete handling of zero variable selector
        # pattern: str = r"IMP\(g\d+,(?P<group>\w+),\1\)"
        # result_series: pd.Series = self.variable_summary["name"].str.extract(pattern)
        # return result_series["group"].notnull()

    @property
    def zero_variables_summary(self) -> pd.DataFrame:
        """

        ## Overview

        Some variables have equations defined for them by SYM but should instead be set to
        zero in the model. This method enables those variables to be selected.

        This is used to change the python class that contains the equations in the model, replacing
        specific functions for the selected variables and changing the map from LHS to RHS variables
        to have empty RHS lists for the selected variables as LHS variables.

        ## Returns

        The extract of the variable summary dataframe for those variables that are to have their
        equations replaced with an equals zero.

        """
        return self.variable_summary.loc[self.zero_variables_selector, :]

    def equation_function_name(self, variable_name: str) -> str:
        """
        ### Arguments

        variable_name: The full name of the variable.

        ### Returns

        The name of the function that is to be used to calculate
        the value of the variable in the model.

        ### Throws

        - `AssertionError` if the named variable is not in the model.
        - `AssertionError` if the named variable is exogenous.
        - `AssertionError` if the named variable is a parameter.

        """
        assert self.has_variable(
            variable_name
        ), f"{variable_name} is not a variable in the model."
        assert (
            self.variable_var_type(variable_name=variable_name) != "exo"
        ), f"{variable_name} is an exogenous variable so it does not have an equation in the model."
        assert (
            self.variable_var_type(variable_name=variable_name) != "par"
        ), f"{variable_name} is a parameter so it does not have an equation in the model."

        return f"{self.variable_summary.at[variable_name, 'vector']}_{self.variable_summary.at[variable_name, 'sequence']}"

    def variable_name(self, vector_name: str, sequence: int) -> str:
        """

        Enables determation of the variable name from the vector name and sequence details
        provided in the SYM generated equation map.

        ### Arguments

        `vector_name`: the name of the vector in which the variable is stored.

        `sequence`: the position of the variable in the vector.

        ### Returns

        The name of the variable in the model.
        """

        # Get the type of variable
        vector: str = self.vector_type(vector_name=vector_name)

        # Get the variable name by looking up the variable summary
        matching_names: pd.Series = self.variable_summary.loc[
            (self.variable_summary.vector == vector)
            & (self.variable_summary.sequence == sequence),
            "name",
        ]
        assert (
            len(matching_names) == 1
        ), f"Failed to find a unique variable name for vector {vector_name} and sequence {sequence}."
        return matching_names.values[0]

    def variables_with_prefix(self, variable_name_prefix: str) -> list[str]:
        """

        ### Overview

        Used to get the list of variable names in the model that have the given prefix (the letters before the first '(').

        ### Arguments

        `variable_name_prefix`: The variable name prefix string.

        ### Returns

        A series of variable names that have the given prefix.

        """
        return list(
            self.variable_summary[
                self.variable_summary["prefix"] == variable_name_prefix
            ]["name"]
        )
