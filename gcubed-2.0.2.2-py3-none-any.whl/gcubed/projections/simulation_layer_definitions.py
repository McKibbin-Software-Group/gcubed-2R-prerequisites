"""
This module contains the `SimulationLayerDefinitions` class.

It contains a list of simulation layer definitions, in the order that
they are to be imposed over the baseline for the model.
"""

import logging
import os
import os.path
import pandas as pd
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.projections.simulation_layer_definition import SimulationLayerDefinition
from gcubed.sym_data import SymData


class SimulationLayerDefinitions(Base):
    """
    An event_year ordered list of simulation layer definitions.

    The ordered list implemented as a singly linked list.

    It supports addition, removal and iteration of simulation layer definitions.
    """

    def __init__(self, sym_data: SymData) -> None:
        """Create an empty ordered list of SimulationLayerDefinitions"""

        assert sym_data is not None
        self._sym_data = sym_data

        self.head: SimulationLayerDefinition = None
        self.size = 0

    @property
    def sym_data(self) -> SymData:
        return self._sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        return self.sym_data.configuration

    def __len__(self):
        """Return the number of SimulationLayerDefinitions in the list"""
        return self.size

    def __iter__(self):
        """Return an iterator over the SimulationLayerDefinitions in the list"""
        current = self.head
        while current:
            yield current
            current = current.next

    def add(self, simulation_layer_definition: SimulationLayerDefinition):
        """
        ### Overview

        Insert a `SimulationLayerDefinition` into the iterable list of
        definitions, in the correct event-year order.
        """
        simulation_layer_definition.next = None
        if self.head:
            current: SimulationLayerDefinition = self.head
            while current.next:
                current = current.next
            current.next = simulation_layer_definition
        else:
            self.head = simulation_layer_definition
        self.size += 1

    def remove(self, simulation_layer_definition: SimulationLayerDefinition):
        """Remove a SimulationLayerDefinition from the list"""
        current = self.head
        previous = None
        while current is not None:
            if current == simulation_layer_definition:
                if previous is None:
                    self.head = current.next
                else:
                    previous.next = current.next
                self.size -= 1
                return
            previous = current
            current = current.next
            raise ValueError(
                f"The simulation layer definition {simulation_layer_definition.name} was not found in the list."
            )

    def get_simulation_layer_definition(
        self, simulation_name: str
    ) -> SimulationLayerDefinition:
        """
        ### Arguments

         simulation_name: The name of the simulation to retrieve details for.

         Returns the definition for a named simulation layer.
        """
        for candidate in self:
            if candidate.name == simulation_name:
                return candidate
        raise Exception(f"There is no simulation layer named {simulation_name}")

    def get_simulation_layer_definitions(
        self, event_year: int
    ) -> list[SimulationLayerDefinition]:
        """
        ### Arguments

         event_year: The event year.

         Returns the simulation layer definitions that have the specified event year.
         They are returned in the same order as they have been loaded.
        """
        result: list[SimulationLayerDefinition] = []
        for candidate in self:
            if candidate.event_year == event_year:
                result.append(candidate)
        return result

    @property
    def all_event_years_in_ascending_order(self):
        """
        The list of unique event years associated with simulation layer definitions
        in ascending order.
        """
        result: list[int] = []
        if len(self) == 0:
            return result
        for definition in self:
            result.append(definition.event_year)
            result = sorted(set(result))
        return result

    def load_from_csv_file(self, design_file: str):
        """
        ### Overview

        Loads the metadata about each simulation layer from the specified CSV experiment design file.

        ### Arguments

        `design_file`: the name and **absolute** path to the experiment design file.

        Loads the simulation layer definitions from a CSV file that lists the files along with other details of each simulation layer.
        The CSV file columns are expected to be, in the following order:

        * `name` - the name of the simulation layer
        * `data` - the name of the simulation layer data file. The data files are expected to be in the same directory
        as the CSV design file that defines the simulation layers.
        * `event_year` - the event year for the simulation layer.
        * `description` - the text description of the simulation layer.

        ### Exceptions

        Raises an exception if the experiment design file does not exist.

        Raises and exception if the simulation layers in the experiment design are
        not in event year order from earliest to latest.

        """

        filename: str = os.path.join(
            self.configuration.simulations_directory, design_file
        )

        if not filename:
            raise Exception(
                "An experiment design file is required to set up a simulation experiment."
            )

        if not os.path.isfile(filename):
            raise Exception(f"Experiment design file {filename} does not exist.")

        data_files_directory = os.path.dirname(filename)

        simulations: pd.DataFrame = pd.read_csv(filename, header=0)

        latest_event_year: int = 0
        for simulation_details in simulations.itertuples(index=False):
            simulation_layer_definition: SimulationLayerDefinition = (
                SimulationLayerDefinition(
                    sym_data=self.sym_data,
                    name=simulation_details.name,
                    event_year=int(simulation_details.event_year),
                    data_filename=os.path.abspath(
                        os.path.join(data_files_directory, simulation_details.data)
                    ),
                    description=simulation_details.description,
                )
            )

            if simulation_layer_definition.event_year < latest_event_year:
                raise Exception(
                    f"The simulation layers in the experiment design file {filename} are not in event year order from earliest to latest."
                )

            self.add(simulation_layer_definition=simulation_layer_definition)

        if len(self) == 0:
            logging.warning(
                f"The design file {filename} contains no simulation layers."
            )
