"""
This module contains the `Comparator` class that compares two 
`Benchmarks` instances.
"""

import logging
import os
import pandas as pd
import numpy as np
from gcubed.base import Base
from gcubed.benchmarking.benchmarks import Benchmarks


class Comparator(Base):
    """
    ### Overview

    Create a set of benchmark results associated with a model
    and a version of Ox.
    """

    def __init__(self, old_benchmarks: Benchmarks, new_benchmarks: Benchmarks):
        """
        ### Overview

        Analyses and reports on differences between the original and new
        benchmarks.

        ### Arguments

        `old_benchmarks`: The old benchmarks. Typically these have been run some time
        ago and are pickled (serialised to disk) and will need to be unpickled (restored
        to a Python object) before being passed to this Comparator for analysis.

        `new_benchmarks`: The new benchmarks. Often these benchmarks are run and used
        immediately.

        """

        assert old_benchmarks is not None, "The old benchmarks must be specified."
        self._old_benchmarks = old_benchmarks

        assert new_benchmarks is not None, "The new benchmarks must be specified."
        self._new_benchmarks = new_benchmarks

        self._reporting_directory = os.getcwd()

        self._save_reports = False

    @property
    def new_benchmarks(self) -> Benchmarks:
        """
        The new benchmarks.
        """
        return self._new_benchmarks

    @property
    def old_benchmarks(self) -> Benchmarks:
        """
        The old benchmarks.
        """
        return self._old_benchmarks

    @property
    def reporting_directory(self) -> str:
        """
        The directory to save mismatch reports in.
        """
        return self._reporting_directory

    @reporting_directory.setter
    def reporting_directory(self, value):
        """
        Set the value of the reporting directory

        # Exception

        Raises an exception if the directory is invalid or does not exist.
        """
        assert value is not None, "The reporting directory must be specified."
        assert isinstance(value, str), "The reporting directory must be a string."
        assert os.path.isdir(
            value
        ), f"The reporting directory must exist. {value} does not exist."
        self._reporting_directory = value

    @property
    def save_reports(self) -> bool:
        """
        `True` if reports are to be saved.

        Defaults to `False`
        """
        return self._save_reports

    @save_reports.setter
    def save_reports(self, value):
        """
        Set to `True` to save reports of mismatches.
        """
        assert (
            value is not None
        ), "The save reports flag must be specified as a Boolean value."
        assert isinstance(value, bool), "Save reports must be a Boolean value."
        self._save_reports = value

    @property
    def FLOAT_FORMAT(self) -> str:
        """
        The format to use for floating point values in CSV output.

        Defaults to `%.10f`.
        """
        if not hasattr(__class__, "_FLOAT_FORMAT"):
            self._FLOAT_FORMAT: str = "%.10f"
        return self._FLOAT_FORMAT

    @property
    def ABSOLUTE_TOLERANCE(self) -> float:
        """
        The absolute allowable errors. See `numpy.allclose` for details.

        Defaults to `0.00001`.
        """
        if not hasattr(__class__, "_ABSOLUTE_TOLERANCE"):
            self._ABSOLUTE_TOLERANCE = 0.00001
        return self._ABSOLUTE_TOLERANCE

    @property
    def RELATIVE_TOLERANCE(self) -> float:
        """
        The relative allowable errors. See `numpy.allclose` for details.

        Defaults to `0.00001`.
        """
        if not hasattr(__class__, "_RELATIVE_TOLERANCE"):
            self._RELATIVE_TOLERANCE = 0.00001
        return self._RELATIVE_TOLERANCE

    @property
    def DISCREPANCY_LIMIT(self) -> float:
        """
        The discrepancy limit, used for determining which discrepancies
        to report.

        Defaults to `0.00001`.
        """
        if not hasattr(__class__, "_DISCREPANCY_LIMIT"):
            self._DISCREPANCY_LIMIT = 0.00001
        return self._DISCREPANCY_LIMIT

    def isclose(self, old: np.ndarray, new: np.ndarray) -> np.ndarray:
        """
        ### Arguments

        old: The data frame of numbers from the old benchmarks.

        new: The data frame of numbers from the new benchmarks.

        ### Returns

        A boolean array where two arrays are element-wise equal within the
        absolute and relative tolerances set for this `gcubed.benchmarking.comparator.Comparator`.

        ### Exceptions

        Raises an exception if the two arrays are not the same shape.

        """
        assert (
            new.shape == old.shape
        ), f"The two arrays must be the same shape. old.shape={old.shape}, new.shape={new.shape}"
        return np.isclose(
            new, old, rtol=self.RELATIVE_TOLERANCE, atol=self.ABSOLUTE_TOLERANCE
        )

    def allclose(self, old: pd.DataFrame, new: pd.DataFrame) -> bool:
        """
        ### Arguments

        old: The data frame of numbers from the old benchmarks.

        new: The data frame of numbers from the new benchmarks.

        ### Returns

        `True` if arrays are element-wise equal within the
        absolute and relative tolerances set for this `gcubed.benchmarking.comparator.Comparator`.

        ### Exceptions

        Raises an exception if the two arrays are not the same shape.

        """
        assert (
            new.shape == old.shape
        ), f"The two arrays must be the same shape. old.shape={old.shape}, new.shape={new.shape}"
        return np.allclose(
            new, old, atol=self.ABSOLUTE_TOLERANCE, rtol=self.RELATIVE_TOLERANCE
        )

    def compare_vectors(
        self,
        name: str,
        old: pd.DataFrame,
        new: pd.DataFrame,
        new_name: str = "new",
        old_name: str = "old",
    ) -> bool:
        """
        ### Overview

        Compare two vectors.

        ### Arguments

        name: The name of the vector being compared.

        old: The old vector

        new: The new vector

        old_name: The name of the old vector

        new_name: The name of the new vector

        ### Returns

        `True` if the values in the vectors match.

        """
        if not (new.index == old.index).all():
            logging.error(f"{name} indices do not match - {new_name} vs {old_name}")
            return False

        if not self.allclose(new=new.astype(float), old=old.astype(float)):
            error_name: str = f"different {name} values - {new_name} vs {old_name}"
            logging.error(error_name)
            if self.save_reports:
                differences: pd.DataFrame = new - old
                report: pd.DataFrame = pd.concat(
                    [new, old, differences], axis=1, ignore_index=True
                )
                report.columns = ["new", "old", "differences"]
                report.to_csv(f"{self.reporting_directory}/{error_name}.csv")
            return False

        return True

    def compare_matrices(
        self,
        name: str,
        old: pd.DataFrame,
        new: pd.DataFrame,
        new_name: str = "new",
        old_name: str = "old",
    ) -> bool:
        """
        ### Overview

        Compare two matrices.

        ### Arguments

        name: The name of the matrix being compared.

        old: The old matrix

        new: The new matrix

        new_name: The name of the new matrix

        old_name: The name of the old matrix

        ### Returns

        `True` if the values in the matrices match.

        """

        if not (new.to_numpy().shape == old.to_numpy().shape):
            logging.error(
                f"{name} Row/column dimensions do not match - {new_name} {new.to_numpy().shape} vs {old_name} {old.to_numpy().shape} "
            )
            return False

        if not (new.index == old.index).all():
            logging.error(f"{name} indices do not match")
            return False

        if not (new.columns == old.columns).all():
            logging.error(f"{name} columns do not match")
            return False

        if not self.allclose(new=new, old=old):
            error_name: str = f"different {name} values"
            logging.error(error_name)
            if self.save_reports:
                differences: pd.DataFrame = new - old
                differences.to_csv(
                    f"{self.reporting_directory}/{error_name} differences.csv"
                )
                old.to_csv(f"{self.reporting_directory}/{error_name} {old_name}.csv")
                new.to_csv(f"{self.reporting_directory}/{error_name} {new_name}.csv")
            return False

        return True

    def match_variables(self) -> bool:
        """
        ### Overview

        Match the content in the SYM summaries of the model variables.

        Checks to run:

        - The list of variables are the same.

        # Returns

        `True` if the new and old benchmarks match.

        """
        logging.info("Benchmarking variables in the model.")
        result: bool = True
        old: pd.DataFrame = self.old_benchmarks.sym_summary
        new: pd.DataFrame = self.new_benchmarks.sym_summary
        if not (new.index == old.index).all():
            logging.error(f"Different variables - {new.name} vs {old.name}")
            result: bool = False
        return result

    def match_parameters(self) -> bool:
        """
        ### Overview

        Ensure that there is exactly 1 new parameter for each old parameter
        and visa-versa.

        Ensure that each parameter value is associated with the same parameter name and order
        and set members. and that the parameter values are identical (to within a reasonable
        level of numerical accuracy).
        """
        logging.info("Benchmarking model parameters.")

        return self.compare_vectors(
            "parameters",
            old=self.old_benchmarks.parameter_values.loc[:, ["value"]],
            new=self.new_benchmarks.parameter_values.loc[:, ["value"]],
        )

    def match_linearisation_rhs_vector_values(self):
        """
        ### Overview

        Compare RHS vector values used in initial model linearisation.
        """
        logging.info("Benchmarking RHS vector values used for model linearisation.")
        result: bool = True
        for rhs_vector_name in self.old_benchmarks.rhs_vector_names:
            old: pd.DataFrame = self.old_benchmarks.initial_rhs_vector_values(
                rhs_vector_name=rhs_vector_name
            )
            new: pd.DataFrame = self.new_benchmarks.initial_rhs_vector_values(
                rhs_vector_name=rhs_vector_name
            )
            result = result and self.compare_vectors(
                f"database value of RHS vector {rhs_vector_name}", old=old, new=new
            )
        return result

    def match_nonlinear_model_lhs_vector_values(self):
        """
        ### Overview

        Compare old and new LHS vector values calculated using
        the non-linear equations as part of model linearisation.
        """
        logging.info(
            "Benchmarking non-linear function evaluations used for model linearisation."
        )
        result: bool = True
        for lhs_vector_name in self.old_benchmarks.lhs_vector_names:
            old: pd.DataFrame = self.old_benchmarks.nonlinear_equation_vector_values(
                lhs_vector_name=lhs_vector_name
            )
            new: pd.DataFrame = self.new_benchmarks.nonlinear_equation_vector_values(
                lhs_vector_name=lhs_vector_name
            )
            result = result and self.compare_vectors(
                f"nonlinear equation value of LHS vector {lhs_vector_name}",
                old=old,
                new=new,
            )
        return result

    def match_linear_model_partial_derivatives(self):
        """
        ### Overview

        Compare partial derivatives matrices for the model linearisation.
        """
        logging.info("Benchmarking model linearisation partial derivatives.")
        result: bool = True
        for lhs_vector_name in self.old_benchmarks.lhs_vector_names:
            for rhs_vector_name in self.old_benchmarks.rhs_vector_names:
                old: pd.DataFrame = (
                    self.old_benchmarks.linearisation_partial_derivatives(
                        lhs_vector_name=lhs_vector_name, rhs_vector_name=rhs_vector_name
                    )
                )
                new: pd.DataFrame = (
                    self.new_benchmarks.linearisation_partial_derivatives(
                        lhs_vector_name=lhs_vector_name, rhs_vector_name=rhs_vector_name
                    )
                )
                result = result and self.compare_matrices(
                    f"{lhs_vector_name} to {rhs_vector_name} derivatives",
                    old=old,
                    new=new,
                )
        return result

    def match_ssf_matrices(self):
        """
        ### Overview

        Compare state space form matrices computed from the linearised model
        partial derivative matrices.
        """
        logging.info("Benchmarking the State-Space-Form matrices.")
        result: bool = True
        for lhs_vector_name in self.old_benchmarks.lhs_vector_names:
            for rhs_vector_name in self.old_benchmarks.ssf_rhs_vector_names:
                old: pd.DataFrame = self.old_benchmarks.ssf_matrix(
                    lhs_vector_name=lhs_vector_name, rhs_vector_name=rhs_vector_name
                )
                new: pd.DataFrame = self.new_benchmarks.ssf_matrix(
                    lhs_vector_name=lhs_vector_name, rhs_vector_name=rhs_vector_name
                )
                result = result and self.compare_matrices(
                    f"Delta {lhs_vector_name} to {rhs_vector_name} SSF matrix",
                    old=old,
                    new=new,
                )
        return result

    def match_eigenvalues(self):
        """
        ### Overview

        Check moduli of the state transition matrix eigenvalues.
        """
        logging.info("Benchmarking the transition matrix eigenvalues.")
        return self.compare_vectors(
            "eigenvalues",
            old=self.old_benchmarks.eigenvalues,
            new=self.new_benchmarks.eigenvalues,
        )

    def match_H1(self):
        """
        ### Overview

        Check the H1 matrix in the stable manifold
        """
        logging.info("Benchmarking the stable manifold H1 matrix.")
        return self.compare_matrices(
            "H1", old=self.old_benchmarks.H1, new=self.new_benchmarks.H1
        )

    def match_H2(self):
        """
        ### Overview

        Check the H2 matrix in the stable manifold
        """
        logging.info("Benchmarking the stable manifold H2 matrix.")
        return self.compare_matrices(
            "H2", old=self.old_benchmarks.H2, new=self.new_benchmarks.H2
        )

    def match_M1(self):
        """
        ### Overview

        Check the M1 matrix in the stable manifold
        """
        logging.info("Benchmarking the stable manifold M1 matrix.")
        return self.compare_matrices(
            "M1", old=self.old_benchmarks.M1, new=self.new_benchmarks.M1
        )

    def match_M2(self):
        """
        ### Overview

        Check the M2 matrix in the stable manifold
        """
        logging.info("Benchmarking the stable manifold M2 matrix.")
        return self.compare_matrices(
            "M2", old=self.old_benchmarks.M2, new=self.new_benchmarks.M2
        )

    def match_mu1(self):
        """
        ### Overview

        Check the mu1 matrix in the stable manifold
        """
        logging.info("Benchmarking the stable manifold mu1 matrix.")
        return self.compare_matrices(
            "mu1", old=self.old_benchmarks.mu1, new=self.new_benchmarks.mu1
        )

    def match_mu2(self):
        """
        ### Overview

        Check the M2 matrix in the stable manifold
        """
        logging.info("Benchmarking the stable manifold mu2 matrix.")
        return self.compare_matrices(
            "mu2", old=self.old_benchmarks.mu2, new=self.new_benchmarks.mu2
        )

    def match_Anew(self):
        """
        ### Overview

        Check the Anew matrix in the stable manifold
        """
        logging.info("Benchmarking the stable manifold Anew matrix.")
        return self.compare_matrices(
            "Anew", old=self.old_benchmarks.Anew, new=self.new_benchmarks.Anew
        )

    def match_Znew(self):
        """
        ### Overview

        Check the Znew matrix in the stable manifold
        """
        logging.info("Benchmarking the stable manifold Znew matrix.")
        return self.compare_matrices(
            "Znew", old=self.old_benchmarks.Znew, new=self.new_benchmarks.Znew
        )

    def match_Gamma_st(self):
        """
        Compare the Gamma_st matrix in the stable manifold.
        """
        logging.info("Benchmarking Gamma_st.")
        return self.compare_matrices(
            "Gamma_st",
            old=self.old_benchmarks.Gamma_st,
            new=self.new_benchmarks.Gamma_st,
        )

    def match_Gamma_jt(self):
        """
        Compare the Gamma_jt matrix in the stable manifold.
        """
        logging.info("Benchmarking Gamma_jt.")
        return self.compare_matrices(
            "Gamma_jt",
            old=self.old_benchmarks.Gamma_jt,
            new=self.new_benchmarks.Gamma_jt,
        )

    def match_Gamma_rT(self):
        """
        Compare the Gamma_rt matrix in the stable manifold.
        """
        logging.info("Benchmarking Gamma_rT.")
        return self.compare_matrices(
            "Gamma_rT",
            old=self.old_benchmarks.Gamma_rT,
            new=self.new_benchmarks.Gamma_rT,
        )

    def match_psi_rj(self):
        """
        Compare the psi_rj matrix in the stable manifold.
        """
        logging.info("Benchmarking psi_rj.")
        return self.compare_matrices(
            "psi_rj", old=self.old_benchmarks.psi_rj, new=self.new_benchmarks.psi_rj
        )

    def match_psi_rs(self):
        """
        Compare the psi_rs matrix in the stable manifold.
        """
        logging.info("Benchmarking psi_rs.")
        return self.compare_matrices(
            "psi_rs", old=self.old_benchmarks.psi_rs, new=self.new_benchmarks.psi_rs
        )

    def match_psi_rx(self):
        """
        Compare the psi_rx matrix in the stable manifold.
        """
        logging.info("Benchmarking psi_rx.")
        return self.compare_matrices(
            "psi_rx", old=self.old_benchmarks.psi_rx, new=self.new_benchmarks.psi_rx
        )

    def match_tau_sjt(self):
        """
        Compare the tau_sjt matrix in the stable manifold.
        """
        logging.info("Benchmarking tau_sjt.")
        return self.compare_matrices(
            "tau_sjt", old=self.old_benchmarks.tau_sjt, new=self.new_benchmarks.tau_sjt
        )

    def match_common_factor(self):
        """
        Compare the common factor matrix in the stable manifold.
        """
        logging.info("Benchmarking the common factor inside Gamma_jt.")
        return self.compare_matrices(
            "common factor",
            old=self.old_benchmarks.common_factor,
            new=self.new_benchmarks.common_factor,
        )

    def match_population(self):
        """
        Compare the population growth projection adjustments.
        """
        logging.info("Benchmarking population growth.")
        return self.compare_matrices(
            "population growth",
            old=self.old_benchmarks.population,
            new=self.new_benchmarks.population,
        )

    def match_productivity(self):
        """
        Compare productivity adjustments to exogenous projections.
        """
        logging.info("Comparing productivity growth adjustments for each region.")
        result: bool = True
        for region in self.old_benchmarks.regions:
            result = result and self.compare_matrices(
                f"{region} productivity growth projections",
                old=self.old_benchmarks.productivity(region=region),
                new=self.new_benchmarks.productivity(region=region),
            )
        return result

    def match_effective_labour_productivity(self):
        """
        Compare effective labour productivity adjustments to exogenous projections.
        """
        logging.info("Comparing effective labour growth adjustments for each region.")
        result: bool = True
        for region in self.old_benchmarks.regions:
            result = result and self.compare_matrices(
                f"{region} effective labour growth projections",
                old=self.old_benchmarks.effective_labour_productivity(region=region),
                new=self.new_benchmarks.effective_labour_productivity(region=region),
            )
        return result

    def match_potential_output_growth(self):
        """
        Benchmarks the potential output growth adjustments to exogenous projections.
        """
        logging.info(
            "Benchmarking potential output growth adjustments to exogenous projections."
        )
        return self.compare_matrices(
            "potential output growth projections",
            old=self.old_benchmarks.potential_output_growth,
            new=self.new_benchmarks.potential_output_growth,
        )

    def match_energy_usage_efficiency_gains(self):
        """
        Compare sectoral energy usage efficiency gain projections.
        """
        logging.info(
            "Comparing sectoral energy usage efficiency gain projections for all regions."
        )
        result: bool = True
        for region in self.old_benchmarks.regions:
            result = result and self.compare_matrices(
                f"{region} energy usage efficiency gain projections",
                old=self.old_benchmarks.energy_usage_efficiency_gain(region=region),
                new=self.new_benchmarks.energy_usage_efficiency_gain(region=region),
            )
        return result

    def match_consumption_energy_usage_efficiency_gains(self):
        """
        Benchmarks the consumption energy usage efficiency gain projections.
        """
        logging.info(
            "Benchmarking consumption energy usage efficiency gain projections for all regions."
        )
        return self.compare_matrices(
            "consumption energy usage efficiency gain projections",
            old=self.old_benchmarks.consumption_energy_usage_efficiency_gains,
            new=self.new_benchmarks.consumption_energy_usage_efficiency_gains,
        )

    def match_first_year_observed_values_of_variables_adjusted_by_intertemporal_constants(
        self,
    ):
        """
        Benchmarks the first year observed values of variables adjusted_by intertemporal constants.
        """
        logging.info(
            "Benchmarking first year observed values of variables adjusted_by intertemporal constants."
        )
        return self.compare_vectors(
            "first year observed values of variables adjusted_by intertemporal constants",
            old=self.old_benchmarks.first_year_observed_values_of_variables_adjusted_by_intertemporal_constants,
            new=self.new_benchmarks.first_year_observed_values_of_variables_adjusted_by_intertemporal_constants,
        )

    def match_first_year_original_projections_of_variables_adjusted_by_intertemporal_constants(
        self,
    ):
        """
        Benchmarks the first year original projections of variables adjusted by intertemporal constants.
        """
        logging.info(
            "Benchmarking first year original projections of variables adjusted by intertemporal constants."
        )
        return self.compare_vectors(
            "first year original projections of variables adjusted by intertemporal constants",
            old=self.old_benchmarks.first_year_original_projections_of_variables_adjusted_by_intertemporal_constants,
            new=self.new_benchmarks.first_year_original_projections_of_variables_adjusted_by_intertemporal_constants,
        )

    def match_first_year_ssf_lhs_vector_values(self):
        """
        Benchmarks the first projection year state space form evaluations of the LHS vectors.
        """
        logging.info(
            "Benchmarking first year state space form evaluations of the LHS vectors."
        )
        result: bool = True
        for lhs_vector_name in self.old_benchmarks.lhs_vector_names:
            result = result and self.compare_vectors(
                f"first year state space form evaluations of the {lhs_vector_name} vector",
                old=self.old_benchmarks.first_projection_year_ssf_lhs_vector_values(
                    lhs_vector_name=lhs_vector_name
                ),
                new=self.new_benchmarks.first_projection_year_ssf_lhs_vector_values(
                    lhs_vector_name=lhs_vector_name
                ),
            )
        return result

    def match_first_projection_year_data_difference_from_ssf(self):
        """
        Benchmarks the first projection year data difference from state space form evaluations of the LHS vectors.
        """
        logging.info(
            "Benchmarking first year data difference from state space form evaluations of the LHS vectors."
        )
        result: bool = True
        for vector_name in self.old_benchmarks.rhs_versions_of_lhs_vector_names:
            result = result and self.compare_vectors(
                f"first year data difference from state space form evaluations of the {vector_name} vector",
                old=self.old_benchmarks.first_projection_year_data_difference_from_ssf(
                    vector_name=vector_name
                ),
                new=self.new_benchmarks.first_projection_year_data_difference_from_ssf(
                    vector_name=vector_name
                ),
            )
        return result

    def match_partial_derivatives_wrt_intertemporal_constants(self):
        """
        Benchmarks the partial derivatives matrix used to compute intertemporal
        constants.
        """
        logging.info(
            "Benchmarking the partial derivatives matrix used to compute intertemporal constants."
        )
        return self.compare_matrices(
            "partial derivatives matrix for intertemporal constants",
            old=self.old_benchmarks.partial_derivatives_wrt_intertemporal_constants,
            new=self.new_benchmarks.partial_derivatives_wrt_intertemporal_constants,
        )

    def match_intertemporal_constants(self):
        """
        Check that intertemporal constant values are the same.
        """
        logging.info("Benchmarking the intertemporal constants.")
        return self.compare_vectors(
            f"intertemporal constants",
            old=self.old_benchmarks.intertemporal_constants,
            new=self.new_benchmarks.intertemporal_constants,
        )

    def match_baseline_exogenous_variable_projections(self):
        """
        Benchmarks the baseline exogenous variable projections.
        """
        logging.info("Benchmarking the baseline exogenous variable projections.")
        return self.compare_matrices(
            "baseline exogenous variable projections",
            old=self.old_benchmarks.baseline_exogenous_variable_projections,
            new=self.new_benchmarks.baseline_exogenous_variable_projections,
        )

    def match_first_projection_year_original_projections(self):
        """
        Benchmarks the first projection year original (unadjusted
        by constants) projections of the LHS vectors.
        """
        logging.info(
            "Benchmarking first projection year original projections of the LHS vectors."
        )
        result: bool = True
        for vector_name in ["yxr", "yjr", "exz", "z1l"]:
            result = result and self.compare_vectors(
                f"first projection year original projections of the {vector_name} vector",
                old=self.old_benchmarks.first_projection_year_original_projections(
                    vector_name=vector_name
                ),
                new=self.new_benchmarks.first_projection_year_original_projections(
                    vector_name=vector_name
                ),
            )
        return result

    def match_baseline_c4t(self):
        """
        Benchmarks the baseline c4t matrix.
        """
        logging.info("Benchmarking the baseline c4t matrix.")
        return self.compare_matrices(
            "baseline c4t matrix",
            old=self.old_benchmarks.baseline_c4t,
            new=self.new_benchmarks.baseline_c4t,
        )

    def match_baseline_h3t(self):
        """
        Benchmarks the baseline h3t matrix.
        """
        logging.info("Benchmarking the baseline h3t matrix.")
        return self.compare_matrices(
            "baseline h3t matrix",
            old=self.old_benchmarks.baseline_h3t,
            new=self.new_benchmarks.baseline_h3t,
        )

    def match_baseline_initial_state_vector(self):
        """
        Benchmarks the baseline initial state vector.
        """
        logging.info("Benchmarking the baseline initial state vector.")
        return self.compare_vectors(
            "baseline initial state vector",
            old=self.old_benchmarks.baseline_initial_state_vector,
            new=self.new_benchmarks.baseline_initial_state_vector,
        )

    def match_baseline_constantBL(self):
        """
        Benchmarks the baseline constantBL matrix.
        """
        logging.info("Benchmarking the baseline constantBL matrix.")
        return self.compare_matrices(
            "the baseline constantBL matrix",
            old=self.old_benchmarks.baseline_constantBL,
            new=self.new_benchmarks.baseline_constantBL,
        )

    def match_all_projections(self):
        """
        Match the details for all projections
        """
        logging.info("Benchmarking all projections.")
        old: list[tuple] = self.old_benchmarks.all_projections
        new: list[tuple] = self.new_benchmarks.all_projections

        result: bool = True

        if len(old) != len(new):
            logging.error(
                f"The number of projections in the old ({len(old)}) and new ({len(new)}) benchmarks do not match."
            )
            return False

        for i in range(len(old)):
            old_details: tuple = old[i]
            new_details: tuple = new[i]

            if old_details[0] != new_details[0]:
                logging.error(
                    f"The old first projection year {old_details[0]} does not match the new first projection year {new_details[0]} for projection {i}."
                )
                return False

            if old_details[1] != new_details[1]:
                logging.error(
                    f"The old last projection year {old_details[1]} does not match the new last projection year {new_details[1]} for projection {i}."
                )
                return False

            if old_details[2] != new_details[2]:
                logging.error(
                    f"The old projection name {old_details[2]} does not match the new projection name {new_details[2]} for projection {i}."
                )
                result = False

            result: bool = result and self.compare_matrices(
                "raw projections", old=old_details[3], new=new_details[3]
            )

            result: bool = result and self.compare_matrices(
                "database projections aside from last 12 columns",
                old=old_details[4].drop(old_details[4].columns[-12:], axis=1),
                new=new_details[4].drop(new_details[4].columns[-12:], axis=1),
            )

            result: bool = result and self.compare_matrices(
                "publishable projections aside from last 12 columns",
                old=old_details[5].drop(old_details[5].columns[-12:], axis=1),
                new=new_details[5].drop(old_details[5].columns[-12:], axis=1),
            )

        return result
