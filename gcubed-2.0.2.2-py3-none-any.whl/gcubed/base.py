"""
This module contains the `Base` class.
"""

import traceback  # Used for logging the calling stack.
import re
import os
import logging
import csv
import pandas as pd
import numpy as np


class Base:
    """

    ### Overview

    Provides convenience methods for all classes.

    All G-Cubed classes inherit from this base class.

    """

    def __init__(self) -> None:
        """

        ### Constructor

        Does constructor operations required by all classes that inherit from this base class.

        These currently just set up numpy array print options.

        """
        np.set_printoptions(formatter={"float": lambda x: "{0:0.4f}".format(x)})
        np.set_printoptions(suppress=True, linewidth=400)

        # make all Numpy warnings real Python warnings.
        np.seterr(all="warn")

    def zeros(self, rows=1, cols=1) -> pd.DataFrame:
        """
        ### Overview

        Create a dataframe filled with zeros.

        ### Arguments

        rows: the number of dataframe rows

        cols: the number of dataframe columns

        ### Returns

        A dataframe containing zeros with the given number
        of rows and the given number of columns.
        """
        data: pd.DataFrame = pd.DataFrame(0.0, index=range(rows), columns=range(cols))
        # data: pd.DataFrame = pd.DataFrame(index=range(rows), columns=range(cols))
        # data = data.replace(np.nan, 0)
        if (len(data.columns)) == 1:
            data.columns = ["value"]
        return data.astype(float)

    def load_data(self, filename: str, name_column: int = 1) -> tuple:
        """

        ### Overview

        Loads data from a CSV file, splitting it into two parts,
        the data selected as the columns with a 4 digit column name,
        and the non-data, selected as all other columns.

        This is used to load a variety of different CSV data sources.

        ### Arguments

        filename: the name of the CSV file, including the path relative
        to the model root directory.

        name_column: the column of the CSV file that contains the variable
        names, indexed from zero for the first column and defaulting to 1.

        ### Returns

        A tuple is returned. The first element in the tuple is the dataframe consisting
        of all columns that were loaded and that did not have a year label for the column.
        The second element in the tuple is the dataframe consisting of all columns that
        were loaded and that did have a year label for the column.

        ### Exceptions

        Raises an exception if the file has no contents.
        """
        if not os.path.isfile(filename):
            raise Exception(
                f"Could not load data from {filename} because it does not exist."
            )

        # Load the data
        rows = []
        with open(filename, "r") as csvfile:
            csvreader = csv.reader(csvfile)
            for row in csvreader:
                rows.append(row)

        columns = rows[0]
        max_columns = len(columns)

        assert len(rows), f"No data found in {filename}"

        # Boolean that is set to true if there is data as well as column headings.
        got_data: bool = len(rows) > 1

        # Remove the header row from the data
        if got_data:
            rows = rows[1:]

        # Pad the shorter rows with zeros to create a rectangular structure
        for row in rows:
            while len(row) < max_columns:
                row.append(0)

        # Create a pandas DataFrame from the rectangular data
        combined_data: pd.DataFrame = pd.DataFrame(rows, columns=columns)

        # Replace empty strings with None values.
        combined_data.replace("", None, inplace=True)

        # Drop any columns that are all None or NaN values.
        combined_data = combined_data.dropna(axis="columns", how="all")

        # Ensure dataframe is empty if there was no data.
        if not got_data:
            combined_data = combined_data.iloc[0:0]

        if len(combined_data.index):
            combined_data.index = combined_data.iloc[:, name_column]

        # Use a regular expression to pick out the data columns.
        regular_expression = re.compile("[1-9][0-9]{3}")
        data_column_names = list(
            filter(regular_expression.match, list(combined_data.columns))
        )
        data: pd.DataFrame = combined_data.loc[:, data_column_names]
        assert (
            not data.isna().any().any()
        ), f"NaN values found in a CSV file. Check for trailing commas in the rows of {filename}"

        other: pd.DataFrame = combined_data.drop(columns=data_column_names)
        try:
            return (other, data.astype(float))
        except ValueError as error:
            logging.error(
                f"Could not convert all data values in {filename} to float values. Please check the file content."
            )
            raise error

    # Regular expression to match YYYY format year labels.
    __YYY_regular_expression = re.compile("[1-9][0-9]{3}")

    def get_year_labels(self, labels: list[str]) -> list[str]:
        """

        ### Overview

        Extracts the subset of elements in the input list of labels that have
        a YYYY format.

        ### Arguments

        labels: A list of strings, some of which contain years in YYYY format.

        ### Returns

        all strings in the list that match the YYYY year format.
        """
        return list(filter(__class__.__YYY_regular_expression.match, labels))

    # @property
    # def now(self) -> str:
    #     """
    #     The current time and date as a string with a format that is
    #     `%Y-%m-%d_%H-%M-%S`

    #     This is useful for result reporting and debugging purposes when naming
    #     output files.
    #     """
    #     return datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    def log_calling_stack(self):
        # Get the calling stack as a list of frames
        logging.debug("Stack Trace:\n%s", traceback.format_exc())
        # stack = traceback.extract_stack()

        # # Iterate through the frames and print them
        # for frame in stack[:-1]:  # Skip the current frame (log_calling_stack itself)
        #     logging.debug(
        #         f"File: {frame.filename}, Line: {frame.lineno}, Function: {frame.name}"
        #     )
