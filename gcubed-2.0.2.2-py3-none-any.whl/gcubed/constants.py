"""
Defines a singleton class, `Constants`, that provides access to all constants.
"""


class Constants:
    """
    ### Overview

    This is a singleton class.

    Most of the constants in GCUBED are variable names and prefixes.

    """

    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super().__new__(cls, *args, **kwargs)
        return cls._instance

    _VERSION: int = "2.0.2.2"

    @property
    def VERSION(self) -> int:
        """
        The version of the G-Cubed Python implementation.
        """
        return __class__._VERSION

    _BUILD: int = 1

    @property
    def BUILD(self) -> int:
        """
        The build of the G-Cubed Python implementation.
        """
        return __class__._BUILD

    _DELTA = 0.00000001

    @property
    def DELTA(self) -> float:
        """
        The delta used to compute numeric derivatives.
        """
        return __class__._DELTA

    _ROGY_PREFIX: str = "ROGY"

    @property
    def ROGY_PREFIX(self) -> str:
        """
        The ROGY (potential output growth rate) variable prefix.
        """
        return __class__._ROGY_PREFIX

    _INFP_PREFIX: str = "INFP"

    @property
    def INFP_PREFIX(self) -> str:
        """
        The INFP (inflation rate in PRID) variable prefix.
        """
        return __class__._INFP_PREFIX

    _INFX_PREFIX: str = "INFX"

    @property
    def INFX_PREFIX(self) -> str:
        """
        The INFX (inflation rate target) variable prefix.
        """
        return __class__._INFX_PREFIX

    _PRID_PREFIX: str = "PRID"

    @property
    def PRID_PREFIX(self) -> str:
        """
        The PRID (weighted price of domestic output) variable prefix.
        """
        return __class__._PRID_PREFIX

    _REXC_PREFIX: str = "REXC"

    @property
    def REXC_PREFIX(self) -> str:
        """
        The REXC variable prefix.
        """
        return __class__._REXC_PREFIX

    _WAGE_PREFIX: str = "WAGE"

    @property
    def WAGE_PREFIX(self) -> str:
        """
        The wage variable prefix.
        """
        return __class__._WAGE_PREFIX

    _NOMINAL_GDP_PREFIX = "LGDPN"

    @property
    def NOMINAL_GDP_PREFIX(self) -> str:
        """
        The nominal GDP variable prefix.
        """
        return __class__._NOMINAL_GDP_PREFIX

    _REAL_GDP_PREFIX = "LGDPR"

    @property
    def REAL_GDP_PREFIX(self) -> str:
        """
        The real GDP variable prefix, LGDPR.
        """
        return __class__._REAL_GDP_PREFIX

    _GDPR_PREFIX = "GDPR"

    @property
    def GDPR_PREFIX(self) -> str:
        """
        The GDPR variable prefix.
        """
        return __class__._GDPR_PREFIX

    _US_REAL_GDP_RATIO_PREFIX = "YRATR"

    @property
    def US_REAL_GDP_RATIO_PREFIX(self) -> str:
        """
        The ratio of regional real GDP to USA real GDP variable prefix.
        """
        return __class__._US_REAL_GDP_RATIO_PREFIX

    _REAL_INTEREST_RATE_PREFIX = "INTR"

    @property
    def REAL_INTEREST_RATE_PREFIX(self) -> str:
        """
        The real interest rate variable prefix.
        """
        return __class__._REAL_INTEREST_RATE_PREFIX

    _NOMINAL_INTEREST_RATE_PREFIX = "INTN"

    @property
    def NOMINAL_INTEREST_RATE_PREFIX(self) -> str:
        """
        The nominal interest rate variable prefix.
        """
        return __class__._NOMINAL_INTEREST_RATE_PREFIX

    _ALL_REAL_INTEREST_RATE_PREFIXES: list[str] = ["INTF", "INTR"]

    @property
    def ALL_REAL_INTEREST_RATE_PREFIXES(self) -> list[str]:
        """
        The real interest rate variable prefixes.

        These are the prefixes of the variables that are set equal to the neutral real interest
        rate (set in the model configuration, `ModelConfiguration.neutral_real_interest_rate`)
        when doing linearisation of the model and when determining the
        adjustments to make to equate projections to observed data when
        doing the baseline projections.

        * `INTF` is the real short-run interest rate.
        * `INTL` is the real short-run interest rate, lagged by 1 period.
        * `INTR` is the 'risk-adjusted' real short-run interest rate, controlled by the central bank,
        equal to INTF plus RISR - an exogenous risk-premium in the yield curve. Note that
        RISR is typically zero in the databases and would be used to run simulation experiments.

        """
        return __class__._ALL_REAL_INTEREST_RATE_PREFIXES

    _ALL_NOMINAL_INTEREST_RATE_PREFIXES: list[str] = ["INPN", "INTN"]

    @property
    def ALL_NOMINAL_INTEREST_RATE_PREFIXES(self) -> list[str]:
        """
        The nominal interest rate variable prefixes.

        These are the prefixes of the variables that are set equal to the neutral real interest
        rate plus the expected inflation rate
        when doing linearisation of the model and when determining the
        adjustments to make to equate projections to observed data when
        doing the baseline projections.

        * `INPN` is the desired nominal short-run interest rate in the current period.
        * `INTN` is the nominal short-run interest rate, controlled by the central bank.

        """
        return __class__._ALL_NOMINAL_INTEREST_RATE_PREFIXES

    _ALL_LAGGED_NOMINAL_INTEREST_RATE_PREFIXES: list[str] = ["INPL", "INTL"]

    @property
    def ALL_LAGGED_NOMINAL_INTEREST_RATE_PREFIXES(self) -> list[str]:
        """
        The lagged nominal interest rate variable prefixes.

        These are the prefixes of the variables that are set equal to the neutral real interest
        rate plus the expected inflation rate
        when doing linearisation of the model and when determining the
        adjustments to make to equate projections to observed data when
        doing the baseline projections.

        * `INPL` is the desired nominal short-run interest rate, lagged by 1 period.

        """
        return __class__._ALL_LAGGED_NOMINAL_INTEREST_RATE_PREFIXES

    _BOND_RATE_PREFIXES: list[str] = ["NB02", "NB05", "NB10", "RB10"]

    @property
    def BOND_RATE_PREFIXES(self) -> list[str]:
        """
        The long bond rate (real and nominal) variable prefixes.
        """
        return __class__._BOND_RATE_PREFIXES

    _STATE_LEAD_VARIABLES: list[str] = ["INTN", "EXCH", "INPN", "REXB"]

    @property
    def STATE_LEAD_VARIABLES(self) -> list[str]:
        """
        The state vector lead (stl variable types in SYM) variable prefixes.
        """
        return __class__._STATE_LEAD_VARIABLES
