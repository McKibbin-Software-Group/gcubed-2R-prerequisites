"""
This module contains the `EnergyUsageEfficiency` class.
"""

import logging
import os
import pandas as pd
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData


class EnergyUsageEfficiency(Base):
    """
    This class loads and provides access to
    autonomous Energy Efficiency Improvements(AEEI) data.

    The adjustments are part of exogenous variable projections.
    """

    def __init__(self, sym_data: SymData) -> None:
        """

        ### Constructor

        ### Arguments
        sym_data: The information about the SYM model definition.

        The model configuration is accessible via this argument, thus
        enabling discovery of the location of the AEEI CSV file.

        ### CSV file format

        The AEEI CSV file records Autonomous Energy Efficiency Improvements
        for all regions and all sectors within each region, through the
        projection years. It also captures these improvements for consumption.

        See McKibbin and Wilcoxen (2013) [A global approach to energy and
        environment: the G-Cubed model](https://www.researchgate.net/publication/285239562_A_global_approach_to_energy_and_environment_the_G-Cubed_model) for details of AEEI.

        An example layout for this CSV file is shown below for the
        2 region/2 sector model:

        |         | 2017 | 2018 | 2019 | .... | 2100 |
        | ------- | ---- | ---- | ---- | ---- | ---- |
        | aeei1USA | 0    | 0    | 0    | 0    | 0    |
        | aeei2USA | 0    | 0    | 0    | 0    | 0    |
        | aeei1ROW | 0    | 0    | 0    | 0    | 0    |
        | aeei2ROW | 0    | 0    | 0    | 0    | 0    |
        | aeeicUSA | 0    | 0    | 0    | 0    | 0    |
        | aeeicROW | 0    | 0    | 0    | 0    | 0    |

        The first row contains the ordered years as column labels.

        Note that the first year can be before the first projection year.

        The last year must be the last projection year.

        The first column contains row labels. All row labels are made up
        from three components, in the following order:

        1. The prefix `aeei`
        2. Either an integer indicating the sector (for each of the
        sectors defined in the SYM model definition) or the letter `c` to
        indicate that the row describes consumption
        3. the SYM region code.

        For example, the row labelled `aeei2USA` is the AEEI projections for sector 2
        for the United States.

        The consumption rows must be the last rows in the file.

        The sector rows must be in the SYM-defined sector order.

        The rows must also be in the SYM-defined region order as you work down the file.

        The data values are the percentage exogenous improvement in energy
        efficiency for that sector, or for consumption, in the given region for a given year.

        """
        assert sym_data is not None
        assert sym_data.configuration is not None
        self._sym_data: SymData = sym_data
        self.__load_energy_usage_efficiency_data()

        self.__validate()

    def __validate(self):
        """
        Ensure energy usage efficiency data meet expectations.
        """
        pass

    @property
    def sym_data(self) -> SymData:
        return self._sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        return self.sym_data.configuration

    def sector_energy_usage_efficiency_gains(self, region: str) -> pd.DataFrame:
        """
        ### Overview

        Accesses the annual sectoral autonomous energy efficiency gain
        projections for the given region.

        ### Arguments

        `region`: The region code for which the data is required.

        ### Returns

        A dataframe containing the projected autonomous energy efficiency gains
        for the sectors in the given region.
        """
        if not region in self._sector_aeei:
            raise Exception(
                f"Energy usage efficiency (AEEI) by sector is not avaiable for region {region}"
            )
        return self._sector_aeei[region]

    def sector_cumulative_energy_usage_efficiency_gains(
        self, region: str
    ) -> pd.DataFrame:
        """
        ### Overview

        The cumulative autonomous energy efficiency gain projections for the given region
        are calculated from the annual gains in the data file.

        They are simply a cumulative sum of the annual gains.

        ### Arguments
        `region`: The region code for which the data is required.

        ### Returns
        The dataframe of cumulative energy usage efficiency gains for the sectors in
        the given region.

        Each dataframe has a row for each sector.

        They are used to populate the projections for the exogenous variables
        `SHL(sector,region)`.

        """
        if not region in self._sector_cumulative_aeei:
            raise Exception(
                f"Cumulative energy usage efficiency by sector is not avaiable for region {region}"
            )
        return self._sector_cumulative_aeei[region]

    @property
    def consumption_energy_usage_efficiency_gains(self) -> pd.DataFrame:
        """
        ### Overview

        Accesses the annual consumption autonomous energy efficiency gain
        projections for all regions.

        ### Arguments

        `region`: The region code for which the data is required.

        ### Returns

        A dataframe containing the projected autonomous energy efficiency gains
        for consumption with a row for each region and a column for each
        projection year.
        """
        return self._consumption_energy_usage_efficiency

    @property
    def consumption_cumulative_energy_usage_efficiency_gains(self) -> pd.DataFrame:
        """
        ### Overview

        The cumulative autonomous energy efficiency gain projections for
        consumption in all regions.

        They are simply a cumulative sum of the annual gains.

        ### Returns
        The dataframe of cumulative energy usage efficiency gains for consumption
        in each region.

        The dataframe has a row for each region.

        They are used to populate the projections for the exogenous variables
        `SHEFC(region)`.

        """

        """
        Dataframe for cumulative consumption energy usage efficiency with a row for each region.
        This corresponds to the SHEFC rows of product.csv.
        """
        return self._consumption_cumulative_aeei

    @property
    def model_includes_consumption_energy_usage_efficiency(self) -> bool:
        """
        `True` if the input AEEI data include consumption energy usage efficiency projections
        for each region and `False` otherwise.
        """
        if not hasattr(self, "_model_includes_consumption_energy_usage_efficiency"):
            return False
        return self._model_includes_consumption_energy_usage_efficiency

    def __load_energy_usage_efficiency_data(self):
        """

        ### Overview

        Parse the CSV file containing energy efficiency projections
        into its the dataframe of energy usage efficiency data.

        """
        # Load the data into a dataframe
        self._filename: str = self.configuration.aeei_file
        if not os.path.isfile(self._filename):
            raise Exception(
                f"The energy usage efficiency (AEEI) file, {self._filename}, does not exist. Check the model configuration."
            )
        input: pd.DataFrame = pd.read_csv(self._filename, header=0)

        # Set column 1 to be the index.
        input.index = input.iloc[:, 0]

        # Set row 1 to be the column labels.
        input = input.loc[:, self.configuration.projection_years_column_labels]

        # Get the consumption energy usage efficiency first, for models that use it.
        # The relevant projections have their index prefixed by `aeiic`.
        # Warwick removed consumption energy usage efficiency in build 170.
        consumption_rows: pd.Series = input.index.str.startswith(
            "AEEIC"
        ) | input.index.str.startswith("aeeic")
        self._consumption_energy_usage_efficiency = input.loc[
            consumption_rows, self.configuration.projection_years_column_labels
        ]
        if len(self._consumption_energy_usage_efficiency.index) > 0:
            assert (
                len(self._consumption_energy_usage_efficiency.index)
                == self.sym_data.regions_count
            ), "If consumption energy efficiency projections are provided, there must be one row for each region."
            self._consumption_energy_usage_efficiency.index = (
                self.sym_data.regions_members
            )
            self._consumption_cumulative_aeei = (
                self._consumption_energy_usage_efficiency.copy()
            )
            self._consumption_cumulative_aeei.iloc[:, 0] = 0
            self._consumption_cumulative_aeei = (
                self._consumption_cumulative_aeei.cumsum(axis=1)
            )
            logging.info(
                "The model inputs include consumption energy efficiency improvements."
            )
            self._model_includes_consumption_energy_usage_efficiency = True

        # Split the remaining data by region, with each region dataframe having one row per sector for that region.
        sectors_input: pd.DataFrame = input.loc[
            ~consumption_rows, self.configuration.projection_years_column_labels
        ].copy()

        # Set the index to be the sector and region identifier without the aeei prefix.
        sectors_input.index = sectors_input.index.str[4:]

        assert (
            len(sectors_input)
            == self.sym_data.sectors_count * self.sym_data.regions_count
        ), f"For energy usage efficiency data, there must be one row for each sector in each region but there are {len(sectors_input)} rows and {self.sym_data.regions_count} regions and {self.sym_data.sectors_count} sectors."
        self._sector_aeei = dict()
        self._sector_cumulative_aeei = dict()
        for region in self.sym_data.regions_members:
            region_aeei: pd.DataFrame = sectors_input.loc[
                sectors_input.index.str.contains(region),
                self.configuration.projection_years_column_labels,
            ].copy()
            region_aeei.index = self.sym_data.sectors_members
            region_cumulative_aeei = region_aeei.copy()
            region_cumulative_aeei.iloc[:, 0] = 0
            region_cumulative_aeei = region_cumulative_aeei.cumsum(axis=1)
            self._sector_cumulative_aeei[region] = region_cumulative_aeei
            self._sector_aeei[region] = region_aeei
