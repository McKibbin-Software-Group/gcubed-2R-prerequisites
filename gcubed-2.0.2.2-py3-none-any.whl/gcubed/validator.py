"""
This module contains the Validator classes that
check that the model configuration is runnable.
"""

from gcubed.base import Base
from gcubed.sym_data import SymData
from gcubed.model_configuration import ModelConfiguration


class Validator(Base):
    """
    ### Overview

    Checks that the given model, identified by its version and build
    is runnable.

    """

    def __init__(self, sym_data: SymData) -> None:
        """

        ### Constructor

        Initialises the model validator. This is a base class only and should not be used directly.

        ### Arguments

        sym_data: The model SYM data.

        ### Exceptions

        Raises an exception if the sym_data argument is None or not the right type.

        """
        assert sym_data is not None, f"sym_data cannot be None"
        assert isinstance(sym_data, SymData), f"sym_data must be of type SymData"
        self._sym_data = sym_data

    @property
    def sym_data(self) -> SymData:
        """
        Returns the sym data.
        """
        return self._sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        """
        Returns the model configuration.
        """
        return self.sym_data.configuration

    def validate(self) -> None:
        """

        ### Overview

        Checks that the given model configuration is allowed to be run.

        This validator should never be used. It is a base class for other validators.

        ### Exceptions

        Raises an exception always. No models can be run.

        """
        raise Exception("No models can be run using this implementation of G-Cubed.")


class AllModelsValidator(Validator):
    """
    ### Overview

    Checks that the given model is allowed to be run.

    """

    def validate(self) -> None:
        """

        ### Overview

        This validator does not rule out any of the model versions or builds.

        ### Exceptions

        No exceptions are thrown by this validator. All models can be run.

        """
        pass


class TeachingModelValidator(Validator):
    """
    ### Overview

    Checks that the model being run is the teaching model.

    """

    def validate(self) -> None:
        """

        ### Overview

        Checks that the given model configuration is a G-Cubed teaching model.

        ### Exceptions

        Throws an exception if the model is not the teaching model.

        """
        assert (
            self.configuration.version == "2R"
        ), f"The teaching model must be version 2R"
        assert (
            self.sym_data.regions_count == 2
        ), f"The teaching model must have 2 regions"
        assert (
            self.sym_data.sectors_count == 2
        ), f"The teaching model must have 2 sectors"
